package com.example.offligneplay.codejeux.clicker.vue;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.offligneplay.R;
import com.example.offligneplay.codejeux.clicker.model.Usine;

import java.util.List;

public class AdataperUsine extends RecyclerView.Adapter<AdataperUsine.MyViewHolder>{
    private List<Usine> usines;
    private OnClickListener onClickListener;

    public AdataperUsine(List<Usine> listUsines){
        this.usines = listUsines;
        this.onClickListener = null;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.usine, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Usine usineItem = this.usines.get(position);

        holder.nomUsine.setText("Usine "+usineItem.getClass().getSimpleName());
        holder.nombreUsine.setText(String.valueOf(usineItem.getNombreUsine()));
        holder.genereSeconde.setText(String.valueOf(usineItem.getGenereSeconde()));
        holder.image.setImageResource(usineItem.getImage());
        holder.prixAchat.setText(String.valueOf(usineItem.getPrixAchat()) +"$");

        holder.prixAchat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("CLICK_TEST", "Clic détecté sur la position " + position);
                if (onClickListener != null) {
                    onClickListener.onClick(position, usineItem);
                }
            }
        });
    }

    public void setOnClickListener(OnClickListener listener) {
        this.onClickListener = listener;
    }
    interface OnClickListener {
        public void onClick(int position, Usine usine);
    }

    @Override
    public int getItemCount() {
        return this.usines.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView nomUsine, nombreUsine, genereSeconde;
        ImageView image;
        Button prixAchat;

        public MyViewHolder(@NonNull View itemView) {

            super(itemView);

            nomUsine = itemView.findViewById(R.id.nomUsine);
            nombreUsine = itemView.findViewById(R.id.nombreUsine);
            genereSeconde = itemView.findViewById(R.id.genereSeconde);
            image = itemView.findViewById(R.id.image);
            prixAchat = itemView.findViewById(R.id.prixAchat);
        }
    }
}

