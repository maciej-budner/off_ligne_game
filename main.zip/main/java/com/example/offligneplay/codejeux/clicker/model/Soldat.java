package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class Soldat extends Usine{

    public Soldat(){
        super();
        this.setNiveauUsine(11);
        this.setImage(R.drawable.solda);
    }

    public Soldat(double genere){
        super(0,genere*10, genere);
    }
}
