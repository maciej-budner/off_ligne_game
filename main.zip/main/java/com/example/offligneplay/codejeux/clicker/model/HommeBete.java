package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class HommeBete extends Usine{

    public HommeBete(){
        super();
        this.setNiveauUsine(7);
        this.setImage(R.drawable.hommebete);

    }
    public HommeBete(double genere){
        super(0,genere*10, genere);
    }
}
