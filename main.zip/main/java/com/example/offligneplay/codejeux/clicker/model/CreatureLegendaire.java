package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class CreatureLegendaire extends Usine{

    public CreatureLegendaire(){
        super();
        this.setNiveauUsine(10);
        this.setImage(R.drawable.creaturelegendaire);
    }
    public CreatureLegendaire(double genere){
        super(0,genere*10, genere);
    }
}
