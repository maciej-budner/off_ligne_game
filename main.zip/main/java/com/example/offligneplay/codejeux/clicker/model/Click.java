package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class Click extends Usine{
    public Click(){
        super();
        this.setNiveauUsine(1);
        this.setImage(R.drawable.click);
    }
    public Click(double genere){
        super(0,genere*10, genere);
    }
}
