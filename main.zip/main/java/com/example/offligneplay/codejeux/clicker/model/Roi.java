package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class Roi extends Usine{

    public Roi(){
        super();
        this.setNiveauUsine(5);
        this.setImage(R.drawable.roi);
    }
    public Roi(double genere){
        super(0,genere*10, genere);
    }
}
