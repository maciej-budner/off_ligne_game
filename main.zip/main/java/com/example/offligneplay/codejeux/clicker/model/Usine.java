package com.example.offligneplay.codejeux.clicker.model;

public class Usine {
    private int niveauUsine;
    private double prixAchat;
    private int nombreUsine;
    private double genereSeconde;
    private int image;


    public Usine(){
        this.genereSeconde = 0;
        this.nombreUsine = 0;
        this.prixAchat =  0;
        this.nombreUsine = 0;
        this.image =  0;
    }

    public Usine(int nb, double prix, double genere){
        this.genereSeconde = genere;
        this.nombreUsine = nb;
        this.prixAchat =  prix;

        this.nombreUsine = 0;
    }

    public double getPrixAchat(){
        return this.prixAchat;
    }
    public double getGenereSeconde(){return this.genereSeconde;}
    public int getNombreUsine(){return this.nombreUsine;}
    public int getNiveauUsine(){
        return this.niveauUsine;
    }
    public int getImage(){return this.image;}
    public void setNiveauUsine(int niveau){
        this.niveauUsine = niveau;
    }
    public void setNombreUsine(int nombreUsine) {
        this.nombreUsine = nombreUsine;
    }
    public void setGenereSeconde(double genereSeconde) {
        this.genereSeconde = genereSeconde;
    }
    public void setPrixAchat(double prixAchat){
        this.prixAchat = prixAchat;
    }
    public void setImage(int image){this.image = image;}

    public void achatUsine(){
        this.nombreUsine += 1;
        this.prixAchat *=2;
    }
}
