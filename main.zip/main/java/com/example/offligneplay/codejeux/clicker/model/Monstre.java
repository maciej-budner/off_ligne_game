package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class Monstre extends Usine{

    public Monstre(){
        super();
        this.setNiveauUsine(9);
        this.setImage(R.drawable.creature);
    }
    public Monstre(double genere){
        super(0,genere*10, genere);
    }
}
