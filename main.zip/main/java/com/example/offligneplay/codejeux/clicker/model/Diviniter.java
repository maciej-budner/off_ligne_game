package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class Diviniter extends Usine{

    public Diviniter(){
        super();
        this.setNiveauUsine(12);
        this.setImage(R.drawable.diviniter);

    }
    public Diviniter(double genere){
        super(0,genere*10, genere);
    }
}
