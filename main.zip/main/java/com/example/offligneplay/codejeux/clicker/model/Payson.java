package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class Payson extends Usine{

    public Payson(){
        super();
        this.setNiveauUsine(2);
        this.setImage(R.drawable.payson);
    }
    public Payson(double genere){
        super(0,genere*10, genere);
    }
}
