package com.example.offligneplay.codejeux.clicker.model;


import com.example.offligneplay.codejeux.clicker.controler.Controler;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import dalvik.system.DexFile;
import kotlin.jvm.Synchronized;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;

public class Clikeur {
    private double revenuSec;
    private List<Usine> allUsine;

    private double totalRevenu;

    private Controler controler;

    private double bonusReset;

    private double bonusActuel;

    public Clikeur(){
        this.revenuSec = 0;
        this.allUsine = null;
        this.controler = null;
        this.bonusActuel = 1;
        this.bonusReset = 0;
        this.totalRevenu = 0;
    }

    /**
     * recupére tout les sous class de usine
     * @param context activity de notre jeux
     * @return une list de tout les sous-class de usine
     */
    public List<Class<? extends Usine>> allSousClassUsine(Context context){
        List<Class<? extends Usine>> subClasses = new ArrayList<>();
        String packageName = "com.example.offligneplay.codejeux.clicker.model";

        Class<Usine> superClasse = Usine.class;
        try {
            // Récupère le chemin du fichier APK/DEX exécuté par Android
            DexFile dexFile = new DexFile(context.getPackageCodePath());
            Enumeration<String> entries = dexFile.entries();

            while (entries.hasMoreElements()) {
                String className = entries.nextElement();

                // On filtre les classes appartenant à notre package
                if (className.startsWith(packageName) && !className.contains("$")) {
                    try {
                        Class<?> clazz = Class.forName(className);

                        //si la class dans model est une sous class de usine
                        if (superClasse.isAssignableFrom(clazz) && !superClasse.equals(clazz)) {
                            subClasses.add(clazz.asSubclass(superClasse));
                        }
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return subClasses;
    }
    public Clikeur(Controler controler, Context context){
        this.bonusActuel = 1;
        this.bonusReset = 0;
        this.controler = controler;
        this.revenuSec = 0;
        this.totalRevenu = 0;
        this.allUsine = new ArrayList<Usine>();
        //regarde tout les class qui extends de usine pour que le nombre d'usine soit dinamique
        List<Class<? extends Usine>> subClasses = allSousClassUsine(context);

        for (Class<?> clazz : subClasses) {
            try {
                // Crée une instance réelle de l'usine
                Usine usine = (Usine) clazz.getDeclaredConstructor().newInstance();
                this.allUsine.add(usine);
                //Log.d("SCANNER", "Usine ajoutée : " + usine.getClass() + " | Prix : " + usine.getPrixAchat());
            } catch (Exception e) {
                Log.e("SCANNER", "Impossible d'instancier : " + clazz.getSimpleName(), e);
            }
        }
        this.allUsine = trierUsineParNiveau();
        double genereSeconde = 1;
        for(Usine usine : this.allUsine) {
            if(usine.getClass() == Click.class){
                usine.setNombreUsine(1);
                usine.setGenereSeconde(genereSeconde);
                usine.setPrixAchat(genereSeconde*10);
                genereSeconde = 10;
            }
            else{
                usine.setGenereSeconde(genereSeconde);
                usine.setPrixAchat(genereSeconde*10);
                genereSeconde *= 2;
            }
            //Log.d("Trier", "Usine ajoutée : " + usine.getClass() + " | Prix : " + usine.getPrixAchat());
        }
    }

    /**
     * trie la liste selon l'ordre des niveaux des usine
     * @return la liste trier
     */
    public List<Usine> trierUsineParNiveau(){
        List<Usine> usinesTriees = new ArrayList<>(this.allUsine);

        Collections.sort(usinesTriees, Comparator.comparingInt(Usine::getNiveauUsine));

        return usinesTriees;
    }

    /**
     * calcule le gain du click et le rajoute dans les revenue
     * @return le gain du click
     */
    public double actionClick(){
        double gainClick = 0;
        Usine usineClick = this.allUsine.get(0);
        gainClick = usineClick.getNombreUsine() * usineClick.getGenereSeconde();
        this.totalRevenu += gainClick;
        return gainClick;
    }

    /**
     * regarde si on peut l'aheter l'usine, si oui, achat d'une usine et augmente le gain seconde
     * @param model l'usine acheter
     * @return le revenue par sec de l'usine
     */
    public double achatUsine(Usine model){
        if(this.totalRevenu >= model.getPrixAchat()){
            this.totalRevenu -= model.getPrixAchat();
            model.achatUsine();

            if(model.getClass() != Click.class){
                this.revenuSec += model.getGenereSeconde();
                return model.getGenereSeconde();
            }
            return 0;
        }
        else{
            return 0;
        }
    }

    /**
     * rajoue du gain par les usine non clickable
     * @param gain gain des usine
     */
    @Synchronized
    public double gainPassive(double gain){
        this.totalRevenu += gain;
        return this.totalRevenu;
    }

    public List<Usine> getAllUsine(){
        return this.allUsine;
    }
    @Synchronized
    public double getGainSec(){
        return this.revenuSec;
    }
}
