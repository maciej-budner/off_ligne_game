package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class Monture extends Usine{

    public Monture(){
        super();
        this.setNiveauUsine(6);
        this.setImage(R.drawable.monture);
    }
    public Monture(double genere){
        super(0,genere*10, genere);
    }
}
