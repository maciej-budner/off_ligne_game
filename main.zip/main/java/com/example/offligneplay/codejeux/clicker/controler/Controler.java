package com.example.offligneplay.codejeux.clicker.controler;

import com.example.offligneplay.codejeux.clicker.model.Clikeur;
import com.example.offligneplay.codejeux.clicker.model.Usine;
import com.example.offligneplay.codejeux.clicker.vue.ClickerPage;

import java.util.List;

import kotlin.jvm.Synchronized;

public class Controler {
    private ClickerPage mainPage;
    private Clikeur model;

    public Controler(){
        this.mainPage = null;
        this.model = null;
    }

    public Controler(ClickerPage main){
        this.mainPage = main;
        this.model = new Clikeur(this, main);
    }

    /**
     * demande le gain du click
     * @return le gain du click
     */
    public double actionClick(){
        return model.actionClick();
    }

    public List<Usine> getAllUsine(){
        return this.model.getAllUsine();
    }

    /**
     * achat d'une usine
     * @param model l'usine acheter
     * @return le gain par seconde de l'usine
     */
    public double achatUsine(Usine model){
        return this.model.achatUsine(model);
    }

    /**
     * rajoue du gain par les usine non clickable
     * @param gain gain des usine
     */
    @Synchronized
    public double gainPassive(double gain){
        return this.model.gainPassive(gain);
    }
    @Synchronized
    public double getGainSec(){
        return this.model.getGainSec();
    }
}
