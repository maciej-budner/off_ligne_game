package com.example.offligneplay.codejeux.clicker.vue

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.offligneplay.MainActivity
import com.example.offligneplay.R
import com.example.offligneplay.codejeux.clicker.controler.Controler
import com.example.offligneplay.codejeux.clicker.model.Usine
import com.example.offligneplay.databinding.ActivityClickerPageBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ClickerPage : AppCompatActivity() {
    private lateinit var ui: ActivityClickerPageBinding

    private lateinit var controleur: Controler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ui = ActivityClickerPageBinding.inflate(layoutInflater)
        setContentView(ui.root)

        val recyclerView = ui.recyclerView

        // Masquer la barre de statut (status bar) et la barre de navigation
        val decorView = window.decorView
        val uiOptions =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        decorView.systemUiVisibility = uiOptions

        controleur = Controler(this)

        ui.sorti.setOnClickListener {
            val mainMenu = Intent(this, MainActivity::class.java)
            startActivity(mainMenu)
            finish()
        }

        ui.attaque.setOnClickListener {
            ui.attaque.setBackgroundResource(R.drawable.attack)

            val gainActuelle = ui.gain.text.toString().toDoubleOrNull() ?: 0.0

            val rajoueGain = controleur.actionClick()
            val total = gainActuelle + rajoueGain
            ui.gain.text = total.toString()

            ui.attaque.postDelayed({
                ui.attaque.setBackgroundResource(R.drawable.repot)
            }, 1000)

        }

        val allUsine = controleur.getAllUsine()
        recyclerView.layoutManager = LinearLayoutManager(this@ClickerPage)
        recyclerView.setHasFixedSize(true)
        val adapterUsine = AdataperUsine(allUsine)
        recyclerView.adapter = adapterUsine

        //swipe sur la fenetre dedier au usine
        val bottomSheetView = findViewById<LinearLayout>(R.id.bottomSheet)
        val bottomSheetBehavior = BottomSheetBehavior.from(bottomSheetView)

        adapterUsine.setOnClickListener(object :
            AdataperUsine.OnClickListener {
            override fun onClick(position: Int, model: Usine) {
                val gaintotal = ui.gain.text.toString().toDoubleOrNull() ?: 0.0
                if(gaintotal >= model.prixAchat){
                val prixUsine = model.prixAchat
                val revenuSec = controleur.achatUsine(model)
                val gainSec = ui.gainSeconde.text.toString().toDoubleOrNull() ?: 0.0
                val total = revenuSec + gainSec
                ui.gainSeconde.text = total.toString()
                val total2 = gaintotal - prixUsine
                ui.gain.text = total2.toString()
                //rapel pour mettre a jour le prix usine
                adapterUsine.notifyItemChanged(position)}

            }
        })

        // Ouvrir le panneau par le code
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED

        // Fermer / Réduire le panneau
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED

        // Détecter les changements d'état
        bottomSheetBehavior.addBottomSheetCallback(object :
            BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(bottomSheet: View, newState: Int) {
                when (newState) {
                    BottomSheetBehavior.STATE_EXPANDED -> {
                        // Le panneau est complètement ouvert
                        adapterUsine.notifyDataSetChanged()
                    }

                    BottomSheetBehavior.STATE_COLLAPSED -> {
                        // Le panneau est fermé / réduit
                    }
                }
            }

            override fun onSlide(bottomSheet: View, slideOffset: Float) {
                // Appelé pendant le mouvement du glissement
            }
        })

        //thread pour revenu/sec
        lifecycleScope.launch {
            while (true) {
                delay(1000) // Suspend sans bloquer le thread

                val gainSec = controleur.getGainSec()
                val nouveauTotal = controleur.gainPassive(gainSec)

                ui.gain.text = nouveauTotal.toString()
            }
        }

    }
}

