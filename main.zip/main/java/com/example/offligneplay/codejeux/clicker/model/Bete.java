package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class Bete extends Usine{

    public Bete(){
        super();
        this.setNiveauUsine(8);
        this.setImage(R.drawable.bete);
    }

    public Bete(double genere){
        super(0,genere*10, genere);
    }
}
