package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class Paladin extends Usine{

    public Paladin(){
        super();
        this.setNiveauUsine(4);
        this.setImage(R.drawable.paladin);
    }
    public Paladin(double genere){
        super(0,genere*10, genere);
    }
}
