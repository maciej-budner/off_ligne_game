package com.example.offligneplay.codejeux.clicker.model;

import com.example.offligneplay.R;

public class Chevalier extends Usine{

    public Chevalier(){
        super();
        this.setNiveauUsine(3);
        this.setImage(R.drawable.chevalier);
    }
    public Chevalier(double genere){
        super(0,genere*10, genere);
    }
}
