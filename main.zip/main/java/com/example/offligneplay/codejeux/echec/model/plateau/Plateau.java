package com.example.offligneplay.codejeux.echec.model.plateau;
import java.util.HashMap;
/**
 * Classe qui représente le plateau de jeu
 * 
 * @author Maciej
 */
public class Plateau {
    private HashMap<String, Cases> plateau;
    private String positionRoiGreen;
    private String positionRoiBlue;
    private String positionRoiRed;

    /**
     * on lie les cases uniquement leur lien nord et sud
     * @param idPlateauSens le tableau des identifiants des cases
     */
    private void associerVoisinNS(String idPlateauSens[][]){
        for(int i=0; i<8; i++){
            for(int j=0; j<8; j++){
                Cases cases = this.plateau.get(idPlateauSens[i][j]);
                
                //NE,NO,SE,SO,E,OU,N,S
                if(i==0){
                    //il a pas de haut
                    cases.setVoisinSecuriser(null, null, null, null, null, null, null, this.plateau.get(idPlateauSens[i+1][j]));
                }
                else if(i==7){
                    //il a pas de bas
                    cases.setVoisinSecuriser(null, null, null, null, null, null, this.plateau.get(idPlateauSens[i-1][j]), null);
                }
                else{
                    cases.setVoisinSecuriser(null, null, null, null, null, null, this.plateau.get(idPlateauSens[i-1][j]), this.plateau.get(idPlateauSens[i+1][j]));
                }
            }
        }   
    }



    /**
     * Associe les voisins Est/Ouest et diagonales.
     * @param idPlateauSens le tableau des identifiants des cases
     */
    private void associerVoisinEO(String idPlateauSens[][]){
        // Récupération dynamique de la taille pour éviter tout crash (4x8, 8x8, etc.)
        int maxI = idPlateauSens.length;
        int maxJ = idPlateauSens[0].length;

        for (int i = 0; i < maxI; i++) {
            for (int j = 0; j < maxJ; j++) {
                Cases cases = this.plateau.get(idPlateauSens[i][j]);

                // 1. Détection des bords (true si on n'est pas sur le bord)
                boolean hasHaut   = (i > 0);
                boolean hasBas    = (i < maxI - 1);
                boolean hasGauche = (j > 0);
                boolean hasDroite = (j < maxJ - 1);

                // 2. Récupération des clés (null si hors limite)
                String idNE = (hasHaut && hasDroite) ? idPlateauSens[i - 1][j + 1] : null;
                String idNO = (hasHaut && hasGauche) ? idPlateauSens[i - 1][j - 1] : null;
                String idSE = (hasBas && hasDroite)  ? idPlateauSens[i + 1][j + 1] : null;
                String idSO = (hasBas && hasGauche)  ? idPlateauSens[i + 1][j - 1] : null;

                String idE  = hasDroite ? idPlateauSens[i][j + 1] : null;
                String idO  = hasGauche ? idPlateauSens[i][j - 1] : null;

                // 3. Attribution (NE, NO, SE, SO, E, OU, N, S)
                cases.setVoisinSecuriser(
                        idNE != null ? this.plateau.get(idNE) : null,
                        idNO != null ? this.plateau.get(idNO) : null,
                        idSE != null ? this.plateau.get(idSE) : null,
                        idSO != null ? this.plateau.get(idSO) : null,
                        idE  != null ? this.plateau.get(idE)  : null,
                        idO  != null ? this.plateau.get(idO)  : null,
                        null, // Nord ignoré
                        null  // Sud ignoré
                );
            }
        }
    }

    /**
     * initialisation des voisins
     */
    private void initVoisin(){
        String idPlateauNS[][]={//plateau haut on prend que N et S
            {"A8","B8","C8","D8","E8","F8","G8","H8"},
            {"A7","B7","C7","D7","E7","F7","G7","H7"},
            {"A6","B6","C6","D6","E6","F6","G6","H6"},
            {"A5","B5","C5","D5","E5","F5","G5","H5"},
            {"A4","B4","C4","D4","E4","F4","G4","H4"},
            {"A3","B3","C3","D3","E3","F3","G3","H3"},
            {"A2","B2","C2","D2","E2","F2","G2","H2"},
            {"A1","B1","C1","D1","E1","F1","G1","H1"}
        };

        //TODO: savoir comment faire les lien avec le tab de haut sont avoir besoin de la liaisont special
        String idPlateauEO[][]={//plateau haut on prend que E et O
                {"A8","B8","C8","D8","E8","F8","G8","H8"},
                {"A7","B7","C7","D7","E7","F7","G7","H7"},
                {"A6","B6","C6","D6","E6","F6","G6","H6"},
                {"A5","B5","C5","D5","E5","F5","G5","H5"},
                {"A4","B4","C4","D4","E4","F4","G4","H4"},
                {"A3","B3","C3","D3","E3","F3","G3","H3"},
                {"A2","B2","C2","D2","E2","F2","G2","H2"},
                {"A1","B1","C1","D1","E1","F1","G1","H1"}
            
        };

        //TODO: factoriser pour le faire on une seul boucle
        this.associerVoisinNS(idPlateauNS);
        associerVoisinEO(idPlateauEO);
        
    }

    /**
     * initialisation du plateau
     */
    private void initPlateau(){
        String idCases[] = {"A1","A2","A3","A4","A5","A6","A7","A8",
                        "B1","B2","B3","B4","B5","B6","B7","B8",
                        "C1","C2","C3","C4","C5","C6","C7","C8",
                        "D1","D2","D3","D4","D5","D6","D7","D8",
                        "E1","E2","E3","E4","E5","E6","E7","E8",
                        "F1","F2","F3","F4","F5","F6","F7","F8",
                        "G1","G2","G3","G4","G5","G6","G7","G8",
                        "H1","H2","H3","H4","H5","H6","H7","H8",};
        for(int i=0; i<64; i++){
            Cases cases = new Cases(idCases[i]);
            this.plateau.put(idCases[i], cases);
        }
        this.initVoisin();

    }
    public Plateau() {
        this.plateau = new HashMap<String, Cases>();
    }

    /**
     * retourne une piece selon son nom et sa couleur
     * @param nomPiece le nom de la piece
     * @param couleur la couleur de la piece
     * @return la piece
     */
    public Piece getPieceSelonNom(String nomPiece, String couleur){
        switch(nomPiece){
            case "Tour":
                return new Tour(couleur, 5);
            case "Cavalier":
                return new Cavalier(couleur, 3);
            case "Fou":
                return new Fou(couleur, 3);
            case "Reine":
                return new Reine(couleur, 9);
            case "Roi":
                return new Roi(couleur, 100);
            default:
                return new Pion(couleur, 1);
        }
    }

    /**
     * met les piece dans le plateau
     */
    public void setStartPartie(){
        initPlateau();//une sorte de reset
        //on sait ou est le roi
        this.positionRoiBlue="E8";//existe pas
        this.positionRoiGreen="E1";
        this.positionRoiRed="E8";
        //placer les piece
        String pieces[]={"Tour","Cavalier","Fou","Reine","Roi","Fou","Cavalier","Tour"};
        String positionPiece[][]={//vert
            {"A1","B1","C1","D1","E1","F1","G1","H1"},
            {"A2","B2","C2","D2","E2","F2","G2","H2"},
            //rouge
            {"A8","B8","C8","D8","E8","F8","G8","H8"},
            {"A7","B7","C7","D7","E7","F7","G7","H7"},
        };
        String couleur[]={"green","red"};
        for(int i=0; i<4; i+=2){
            for(int j=0; j<8; j++){
                String nomPiece = pieces[j];
                String positionGrosePiece = positionPiece[i][j];
                String positionPion = positionPiece[i+1][j];
                Cases casesGrisPiece = this.plateau.get(positionGrosePiece);
                Cases casesPion = this.plateau.get(positionPion);
                String couleurPiece = couleur[i/2];
                Piece piecePion = this.getPieceSelonNom("Pion", couleurPiece);
                Piece pieceGrose = this.getPieceSelonNom(nomPiece, couleurPiece);
                
                casesGrisPiece.setPiece(pieceGrose);
                casesPion.setPiece(piecePion);
            }
        }
        //void si tout les voisin sont bien
        /*
        for (Cases elem : this.plateau.values()) {
            System.out.print(elem.toString());
            System.out.print("\n");
        }*/
    }
    
    /**
     * deplace une piece
     * @param casePiece la case de la piece
     * @param casePieceDeplacer la case de la piece a deplacer
     */
    public void deplacementPiece(String casePiece, String casePieceDeplacer){
        Cases casesDepart = this.plateau.get(casePiece);
        Cases casesArrive = this.plateau.get(casePieceDeplacer);
        Piece piece = casesDepart.getPiece();
        casesArrive.setPiece(piece);
        casesDepart.setPiece(null);
    }
    
    /**
     * retourne le plateau
     * @return le plateau
     */
    public HashMap<String, Cases> getPlateau() {
        return this.plateau;
    }
    /**
     * retourne une case selon sa position
     * @param position la position de la case
     * @return la case
     */
    public Cases getCasesInPosition(String position){
        return this.plateau.get(position);
    }
    public void setPlateau(HashMap<String, Cases> plateau){
        this.plateau = plateau;
    }
    public String getRoiRed(){
        return this.positionRoiRed;
    }
    public String getRoiBlue(){
        return this.positionRoiBlue;
    }
    public String getRoiGreen(){
        return this.positionRoiGreen;
    }
    public void setRoiRed(String newPosition){
        this.positionRoiRed = newPosition;
    }
    public void setRoiBlue(String newPosition){
        this.positionRoiBlue = newPosition;
    }
    public void setRoiGreen(String newPosition){
        this.positionRoiGreen  = newPosition;
    }
    /**
     * verifie si une piece est sur une case
     * @param position la position de la case
     * @return true si une piece est sur la case, false sinon
     */
    public boolean pieceOnCase(String position){
        Cases pieceCase = this.plateau.get(position);
        if(pieceCase.getPiece() != null){
            return true;
        }
        else{
            return false;
        }
    }
    public String getCouleurPiece(String position){
        Cases cases = this.plateau.get(position);
        Piece piece = cases.getPiece();
        return piece.getCouleurPiece();
    }

    public int getCoupPossibleCase(String position){
        Cases cases = this.plateau.get(position);
        return cases.getCoupPossible();
    }

    public String getRoiSelonCouleur(String couleur){
        if(couleur == "green"){
            return this.positionRoiGreen;
        }
        else if(couleur == "red"){
            return this.positionRoiRed;
        }
        else{
            return this.positionRoiBlue;
        }
    }

}