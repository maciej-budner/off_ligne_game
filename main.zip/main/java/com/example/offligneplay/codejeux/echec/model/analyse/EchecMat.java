package com.example.offligneplay.codejeux.echec.model.analyse;

import java.util.HashSet;

import com.example.offligneplay.codejeux.echec.model.plateau.*;

/**
 * La classe EchecMat représente l'état d'échec et mat dans une partie d'échecs.
 * Elle gère la détection des situations d'échec et mat où le roi est en échec
 * et qu'aucun coup légal ne peut le sortir de cette situation.
 * 
 * @author Maciej Budner
 */
public class EchecMat extends AnalysePartie{
    /**
     * Constructeur par défaut de la classe EchecMat.
     * Initialise une liste vide de coups possibles.
     */
    public EchecMat(){
        super();
    }
    
    /**
     * Constructeur de la classe EchecMat avec une liste de coups existante.
     * 
     * @param coupPossible l'ensemble des coups possibles à initialiser
     */
    public EchecMat(HashSet<String> coupPossible){
        super(coupPossible);
    }
    

    /**
     * Vérifie l'état du jeu et confirme l'échec et mat.
     * Si cette classe est utilisée, c'est que la situation est un échec et mat.
     *
     * @param casesRoi la case contenant le roi
     * @return 2 pour indiquer que la situation est un échec et mat (fin du jeu)
     */
    public int verificationEtatDuJeux( Cases casesRoi){
        return 2;
    }


    /**
     * Change l'état d'analyse en fonction de l'état du jeu.
     * En cas d'échec et mat, reste dans le même état car la partie est terminée.
     * 
     * @param etatJeux l'état du jeu actuel
     * @return une nouvelle instance d'EchecMat (partie terminée)
     */
    public AnalysePartie changeState(int etatJeux){
        //si echec et Mat fin du jeu
        return new EchecMat(this.getCoupPossible());
    }
}
