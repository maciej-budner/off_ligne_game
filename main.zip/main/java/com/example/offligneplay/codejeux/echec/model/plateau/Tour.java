package com.example.offligneplay.codejeux.echec.model.plateau;

public class Tour extends Piece {
    public Tour() {
        super();
    }
    public Tour(String couleur, int point) {
        super(couleur, point);
    }

    @Override
    public String deplacement() {
        return "toutDroit";
    }
    
}
