package com.example.offligneplay.codejeux.echec.model.analyse;
import java.util.HashSet;

import com.example.offligneplay.codejeux.echec.model.plateau.*;

/**
 * Classe abstraite représentant l'analyse de l'état d'une partie d'échecs.
 * Gère la détection des différents états de jeu (échec, échec et mat, pat, etc.)
 * et la gestion des coups possibles.
 * 
 * @author Maciej Budner
 */
public abstract class AnalysePartie {
    /** Ensemble des coups possibles pour le joueur actuel */
    private HashSet<String> coupPossible;

    /**
     * Constructeur par défaut d'AnalysePartie.
     * Initialise une liste vide de coups possibles.
     */
    public AnalysePartie(){
        this.coupPossible = new HashSet<String>();
    }

    /**
     * Constructeur d'AnalysePartie avec une liste de coups existante.
     * 
     * @param coupPossible l'ensemble des coups possibles à initialiser
     */
    public AnalysePartie(HashSet<String> coupPossible){
        this.coupPossible = coupPossible;
    }

    /**
     * Récupère l'ensemble des coups possibles.
     * 
     * @return l'ensemble des coups possibles
     */
    public HashSet<String> getCoupPossible(){
        return this.coupPossible;
    }

    /**
     * Vérifie si une case fait partie des coups possibles.
     * 
     * @param casesChoisi l'identifiant de la case à vérifier
     * @return true si la case est dans les coups possibles, false sinon
     */
    public boolean listCantient(String casesChoisi){
        return this.coupPossible.contains(casesChoisi);
    }

    /**
     * Ajoute une case à la liste des coups possibles.
     * 
     * @param casesCoupPosible l'identifiant de la case à ajouter
     */
    public void addInList(String casesCoupPosible){
        this.coupPossible.add(casesCoupPosible);
    }

    /**
     * Vérifie si la liste des coups possibles est vide.
     * 
     * @return true si la liste est vide, false sinon
     */
    public boolean listVide(){
        if(this.coupPossible.size() != 0){
            return false;
        }
        else{
            return true;
        }
    }

    /**
     * Vide la liste des coups possibles.
     */
    public void resetList(){
        this.coupPossible.clear();
    }

    /**
     * Définit la liste des coups possibles.
     * 
     * @param coupPossible le nouvel ensemble de coups possibles
     */
    public void setCoupPossible(HashSet<String> coupPossible){
        this.coupPossible = coupPossible;
    }

    /**
     * Vérifie l'état actuel du jeu.
     * @param casesRoi la case contenant le roi
     * @return un entier représentant l'état du jeu (0: normal, 1: échec, 2: échec et mat, 3: pat)
     */
    public abstract int verificationEtatDuJeux( Cases casesRoi);

    /**
     * Change l'état d'analyse en fonction de l'état du jeu.
     * 
     * @param etatJeux l'état du jeu actuel
     * @return une nouvelle instance d'AnalysePartie correspondant au nouvel état
     */
    public abstract AnalysePartie changeState(int etatJeux);
    
    /**
     * Recherche récursive si le roi est en échec en ignorant une case.
     * 
     * @param direction la direction d'analyse
     * @param cases la case actuelle
     * @param ignore la case à ignorer
     * @param caseRoi la case du roi
     * @param depart la case avant la recurciviter
     * @param blockerCase une bool qui dit si en doit ignorer la case ou blocker l'avancemet
     * @return true si le roi est en échec, false sinon
     */
    public boolean recurciviterDuRoiEchecIgnoreCase(String direction, Cases cases, Cases ignore, Cases caseRoi, Cases depart, boolean blockerCase){
        if(cases == null){
            return false; //en dehord du plateau
        }
        //on prend le suivant
        Cases nouvelleCase = getCaseSuivante(direction, cases);
        if(nouvelleCase ==null){
            return false;//rien trouver donc pas echec
        }
        else if(nouvelleCase == ignore ){
            if(!(blockerCase)){
                //on lignore la case et on continue
                return recurciviterDuRoiEchecIgnoreCase(direction, nouvelleCase, ignore,caseRoi,depart, blockerCase);
            }   
            else{
                return false;
            }
        }
        else if(nouvelleCase.getPiece() != null){
            //on a un pion faut voir si c'est le notre ou pas
            if (caseRoi != null && caseRoi.getPiece() != null) {
                if (nouvelleCase.getPiece().getCouleurPiece().equals(caseRoi.getPiece().getCouleurPiece())) {
                    // C'est notre pion, plus besoin de regarder dans cette direction
                    return false;
                }else{
                    return false;
                }
            }
            else{
                //c'es un ennemi
                if(quipeutAttaquerRoi(nouvelleCase.getPiece(), direction, caseRoi, nouvelleCase,depart)){
                    return true;
                }
                else{
                    return false;
                }
            }
        }
        else{
            //on peut continuer
            //on regarde si on est pas dans le cas où on a pas put mettre de lien sudest et sud ouest
            direction = changeDirection(cases.getIdCase(), nouvelleCase.getIdCase(), direction);
            return recurciviterDuRoiEchecIgnoreCase(direction, nouvelleCase, ignore,caseRoi,depart, blockerCase);
        }
    }
    /**
     * Vérifie si le roi est en échec en ignorant une case.
     * 
     * @param cases la case de départ
     * @param ignore la case à ignorer
     * @param caseRoi la case du roi
     * @param blockerCase une bool qui dit si en doit ignorer la case ou blocker l'avancemet
     * @return true si le roi est en échec, false sinon
     */
    public boolean roiEnEchecIgnoreUneCase(Cases cases, Cases ignore, Cases caseRoi, boolean blockerCase){
        if(recurciviterDuRoiEchecIgnoreCase("nord", cases, ignore,caseRoi,cases,blockerCase) ||
            recurciviterDuRoiEchecIgnoreCase("sud", cases, ignore,caseRoi,cases, blockerCase) ||
            recurciviterDuRoiEchecIgnoreCase("sudEst", cases, ignore,caseRoi,cases,blockerCase) ||
            recurciviterDuRoiEchecIgnoreCase("sudOuest", cases, ignore,caseRoi,cases, blockerCase) ||
            recurciviterDuRoiEchecIgnoreCase("nordEst", cases, ignore,caseRoi,cases, blockerCase) ||
            recurciviterDuRoiEchecIgnoreCase("nordOuest", cases, ignore,caseRoi,cases, blockerCase) ||
            recurciviterDuRoiEchecIgnoreCase("est", cases, ignore,caseRoi,cases, blockerCase) ||
            recurciviterDuRoiEchecIgnoreCase("ouest", cases, ignore,caseRoi,cases, blockerCase) 
            ){
            return true;
        }//verifier pour le cavalier car cas special sur comment il attaque
        else{//si c'est un cavalier il est on echec dans tout les cas
            return false;
        }
        
    }
    
    /**
     * Vérifie si le déplacement d'un pion met le roi en échec.
     * 
     * @param ignore la case à ignorer dans l'analyse
     * @param roi la case du roi
     * @return true si le roi est en échec après le déplacement, false sinon
     */
    public boolean bougePionMiseEchecRoi(Cases ignore, Cases roi){
        return roiEnEchecIgnoreUneCase(roi, ignore, roi, false);
    }
    /**
     * Vérifie si une case est attaquée par un cavalier.
     * 
     * @param cases la case actuelle
     * @param notrePiece la piece actuelle
     * @return la case attaquée par le cavalier, ou une chaîne vide si aucune
     */
    public Cases attaquerParCavalierQui(Cases cases, Piece notrePiece){
        Cases casesEntreDeux = null;
        Cases caseAttaquer = null;
        if(cases.getNord() !=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getNord().getNord();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getOuest() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getOuest().getPiece() !=null){
                        if(casesEntreDeux.getOuest().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getOuest().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = casesEntreDeux.getOuest();
                        }
                    }
                }
                if(casesEntreDeux.getEst() != null){
                    if(casesEntreDeux.getEst() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getEst().getPiece() !=null){
                            if(casesEntreDeux.getEst().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getEst().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = casesEntreDeux.getEst();
                            }
                        }
                    }
                }
            }
        }
        if(cases.getSud()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getSud().getSud();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getOuest() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getOuest().getPiece() !=null){
                        if(casesEntreDeux.getOuest().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getOuest().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = casesEntreDeux.getOuest();
                        }
                    }
                }
                if(casesEntreDeux.getEst() != null){
                    if(casesEntreDeux.getEst() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getEst().getPiece() !=null){
                            if(casesEntreDeux.getEst().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getEst().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = casesEntreDeux.getOuest();
                            }
                        }
                    }
                }
            }
        }
        //nord sud case possible
        if(cases.getEst()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getEst().getEst();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getNord() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getNord().getPiece() !=null){
                        if(casesEntreDeux.getNord().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getNord().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = casesEntreDeux.getNord();
                        }
                    }
                }
                if(casesEntreDeux.getSud() != null){
                    if(casesEntreDeux.getSud() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getSud().getPiece() !=null){
                            if(casesEntreDeux.getSud().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getSud().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = casesEntreDeux.getSud();
                            }
                        }
                    }
                }
            }
        }
        if(cases.getOuest()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getOuest().getOuest();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getNord() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getNord().getPiece() !=null){
                        if(casesEntreDeux.getNord().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getNord().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = casesEntreDeux.getNord();
                        }
                    }
                }
                if(casesEntreDeux.getSud() != null){
                    if(casesEntreDeux.getSud() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getSud().getPiece() !=null){
                            if(casesEntreDeux.getSud().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getSud().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = casesEntreDeux.getSud();
                            }
                        }
                    }
                }
            }
        }
        return caseAttaquer;
    }
    /**
     * Vérifie récursivement qui a mis le roi en échec.
     * 
     * @param direction la direction d'analyse
     * @param cases la case actuelle
     * @param caseRoi la case du roi
     * @param depart la case de depart avant recurciviter
     * @return la cases de la pièce qui a mis le roi en échec, ou une chaîne vide si aucun
     */
    public Cases recurciviterDuRoiEchecQUI(String direction, Cases cases, Cases caseRoi, Cases depart){
        //on prend le suivant
        Cases nouvelleCase = getCaseSuivante(direction, cases);
        if(nouvelleCase ==null){
            return null;//rien trouver donc pas echec
        }
        else if(nouvelleCase.getPiece() != null){
            //on a un pion faut voir si c'est le notre ou pas
            if(nouvelleCase.getPiece().getCouleurPiece() == caseRoi.getPiece().getCouleurPiece()){
                //ces notre pion plus besoin de regarder si attaquer dans cette direction
                return null;
            }
            else{
                //c'es un ennemi
                if(quipeutAttaquerRoi(nouvelleCase.getPiece(), direction, caseRoi, nouvelleCase, depart)){
                    return nouvelleCase;
                }
                else{
                    return null;
                }
            }
        }
        else{
            //on peut continuer
            //on regarde si on est pas dans le cas où on a pas put mettre de lien sudest et sud ouest
            direction = changeDirection(cases.getIdCase(), nouvelleCase.getIdCase(), direction);
            return recurciviterDuRoiEchecQUI(direction, nouvelleCase,caseRoi,depart);
        }
    }
    /**
     * Vérifie qui a mis le roi en échec.
     * 
     * @param cases la case actuelle
     * @param caseRoi la case du roi
     * @return la cases de la pièce qui a mis le roi en échec, ou null si aucun
     */
    public Cases roiEnEchecQui(Cases cases, Cases caseRoi){
        Cases qui=null;
        qui = recurciviterDuRoiEchecQUI("nord", cases,caseRoi,cases) ;
        if((qui != null)){
            return qui;
        }
        qui =  recurciviterDuRoiEchecQUI("sud", cases,caseRoi,cases) ;
        if((qui!= null)){
            return qui;
        }
        qui =  recurciviterDuRoiEchecQUI("sudEst", cases,caseRoi,cases);
        if((qui!= null)){
            return qui;
        }
        qui =  recurciviterDuRoiEchecQUI("sudOuest", cases,caseRoi,cases);
        if((qui!= null)){
            return qui;
        }
        qui =  recurciviterDuRoiEchecQUI("nordEst", cases,caseRoi,cases);
        if((qui!= null)){
            return qui;
        }
        qui =  recurciviterDuRoiEchecQUI("nordOuest", cases,caseRoi,cases);
        if((qui!= null)){
            return qui;
        }
        qui =  recurciviterDuRoiEchecQUI("est", cases,caseRoi,cases);
        if((qui!= null)){
            return qui;
        }
        qui =  recurciviterDuRoiEchecQUI("ouest", cases,caseRoi,cases) ;
        if((qui!= null)){
            return qui;
        }
        //verifier pour le cavalier car cas special sur comment il attaque
        qui =  attaquerParCavalierQui(cases, caseRoi.getPiece());
        return qui;
        
    }

    /**
     * Identifie le joueur qui met le roi en échec.
     * 
     * @param roi la case contenant le roi
     * @return la cases du joueur qui met le roi en échec
     */
    public Cases quiMetEnEchec(Cases roi){
        return roiEnEchecQui(roi, roi);
    }
    
    /**
     * Récupère la case suivante dans une direction donnée.
     * Méthode héritée de MontrePosibiliter pour la navigation sur le plateau.
     * 
     * @param directionSuivante la direction de recherche ("nord", "sud", "est", "ouest", etc.)
     * @param cases la case de départ
     * @return la case suivante dans la direction spécifiée, ou null si hors plateau
     */
    public Cases getCaseSuivante(String directionSuivante, Cases cases){
        switch(directionSuivante){
            case "nord":
                return cases.getNord();
            case "nordEst":
                return cases.getNordEst();
            case "nordOuest":
                return cases.getNordOuest();
            case "est":
                return cases.getEst();
            case "ouest":
                return cases.getOuest();
            case "sud":
                return cases.getSud();
            case "sudEst":
                return cases.getSudEst();
            case "sudOuest":
                return cases.getSudOuest();
            default:
                return null;
        }

    }
    /**
     * Vérifie si une case se trouve dans la zone bleue (colonnes E, F, G, H) du plateau.
     * Utilisé pour la gestion spécifique du plateau à 3 joueurs.
     * 
     * @param laCaseVoulue l'identifiant de la case à vérifier
     * @return true si la case est dans la zone bleue, false sinon
     */
    public boolean bleuDansCasEaH(String laCaseVoulue){
        if((laCaseVoulue.contains("E") || 
            laCaseVoulue.contains("G") || 
            laCaseVoulue.contains("F") || 
            laCaseVoulue.contains("H" ))){
            return true;
        }
        else{
            return false;
        }
    }
    /**
     * Vérifie si une case se trouve dans la zone où les pions se déplacent vers le haut (colonnes I, J, K, L).
     * Utilisé pour la gestion spécifique du plateau à 3 joueurs.
     * 
     * @param laCaseVoulue l'identifiant de la case à vérifier
     * @return true si la case est dans la zone de déplacement vers le haut, false sinon
     */
    public boolean onDeplacePionHaut(String laCaseVoulue){
        if((laCaseVoulue.contains("I") || 
            laCaseVoulue.contains("J") || 
            laCaseVoulue.contains("K") || 
            laCaseVoulue.contains("L" ))){
            return true;
        }
        else{
            return false;
        }
    }
    /**
     * Détermine si un pion peut attaquer une position ou le roi peut se placer
     * 
     * @param couleur la couleur du pion ("red", "green", "blue")
     * @param caseId l'identifiant de la case où se trouve le pion
     * @param casePion la case ou il y a le pion
     * @param caseRoi la case ou il u a le Roi
     * @param depart la case de depart avant récusiviter
     * @return true si le pion peut attaquer dans cette direction, false sinon
     */
    public boolean attaqueDuPion(String couleur,String caseId, Cases casePion, Cases caseRoi, Cases depart){
        String ecouteur = "";
        ecouteur = ecouteur.copyValueOf(caseId.toCharArray(), 1, caseId.length()-1);
        System.out.println("casesPion:"+caseId+" caseDepart:"+depart.getIdCase()+" couleur:"+couleur);
        switch (couleur) {
            case "green":
                //dans tout les cas il attaque nord
                if(depart == casePion.getNordEst() || depart == casePion.getNordOuest()){
                    System.out.println("P V att");
                    return true;
                }
                else{
                    return false;
                }
            case "red":
                
                if(onDeplacePionHaut(caseId) && Integer.parseInt(ecouteur) <=8){
                    //attaque nord
                    if(depart == casePion.getNordEst() || depart == casePion.getNordOuest()){
                        System.out.println("P R att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }//obliger de séparer car c'est pas les meme case tester
                else if(!(bleuDansCasEaH(caseId)) && Integer.parseInt(ecouteur) <=8){
                    //attaque nord
                    if(depart == casePion.getNordEst() || depart == casePion.getNordOuest()){
                        System.out.println("P R att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else{
                    //sinon attaque sud
                    if(depart == casePion.getSudEst() || depart == casePion.getSudOuest()){
                        System.out.println("P R att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }
            default:  //pion bleu
                if(onDeplacePionHaut(caseId) && Integer.parseInt(ecouteur) >8){
                    //attaque nord
                    if(depart == casePion.getNordEst() || depart == casePion.getNordOuest()){
                        System.out.println("P B att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }//obliger de séparer car c'est pas les meme case tester
                else if(bleuDansCasEaH(caseId)&& Integer.parseInt(ecouteur) >8){
                    //attaque nord
                    if(depart == casePion.getNordEst() || depart == casePion.getNordOuest()){
                        System.out.println("P B att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else{
                    //sinon attaque sud
                    if(depart == casePion.getSudEst() || depart == casePion.getSudOuest()){
                        System.out.println("P B att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }
        }
    }
    /**
     * Détermine si une pièce donnée peut attaquer le roi dans une direction spécifique.
     * Analyse les capacités d'attaque de chaque type de pièce selon la direction.
     * 
     * @param attaquant la pièce potentielle attaquant
     * @param direction la direction d'analyse
     * @param roi la case contenant le roi
     * @param positionPiece la position de la pièce attaquant
     * @param depart la case de depart avant récusiviter
     * @return true si la pièce peut attaquer le roi dans cette direction, false sinon
     */
    public boolean quipeutAttaquerRoi(Piece attaquant, String direction, Cases roi, Cases positionPiece, Cases depart){
        switch(direction){
            case "nord":
                //tour,reigne
                if(attaquant.getClass() == Tour.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            case "nordEst":
                //fou, pion, reine
                if(attaquant.getClass() == Pion.class){
                    //c'est un pion donc faut que il eest audessu du roi
                    if((attaqueDuPion(attaquant.getCouleurPiece(),positionPiece.getIdCase(),positionPiece, roi,depart))){
                        //!attaqueduPion car la direstion c'est celle du roi pas du pion donc c'est inverser
                        return true; //le pion attaque le roi
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Fou.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else{
                    return false;
                }
            case "nordOuest":
                //fou, pion, reine
                if(attaquant.getClass() == Pion.class){
                    //c'est un pion donc faut que il y est audessu du roi
                    if((attaqueDuPion(attaquant.getCouleurPiece(),positionPiece.getIdCase(),positionPiece, roi,depart))){
                        //!attaqueduPion car la direstion c'est celle du roi pas du pion donc c'est inverser
                        //le pion attaque
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Fou.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else{
                    return false;
                }
            case "est":
                //tour, reigne
                if(attaquant.getClass() == Tour.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            case "ouest":
                //tour, reigne
                if(attaquant.getClass() == Tour.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            case "sud":
                //tour, reigne
                if(attaquant.getClass() == Tour.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acotes
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            case "sudEst":
                //fou, reine
                if(attaquant.getClass() == Fou.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Pion.class){
                    //c'est un pion donc faut que il y est audessu du roi
                    if((attaqueDuPion(attaquant.getCouleurPiece(),positionPiece.getIdCase(),positionPiece, roi,depart))){
                        //!attaqueduPion car la direstion c'est celle du roi pas du pion donc c'est inverser
                        //le pion attaque
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            case "sudOuest":
                //fou, reine
                if(attaquant.getClass() == Fou.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Pion.class){
                    //c'est un pion donc faut que il y est audessu du roi
                    if((attaqueDuPion(attaquant.getCouleurPiece(),positionPiece.getIdCase(),positionPiece, roi,depart))){
                        //!attaqueduPion car la direstion c'est celle du roi pas du pion donc c'est inverser
                        //le pion attaque
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            default:
                return false;
        }
    }
   /**
     * Corrige la direction pour les cas spéciaux du plateau à 3 joueurs.
     * Gère les anomalies de positionnement entre les cases I5-L5 et I9-L9.
     * 
     * @param depart la case de départ
     * @param arriver la case d'arrivée
     * @param direction la direction initiale
     * @return la direction corrigée si nécessaire
     */
    public String changeDirection(String depart, String arriver, String direction){
        switch(direction){
            case "sudEst":
                if ((depart == "J9" && arriver == "I5")||
                    (depart == "K9" && arriver == "J5")||
                    (depart == "L9" && arriver == "K5")||
                    (depart == "I5" && arriver =="J9")||
                    (depart == "J5" && arriver == "K9")||
                    (depart == "K5" && arriver == "L9")){
                    return "nordOuest";
                }
                else{
                    return direction;
                }
            case "sudOuest":
                if ((depart == "I9" && arriver == "J5")||
                    (depart == "J9" && arriver == "K5")||
                    (depart == "K9" && arriver == "L5")||
                    (depart == "J5" && arriver =="I9")||
                    (depart == "K5" && arriver == "J9")||
                    (depart == "L5" && arriver == "K9")) {
                    return "nordEst";
                }
                else{
                    return direction;
                }
            default:
                return direction;
        }
    }
    /**
     * Fonction récursive pour vérifier si le roi est en échec.
     * 
     * @param direction la direction à analyser
     * @param cases la case actuelle
     * @param caseRoi la case du roi
     * @param depart la case de depart avant récusiviter
     * @return true si le roi est en échec, false sinon
     */
    public boolean recurciviterDuRoiEchec(String direction, Cases cases, Cases caseRoi,Cases depart){
        if(cases == null){
            return false; //hors du plateau
        }

        //on prend le suivant
        //System.out.println(direction+" "+cases.getIdCase());
        Cases nouvelleCase = getCaseSuivante(direction, cases);
        if(nouvelleCase ==null){
            return false;//rien trouver donc pas echec
        }
        else if(nouvelleCase.getPiece() != null){
            //on a un pion faut voir si c'est le notre ou pas
            if(nouvelleCase.getPiece().getCouleurPiece() == caseRoi.getPiece().getCouleurPiece()){
                //ces notre pion plus besoin de regarder si attaquer dans cette direction
                return false;
            }
            else{
                //c'es un ennemi
                if(quipeutAttaquerRoi(nouvelleCase.getPiece(), direction, caseRoi, nouvelleCase,depart)){
                    System.out.println(" attaquer");
                    return true;
                }
                else{
                    return false;
                }
            }
        }
        else{
            //on peut continuer
            //on regarde si on est pas dans le cas où on a pas put mettre de lien sudest et sud ouest
            direction = changeDirection(cases.getIdCase(), nouvelleCase.getIdCase(), direction);
            return recurciviterDuRoiEchec(direction, nouvelleCase,caseRoi,depart);
        }
    }
   
    /**
     * Vérifie si le roi est en échec.
     * 
     * @param cases la case actuelle
     * @param caseRoi la case du roi
     * @return true si le roi est en échec, false sinon
     */
    public boolean roiEnEchec(Cases cases, Cases caseRoi){
        if(recurciviterDuRoiEchec("nord", cases,caseRoi,cases) ||
            recurciviterDuRoiEchec("sud", cases,caseRoi, cases) ||
            recurciviterDuRoiEchec("sudEst", cases,caseRoi,cases) ||
            recurciviterDuRoiEchec("sudOuest", cases,caseRoi,cases) ||
            recurciviterDuRoiEchec("nordEst", cases,caseRoi,cases) ||
            recurciviterDuRoiEchec("nordOuest", cases,caseRoi, cases) ||
            recurciviterDuRoiEchec("est", cases,caseRoi,cases) ||
            recurciviterDuRoiEchec("ouest", cases,caseRoi,cases) 
            ){
            return true;
        }//verifier pour le cavalier car cas special sur comment il attaque
        if(attaquerParCavalier(cases, caseRoi.getPiece())){
            return true;
        }
        else{
            return false;
        }
        
    }
    /**
     * Vérifie si une case est attaquée par un cavalier ennemi.
     * Analyse les 8 positions possibles d'attaque du cavalier.
     * 
     * @param cases la case à vérifier
     * @param notrePiece notre pièce pour déterminer les ennemis
     * @return true si la case est attaquée par un cavalier, false sinon
     */
    public boolean attaquerParCavalier(Cases cases, Piece notrePiece){
        if(cases == null){//hors du plateau
            return false;
        }
        Cases casesEntreDeux = null;
        boolean caseAttaquer = false;
        if(cases.getNord() !=null){
            //on peut regarder la case suivante
            if(cases.getNord().getNord() !=null){
                casesEntreDeux = cases.getNord().getNord();
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getOuest() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getOuest().getPiece() !=null){
                        if(casesEntreDeux.getOuest().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getOuest().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = true;
                        }
                    }
                }
                if(casesEntreDeux.getEst() != null){
                    if(casesEntreDeux.getEst() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getEst().getPiece() !=null){
                            if(casesEntreDeux.getEst().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getEst().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = true;
                            }
                        }
                    }
                }
            }
        }
        if(cases.getSud()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getSud().getSud();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getOuest() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getOuest().getPiece() !=null){
                        if(casesEntreDeux.getOuest().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getOuest().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = true;
                        }
                    }
                }
                if(casesEntreDeux.getEst() != null){
                    if(casesEntreDeux.getEst() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getEst().getPiece() !=null){
                            if(casesEntreDeux.getEst().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getEst().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = true;
                            }
                        }
                    }
                }
            }
        }
        //nord sud case possible
        if(cases.getEst()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getEst().getEst();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getNord() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getNord().getPiece() !=null){
                        if(casesEntreDeux.getNord().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getNord().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = true;
                        }
                    }
                }
                if(casesEntreDeux.getSud() != null){
                    if(casesEntreDeux.getSud() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getSud().getPiece() !=null){
                            if(casesEntreDeux.getSud().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getSud().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = true;
                            }
                        }
                    }
                }
            }
        }
        if(cases.getOuest()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getOuest().getOuest();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getNord() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getNord().getPiece() !=null){
                        if(casesEntreDeux.getNord().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getNord().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = true;
                        }
                    }
                }
                if(casesEntreDeux.getSud() != null){
                    if(casesEntreDeux.getSud() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getSud().getPiece() !=null){
                            if(casesEntreDeux.getSud().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getSud().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = true;
                            }
                        }
                    }
                }
            }
        }
        return caseAttaquer;
    }
}
