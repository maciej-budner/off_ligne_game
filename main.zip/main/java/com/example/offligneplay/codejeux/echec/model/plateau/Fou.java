package com.example.offligneplay.codejeux.echec.model.plateau;

public class Fou extends Piece {
    public Fou() {
        super();
    }
    public Fou(String couleur, int point) {
        super(couleur, point);
    }

    @Override
    public String deplacement() {
        return "diagonal";
    }
    
}
