package com.example.offligneplay.codejeux.echec.vue

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.offligneplay.MainActivity
import com.example.offligneplay.codejeux.echec.vue.PlateauEchec
import com.example.offligneplay.databinding.ActivityAccueilEchecBinding

class AccueilEchec : AppCompatActivity() {
    private lateinit var ui: ActivityAccueilEchecBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ui = ActivityAccueilEchecBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(ui.root)

        // Masquer la barre de statut (status bar) et la barre de navigation
        val decorView = window.decorView
        val uiOptions =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        decorView.systemUiVisibility = uiOptions


        ui.deuxjoueur.setOnClickListener {
            val demarJeux = Intent(this, PlateauEchec::class.java)
            demarJeux.putExtra("NB_JOUEURS", 2)
            demarJeux.putExtra("NB_IA", 0)
            startActivity(demarJeux)
        }

        ui.unjoueur.setOnClickListener {
            val demarJeux = Intent(this, PlateauEchec::class.java)
            demarJeux.putExtra("NB_JOUEURS", 1)
            demarJeux.putExtra("NB_IA", 1)
            startActivity(demarJeux)
        }
        ui.sorti.setOnClickListener{
            val mainMenu = Intent(this, MainActivity::class.java)
            startActivity(mainMenu)
            finish()
        }

    }
}