package com.example.offligneplay.codejeux.echec.vue

import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.offligneplay.codejeux.echec.controler.ClickEvent
import com.example.offligneplay.databinding.ActivityPlateauYaltaBinding

class PlateauEchec : AppCompatActivity() {

    private lateinit var ui: ActivityPlateauYaltaBinding
    private val mesBoutons = HashMap<String, CasePolygonView>()
    private lateinit var tourJoueur: TextView
    private lateinit var jeuRoot: ConstraintLayout
    private lateinit var clickEvent : ClickEvent
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivityPlateauYaltaBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(ui.root)

        // Masquer la barre de statut (status bar) et la barre de navigation
        val decorView = window.decorView
        val uiOptions =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        decorView.systemUiVisibility = uiOptions

        //jeux
        jeuRoot = ui.main
        tourJoueur = ui.statutJeuLabel
        Log.d("debug","Extra:${intent.extras}")
        var nbplayeur = intent.getIntExtra("NB_JOUEURS",3)
        var nbIA = intent.getIntExtra("NB_IA",0)
        Log.d("debug", "extrait:nbj=${nbplayeur}, nbIa=${nbIA}")
        this.clickEvent = ClickEvent(nbplayeur,nbIA, this)

        creerPlateau()

        //ecouteur
        ui.sorti.setOnClickListener {
            val accueil = Intent(this, AccueilEchec::class.java)
            startActivity(accueil)
            finish()
        }

    }

    private fun ajouterTexte(valeur: String, x: Float, y: Float) {
        val tv = TextView(this).apply {
            text = valeur
            textSize = 14f
            setTextColor(Color.DKGRAY)
            translationX = x - 15f // Ajustement pour centrer le texte sur son propre axe
            translationY = y - 20f
        }
        jeuRoot.addView(tv)
    }

    private fun creerPlateau(){
        //visieul
        val idCases = arrayOf(
                "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8",
                "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8",
                "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8",
                "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8",
                "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8",
                "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8",
                "G1", "G2", "G3", "G4", "G5", "G6", "G7", "G8",
                "H1", "H2", "H3", "H4", "H5", "H6", "H7", "H8"
        )

        val couleurBouton = arrayOf(
            "black","white","black","white","black","white","black","white",
            "white","black","white","black","white","black","white","black",
            "black","white","black","white","black","white","black","white",
            "white","black","white","black","white","black","white","black",
            "black","white","black","white","black","white","black","white",
            "white","black","white","black","white","black","white","black",
            "black","white","black","white","black","white","black","white",
            "white","black","white","black","white","black","white","black"
        )

        // Tes coordonnées JavaFX (X, Y) d'origine
        val coordonnesBouton = arrayOf(
            // A1 à A8
            doubleArrayOf(-132.0, 242.0), doubleArrayOf(-132.0, 198.0), doubleArrayOf(-132.0, 154.0), doubleArrayOf(-132.0, 110.0),
            doubleArrayOf(-132.0, 66.0),  doubleArrayOf(-132.0, 22.0),  doubleArrayOf(-132.0, -22.0), doubleArrayOf(-132.0, -66.0),

            // B1 à B8
            doubleArrayOf(-88.0, 242.0),  doubleArrayOf(-88.0, 198.0),  doubleArrayOf(-88.0, 154.0),  doubleArrayOf(-88.0, 110.0),
            doubleArrayOf(-88.0, 66.0),   doubleArrayOf(-88.0, 22.0),   doubleArrayOf(-88.0, -22.0),  doubleArrayOf(-88.0, -66.0),

            // C1 à C8
            doubleArrayOf(-44.0, 242.0),  doubleArrayOf(-44.0, 198.0),  doubleArrayOf(-44.0, 154.0),  doubleArrayOf(-44.0, 110.0),
            doubleArrayOf(-44.0, 66.0),   doubleArrayOf(-44.0, 22.0),   doubleArrayOf(-44.0, -22.0),  doubleArrayOf(-44.0, -66.0),

            // D1 à D8
            doubleArrayOf(0.0, 242.0),    doubleArrayOf(0.0, 198.0),    doubleArrayOf(0.0, 154.0),    doubleArrayOf(0.0, 110.0),
            doubleArrayOf(0.0, 66.0),     doubleArrayOf(0.0, 22.0),     doubleArrayOf(0.0, -22.0),    doubleArrayOf(0.0, -66.0),

            // E1 à E8
            doubleArrayOf(44.0, 242.0),   doubleArrayOf(44.0, 198.0),   doubleArrayOf(44.0, 154.0),   doubleArrayOf(44.0, 110.0),
            doubleArrayOf(44.0, 66.0),    doubleArrayOf(44.0, 22.0),    doubleArrayOf(44.0, -22.0),   doubleArrayOf(44.0, -66.0),

            // F1 à F8
            doubleArrayOf(88.0, 242.0),   doubleArrayOf(88.0, 198.0),   doubleArrayOf(88.0, 154.0),   doubleArrayOf(88.0, 110.0),
            doubleArrayOf(88.0, 66.0),    doubleArrayOf(88.0, 22.0),    doubleArrayOf(88.0, -22.0),   doubleArrayOf(88.0, -66.0),

            // G1 à G8
            doubleArrayOf(132.0, 242.0),  doubleArrayOf(132.0, 198.0),  doubleArrayOf(132.0, 154.0),  doubleArrayOf(132.0, 110.0),
            doubleArrayOf(132.0, 66.0),   doubleArrayOf(132.0, 22.0),   doubleArrayOf(132.0, -22.0),  doubleArrayOf(132.0, -66.0),

            // H1 à H8
            doubleArrayOf(176.0, 242.0),  doubleArrayOf(176.0, 198.0),  doubleArrayOf(176.0, 154.0),  doubleArrayOf(176.0, 110.0),
            doubleArrayOf(176.0, 66.0),   doubleArrayOf(176.0, 22.0),   doubleArrayOf(176.0, -22.0),  doubleArrayOf(176.0, -66.0)
        )



        val xOffset = 500f
        val yOffset = 1000f
        val echelle = 2.5f

        // 1. Génération des 96 boutons du plateau
        for (i in 0 until 64) {
            val caseId = idCases[i]
            val couleur = if (couleurBouton[i] == "black") Color.BLACK else Color.WHITE

            val demiTaille = 19.0f // Taille réduite pour laisser de la place au halo/glow

            // 1. Récupération et application de l'échelle + décalage d'écran
            val cx = (coordonnesBouton[i][0].toFloat() * echelle) + xOffset
            val cy = (coordonnesBouton[i][1].toFloat() * echelle) + yOffset
            val tailleAgrandie = demiTaille * echelle

            // 2. Construction des 4 coins ajustés au centre de l'écran
            val pointsPolygone = floatArrayOf(
                cx - tailleAgrandie, cy - tailleAgrandie, // Haut-Gauche
                cx + tailleAgrandie, cy - tailleAgrandie, // Haut-Droite
                cx + tailleAgrandie, cy + tailleAgrandie, // Bas-Droite
                cx - tailleAgrandie, cy + tailleAgrandie  // Bas-Gauche
            )

            val casePolygon = CasePolygonView(this, caseId, couleur, pointsPolygone) { id ->
                clickButton(id)
            }

            val layoutParams = ConstraintLayout.LayoutParams(
                ConstraintLayout.LayoutParams.MATCH_PARENT,
                ConstraintLayout.LayoutParams.MATCH_PARENT
            )
            casePolygon.layoutParams = layoutParams

            jeuRoot.addView(casePolygon)
            mesBoutons[caseId] = casePolygon

            val centerX = (pointsPolygone[0] + pointsPolygone[2] + pointsPolygone[4] + pointsPolygone[6]) / 4
            val centerY = (pointsPolygone[1] + pointsPolygone[3] + pointsPolygone[5] + pointsPolygone[7]) / 4

            val lettre = caseId.first().toString()
            val chiffre = caseId.substring(1)

            // ==========================================
            // 1. LES LETTRES (Bords extérieurs horizontaux/obliques)
            // ==========================================

            // En bas (Vert)
            if (chiffre == "1" && (lettre in "A".."H")) {
                ajouterTexte(lettre, centerX, centerY + 80f)
            }

            // en haut Red
            if (chiffre == "8" && (lettre in "A".."H")) {
                // Décalage vers le haut et légèrement à gauche
                ajouterTexte(lettre, centerX, centerY - 80f)
            }

            // placer chiffre a coté de A
            if (lettre == "A") {
                // Décalage vers le haut et légèrement à gauche5
                ajouterTexte(chiffre, centerX - 70f, centerY)
            }

            // placer chiffre a coté de H
            if (lettre == "H") {
                // Décalage vers le haut et légèrement à droite
                ajouterTexte(chiffre, centerX + 70f, centerY )
            }

        }

        // 2. Placement des pièces initiales (Pions et figures)
        val piecesInitiales: Array<Array<String>> = arrayOf(
            arrayOf("♜", "♞", "♝", "♛", "♚", "♝", "♞", "♜"), // Ligne index 0[cite: 1]
            arrayOf("♟", "♟", "♟", "♟", "♟", "♟", "♟", "♟")  // Ligne index 1[cite: 1]
        )

        val positionPiece = arrayOf(
            arrayOf("A1","B1","C1","D1","E1","F1","G1","H1"), // Vert (Bas)
            arrayOf("A2","B2","C2","D2","E2","F2","G2","H2"),
            arrayOf("A8","B8","C8","D8","E8","F8","G8","H8"), // Rouge
            arrayOf("A7","B7","C7","D7","E7","F7","G7","H7"),

        )

        val couleursJoueurs = arrayOf(Color.GREEN, Color.RED)

        // Distribution des pièces Unicode sur les boutons stockés
        for (i in 0 until 4 step 2) {
            val indexCouleur = i / 2
            val couleurCourante = couleursJoueurs[indexCouleur]

            for (j in 0 until 8) {
                // Pièces spéciales
                mesBoutons[positionPiece[i][j]]?.apply {
                    textePiece = piecesInitiales[0][j]
                    couleurPiece = couleurCourante
                    invalidate() // Force le rafraîchissement du dessin
                }

                // Pions
                mesBoutons[positionPiece[i + 1][j]]?.apply {
                    textePiece = piecesInitiales[1][j]
                    couleurPiece = couleurCourante
                    invalidate()
                }
            }
        }
    }

    private fun clickButton(caseChoisie: String) {
        Log.d("JEU", "Case cliquée : $caseChoisie")
        // Ici tu feras appel à ton : clickEvent.eventApuisCase(mesBoutons, caseChoisie, statutLabel)
        this.clickEvent.eventApuisCase(this.mesBoutons, caseChoisie)
    }

    fun changeText(text: String){
        ui.statutJeuLabel.text = text
    }

    interface PromotionCallback {
        fun onPieceChoisie(unicodePiece: String?)
    }

    fun demandePromotion(callback: PromotionCallback) {
        // Ordre des pièces : Tour ♜, Cavalier ♞, Fou ♝, Dame ♛
        val optionsTexte = arrayOf<String?>("Dame (♛)", "Tour (♜)", "Fou (♝)", "Cavalier (♞)")
        val unicodePieces = arrayOf<String>("\u265B", "\u265C", "\u265D", "\u265E")

        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Promotion du Pion 👑")
        builder.setMessage("Félicitations ! Choisissez la pièce de promotion :")


        // Empêche le joueur de fermer le dialogue en cliquant à côté sans choisir
        builder.setCancelable(false)

        builder.setItems(optionsTexte, object : DialogInterface.OnClickListener {
            override fun onClick(dialog: DialogInterface?, which: Int) {
                val pieceChoisie = unicodePieces[which]
                // On déclenche le callback avec la pièce choisie
                callback.onPieceChoisie(pieceChoisie)
            }
        })

        builder.show()
    }
    fun finDePartie(message: String?, nbJoueurs: Int, nbIA: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Fin de partie 🏆")
        builder.setMessage(message + "\nQue voulez-vous faire ?")
        builder.setCancelable(false) // Bloque le clic en dehors pour obliger un choix

        // 1. Bouton "Rejouer"
        builder.setPositiveButton("Rejouer", object : DialogInterface.OnClickListener {
            override fun onClick(dialog: DialogInterface?, which: Int) {
                // Relance la même Activity avec les paramètres de joueurs
                val intent = Intent(this@PlateauEchec, PlateauEchec::class.java)
                intent.putExtra("NB_JOUEURS", nbJoueurs)
                intent.putExtra("NB_IA", nbIA)
                startActivity(intent)
                finish() // Ferme la partie actuelle
            }
        })

        // 2. Bouton "Revenir au menu"
        builder.setNegativeButton("Revenir au menu", object : DialogInterface.OnClickListener {
            override fun onClick(dialog: DialogInterface?, which: Int) {
                // Ouvre le menu principal (ex: MenuActivity)
                val intent: Intent = Intent(
                    this@PlateauEchec,
                    AccueilEchec::class.java
                ) // Remplace par le nom de ton Activity Menu
                startActivity(intent)
                finish() // Ferme la partie actuelle
            }
        })

        builder.show()
    }
}