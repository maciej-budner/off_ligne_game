package com.example.offligneplay.codejeux.echec.model.apui;
import android.widget.Button;

import com.example.offligneplay.codejeux.echec.model.plateau.*;
import com.example.offligneplay.codejeux.echec.vue.CasePolygonView;

import java.util.HashMap;

/**
 * Interface Mouvement définissant le contrat pour les mouvements des pièces.
 * Permet d'implémenter différents types de mouvements (déplacement normal, roque, etc.).
 * 
 * @author Maciej Budner
 */
public interface Mouvement {
    /**
     * Exécute un mouvement de pièce sur le plateau.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param laCaseVoulue l'identifiant de la case de destination
     * @param cases la case de départ
     * @param cases2 la case de destination
     */
    public void mouvement(HashMap<String, CasePolygonView> mesBouton, String laCaseVoulue, Cases cases, Cases cases2);
}
