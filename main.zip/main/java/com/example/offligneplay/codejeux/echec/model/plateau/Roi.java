package com.example.offligneplay.codejeux.echec.model.plateau;

public class Roi extends Piece {
    public Roi() {
        super();
    }
    public Roi(String couleur, int point) {
        super(couleur, point);
    }

    @Override
    public String deplacement() {
        return "autour";
    }
    
}
