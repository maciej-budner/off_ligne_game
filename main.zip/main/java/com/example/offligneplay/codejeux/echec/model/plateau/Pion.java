package com.example.offligneplay.codejeux.echec.model.plateau;

public class Pion extends Piece {
    
    private boolean coupPassantPossible;
    public Pion() {
        super();
    }
    public Pion(String couleur, int point) {
        super(couleur, point);
    }

    @Override
    public String deplacement() {
        return "1caseAvant";
    }
    
    
}
