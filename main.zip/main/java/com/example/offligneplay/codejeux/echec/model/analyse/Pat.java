package com.example.offligneplay.codejeux.echec.model.analyse;

import java.util.HashSet;
import com.example.offligneplay.codejeux.echec.model.plateau.*;

/**
 * La classe Pat représente l'état de pat dans une partie d'échecs.
 * Elle gère la détection des situations de pat où le joueur n'a plus de coups légaux
 * mais son roi n'est pas en échec.
 * 
 * @author Développeur du projet
 * @version 1.0
 */
public class Pat extends AnalysePartie{
    /**
     * Constructeur par défaut de la classe Pat.
     * Initialise une liste vide de coups possibles.
     */
    public Pat(){
        super();
    }
    
    /**
     * Constructeur de la classe Pat avec une liste de coups existante.
     * 
     * @param coupPossible l'ensemble des coups possibles à initialiser
     */
    public Pat(HashSet<String> coupPossible){
        super(coupPossible);
    }
    
    /**
     * Vérifie si le roi peut bouger sans être en échec.
     * 
     * @param cases la case de départ
     * @param casesRoi la case du roi
     * @return true si le roi peut bouger, false sinon
     */
    public boolean bougerRoi(Cases cases, Cases casesRoi){
        if(cases == null){//en est dehord du tableau
            return false;
        }
        if(!(roiEnEchec(cases.getNord(),casesRoi)) && cases.getNord() !=null){
            this.addInList(cases.getNord().getIdCase());
            return true;
        }
        if(!(roiEnEchec(cases.getSud(),casesRoi))&& cases.getSud() !=null){
            this.addInList(cases.getSud().getIdCase());
            return true;
        }
        if(!(roiEnEchec(cases.getEst(),casesRoi))&& cases.getEst() !=null){
            this.addInList(cases.getEst().getIdCase());
            return true;
        }
        if(!(roiEnEchec(cases.getOuest(),casesRoi))&& cases.getOuest() !=null){
            this.addInList(cases.getOuest().getIdCase());
            return true;
        }
        if(!(roiEnEchec(cases.getNordEst(),casesRoi))&& cases.getNordEst() !=null){
            this.addInList(cases.getNordEst().getIdCase());
            return true;
        }
        if(!(roiEnEchec(cases.getNordOuest(),casesRoi))&& cases.getNordOuest() !=null){
            this.addInList(cases.getNordOuest().getIdCase());
            return true;
        }
        if(!(roiEnEchec(cases.getSudEst(),casesRoi))&& cases.getSudEst() !=null){
            this.addInList(cases.getSudEst().getIdCase());
            return true;
        }
        if(!(roiEnEchec(cases.getSudOuest(),casesRoi))&& cases.getSudOuest() !=null){
            this.addInList(cases.getSudOuest().getIdCase());
            return true;
        }
        return false;
    }

    //TODO: verifier si sa le met pas en echec si on le bouge
    
    /**
     * Vérifie si une pièce peut bouger dans une direction donnée.
     * 
     * @param direction la direction d'analyse
     * @param cases la case actuelle
     * @param piece la pièce à vérifier
     * @return true si la pièce peut bouger, false sinon
     */
    public boolean peutBouger(String direction, Cases cases,Piece piece){
        switch(direction){
            case "nord":
                if(piece.getClass() == Tour.class ||
                    piece.getClass() == Reine.class){
                        return true;//il peuvent bouger
                }
                else if(piece.getClass() == Pion.class){
                    //verifi que on parle du bon
                    String ecouteur = "";
                    ecouteur = ecouteur.copyValueOf(cases.getIdCase().toCharArray(), 1, cases.getIdCase().length()-1);
                    if(piece.getCouleurPiece() == "green"){
                        if(onDeplacePionHaut(cases.getIdCase()) && Integer.parseInt(ecouteur) >8){
                            return false;//il va au sud
                        }
                        else if(cases.getPiece() != null){
                            return false;
                        }
                        else{
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                    }
                    else if(piece.getCouleurPiece() == "red"){
                        if(onDeplacePionHaut(cases.getIdCase()) && cases.getPiece() == null){
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                        else{
                            return false;//il y a que la moitier qui se deplace au nord
                        }
                    }
                    else{
                        
                        if(bleuDansCasEaH(cases.getIdCase()) && cases.getPiece() == null){
                            this.addInList(cases.getIdCase());
                            return true;//il va au nord
                        }
                        else{
                            return false;
                        }
                    
                    }
                }
                else{
                    return false;
                }
            case "nordEst":
                if(piece.getClass() == Fou.class ||
                    piece.getClass() == Reine.class){
                        return true;//il peuvent bouger
                }
                else if(piece.getClass() == Pion.class){
                    //verifi que on parle du bon
                    String ecouteur = "";
                    ecouteur = ecouteur.copyValueOf(cases.getIdCase().toCharArray(), 1, cases.getIdCase().length()-1);
                    if(piece.getCouleurPiece() == "green"){
                        if(onDeplacePionHaut(cases.getIdCase()) && Integer.parseInt(ecouteur) >8){
                            return false;//il va au sud
                        }
                        else if(cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                        else{
                            return false;
                        }
                    }
                    else if(piece.getCouleurPiece() == "red"){
                        if(onDeplacePionHaut(cases.getIdCase()) && cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                        else{
                            return false;//il y a que la moitier qui se deplace au nord
                        }
                    }
                    else{
                        if(bleuDansCasEaH(cases.getIdCase()) && cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;//il va au nord
                        }
                        else{
                            return false;
                        }
                    
                    }
                }
                else{
                    return false;
                }
            case "nordOuest":
                if(piece.getClass() == Fou.class ||
                    piece.getClass() == Reine.class){
                        return true;//il peuvent bouger
                }
                else if(piece.getClass() == Pion.class){
                    //verifi que on parle du bon
                    String ecouteur = "";
                    ecouteur = ecouteur.copyValueOf(cases.getIdCase().toCharArray(), 1, cases.getIdCase().length()-1);
                    if(piece.getCouleurPiece() == "green"){
                        if(onDeplacePionHaut(cases.getIdCase()) && Integer.parseInt(ecouteur) >8){
                            return false;//il va au sud
                        }
                        else if(cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                        else{
                            return false;
                        }
                    }
                    else if(piece.getCouleurPiece() == "red"){
                        if(onDeplacePionHaut(cases.getIdCase()) && cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                        else{
                            return false;//il y a que la moitier qui se deplace au nord
                        }
                    }
                    else{
                        if(bleuDansCasEaH(cases.getIdCase()) && cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;//il va au nord
                        }
                        else{
                            return false;
                        }
                    
                    }
                }
                else{
                    return false;
                }
            case "est":
                if(piece.getClass() == Tour.class ||
                    piece.getClass() == Reine.class){
                        return true;//il peuvent bouger
                }
                else{
                    return false;
                }
            case "ouest":
                if(piece.getClass() == Tour.class ||
                    piece.getClass() == Reine.class){
                        return true;//il peuvent bouger
                }
                else{
                    return false;
                }
            case "sud":
                if(piece.getClass() == Tour.class ||
                    piece.getClass() == Reine.class){
                        return true;//il peuvent bouger
                }
                else if(piece.getClass() == Pion.class){
                    //verifi que on parle du bon
                    String ecouteur = "";
                    ecouteur = ecouteur.copyValueOf(cases.getIdCase().toCharArray(), 1, cases.getIdCase().length()-1);
                    if(piece.getCouleurPiece() == "green"){
                        if(onDeplacePionHaut(cases.getIdCase()) && Integer.parseInt(ecouteur) >8 && cases.getPiece() == null){
                            this.addInList(cases.getIdCase());
                            return true;//il va au sud
                        }
                        else{
                            return false;
                        }
                    }
                    else if(piece.getCouleurPiece() == "red"){
                        if(onDeplacePionHaut(cases.getIdCase()) ){
                            return false;//va au nord
                        }
                        else if(cases.getPiece() == null){
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                        else{
                            return false;//il y a que la moitier qui se deplace au nord
                        }
                    }
                    else{
                        if(bleuDansCasEaH(cases.getIdCase())){
                            return false;//il va au nord
                        }
                        else if(cases.getPiece() == null){
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                        else{
                            return false;
                        }
                    
                    }
                }
                else{
                    return false;
                }
            case "sudEst":
                if(piece.getClass() == Fou.class ||
                    piece.getClass() == Reine.class){
                        return true;//il peuvent bouger
                }
                else if(piece.getClass() == Pion.class){
                    //verifi que on parle du bon
                    String ecouteur = "";
                    ecouteur = ecouteur.copyValueOf(cases.getIdCase().toCharArray(), 1, cases.getIdCase().length()-1);
                    if(piece.getCouleurPiece() == "green"){
                        if(onDeplacePionHaut(cases.getIdCase()) && Integer.parseInt(ecouteur) >8 && cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;//il va au sud
                        }
                        else{
                            return false;
                        }
                    }
                    else if(piece.getCouleurPiece() == "red"){
                        if(onDeplacePionHaut(cases.getIdCase()) ){
                            return false;//va au nord
                        }
                        else if(cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                        else{
                            return false;//il y a que la moitier qui se deplace au nord
                        }
                    }
                    else{
                        if(bleuDansCasEaH(cases.getIdCase())){
                            return false;//il va au nord
                        }
                        else if(cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                        else{
                            return false;
                        }
                    
                    }
                }
                else{
                    return false;
                }
            case "sudOuest":
                if(piece.getClass() == Fou.class ||
                    piece.getClass() == Reine.class){
                        return true;//il peuvent bouger
                }
                else if(piece.getClass() == Pion.class){
                    //verifi que on parle du bon
                    String ecouteur = "";
                    ecouteur = ecouteur.copyValueOf(cases.getIdCase().toCharArray(), 1, cases.getIdCase().length()-1);
                    if(piece.getCouleurPiece() == "green"){
                        if(onDeplacePionHaut(cases.getIdCase()) && Integer.parseInt(ecouteur) >8 && cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;//il va au sud
                        }
                        else{
                            return false;
                        }
                    }
                    else if(piece.getCouleurPiece() == "red"){
                        if(onDeplacePionHaut(cases.getIdCase()) ){
                            return false;//va au nord
                        }
                        else if(cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                        else{
                            return false;//il y a que la moitier qui se deplace au nord
                        }
                    }
                    else{
                        if(bleuDansCasEaH(cases.getIdCase())){
                            return false;//il va au nord
                        }
                        else if(cases.getPiece() != null){
                            this.addInList(cases.getIdCase());
                            return true;
                        }
                        else{
                            return false;
                        }
                    
                    }
                }
                else{
                    return false;
                }
            default:
                return false;
        }
    }
    
    /**
     * Vérifie si une case autour d'une pièce peut être occupée.
     * 
     * @param direction la direction d'analyse
     * @param cases la case actuelle
     * @param notrPiece notre pièce pour déterminer les ennemis
     * @return true si la case peut être occupée, false sinon
     */
    public boolean verifiUneCaseAutour(String direction,Cases cases, Piece notrPiece){
        if(cases.getPiece() == null){
            //selon la piece on peut bouger ici
            return peutBouger(direction, cases,notrPiece);
        }
        else if(cases.getPiece() != null && cases.getPiece().getCouleurPiece() != notrPiece.getCouleurPiece()){
            return peutBouger(direction, cases, notrPiece);
        }
        else{
            return false;
        }
    }
    
    /**
     * Vérifie si les cases pour le cabalier sont libres.
     * 
     * @param coterGauche la direction du coté gauche
     * @param coterDroit la direction du coté droit
     * @param pion le pion à vérifier
     * @param cases la case actuelle
     * @return true si les cases sont libres, false sinon
     */
    public boolean regardeSiCaseLibreCavalier(String coterGauche, String coterDroit, Piece pion,Cases cases){
        Cases casesCoterGauche = getCaseSuivante(coterGauche, cases);
        Cases casesCoterDroite = getCaseSuivante(coterDroit, cases);

        //regarde si null ou si peut attacker
        if(casesCoterGauche != null){
            Piece piece = casesCoterGauche.getPiece();
            if(piece == null){
                //deplacement normal
                this.addInList(casesCoterGauche.getIdCase());
                return true;
            }
            else{
                //il y a un pion faut voir si c'est le notre
                if(piece.getCouleurPiece() != pion.getCouleurPiece()){
                    //c'est pas le notre on peut l'attaquer
                    this.addInList(casesCoterGauche.getIdCase());
                    return true;
                }
                //sinon peut peut meme pas se deplacer
                return false;
            }
        }
        if(casesCoterDroite != null){
            Piece piece = casesCoterDroite.getPiece();
            if(piece == null){
                //deplacement normal
                this.addInList(casesCoterDroite.getIdCase());
                return true;
            }
            else{
                //il y a un pion faut voir si c'est le notre
                if(piece.getCouleurPiece() != pion.getCouleurPiece()){
                    //c'est pas le notre on peut l'attaquer
                    this.addInList(casesCoterDroite.getIdCase());
                    return true;
                }
                //sinon peut peut meme pas se deplacer
                return false;
            }
        }
        //sinon on peut pas se deplacer
        return false;
    }
    
    /**
     * Gère les mouvements du cavalier.
     * 
     * @param pion la pièce à vérifier
     * @param cases la case actuelle
     * @return true si le cavalier peut bouger, false sinon
     */
    public boolean mouvementCavalier(Piece pion,Cases cases){
        //regarder 2 case nord, sud, est, ouest
        Cases casesEntreDeux =null;
        //est ouest case possible
        if(cases.getNord() !=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getNord().getNord();
            if(casesEntreDeux !=null){
                return regardeSiCaseLibreCavalier("ouest", "est", pion, casesEntreDeux);
            }
        }
        if(cases.getSud()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getSud().getSud();
            if(casesEntreDeux !=null){
                return regardeSiCaseLibreCavalier("ouest", "est",  pion, casesEntreDeux);
            }
        }
        //nord sud case possible
        if(cases.getEst()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getEst().getEst();
            if(casesEntreDeux !=null){
                return regardeSiCaseLibreCavalier("sud", "nord",  pion, casesEntreDeux);
            }
        }
        if(cases.getOuest()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getOuest().getOuest();
            if(casesEntreDeux !=null){
                return regardeSiCaseLibreCavalier("sud", "nord",  pion, casesEntreDeux);
            }
        }
        return false;
    }
    
    /**
     * Vérifie les mouvements autour d'une pièce.
     * 
     * @param cases la case actuelle
     * @param notrePiece notre pièce pour déterminer les ennemis
     * @param roi le roi à vérifier
     * @return true si la pièce peut bouger, false sinon
     */
    public boolean verifiAutourPiece(Cases cases,Piece notrePiece, Cases roi){
        boolean peutBouger = false;
        //regarde si on la bougean il y a pas un echec
        if(bougePionMiseEchecRoi(cases, roi)){
            return false;//echec si on bouge la case donc on ignore le rest
        }//sinon on regarde
        if(notrePiece.getClass() != Cavalier.class){
            if(verifiUneCaseAutour("est",cases.getEst(), notrePiece) ||
            verifiUneCaseAutour("ouest",cases.getOuest(), notrePiece) ||
            verifiUneCaseAutour("nord",cases.getNord(), notrePiece) ||
            verifiUneCaseAutour("nordEst",cases.getNordEst(), notrePiece) ||
            verifiUneCaseAutour("nordOuest",cases.getNordOuest(), notrePiece)||
            verifiUneCaseAutour("sud",cases.getSud(), notrePiece)||
            verifiUneCaseAutour("sudEst",cases.getSudEst(), notrePiece)||
            verifiUneCaseAutour("sudOuest",cases.getSudOuest(), notrePiece)){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            //me cavelier bouge autrement
            return mouvementCavalier(notrePiece, cases);
        }
    }

    /**
     * Vérifie si une pièce peut bouger dans une direction donnée.
     * 
     * @param direction la direction d'analyse
     * @param casesPiece la case de la pièce
     * @param notrePiece notre pièce pour déterminer les ennemis
     * @param roi le roi à vérifier
     * @return true si la pièce peut bouger, false sinon
     */
    public boolean verifieSiUnePiecePeuBouger(String direction, Cases casesPiece, Piece notrePiece, Cases roi){
        Cases nouvelleCase = getCaseSuivante(direction, casesPiece);
        if(nouvelleCase == null){
            return false;
        }
        else if(nouvelleCase.getPiece().getCouleurPiece() == notrePiece.getCouleurPiece()){
            return verifiAutourPiece(nouvelleCase, notrePiece, roi);
        }
        else{
            return verifieSiUnePiecePeuBouger(direction, nouvelleCase, notrePiece, roi);
        }

    }

    /**
     * Vérifie si le roi peut plus bouger.
     * 
     * @param roi le roi à vérifier
     * @return true si le roi peut plus bouger, false sinon
     */
    public boolean peutPlusBouger(Cases roi){
        boolean peutbouger =false;
        if(bougerRoi(roi, roi)){
            peutbouger = true;
        }
        Cases nouvelleCase = roi;
        while(nouvelleCase != null && peutbouger == false){
            nouvelleCase = roi.getEst();
            if(verifieSiUnePiecePeuBouger("nord", nouvelleCase, roi.getPiece(), roi)||
                verifieSiUnePiecePeuBouger("sud", nouvelleCase, roi.getPiece(), roi)){
                return true;
             }
        }
        while(nouvelleCase != null && peutbouger == false){
            nouvelleCase = roi.getOuest();
            if(verifieSiUnePiecePeuBouger("nord", nouvelleCase, roi.getPiece(), roi)||
                verifieSiUnePiecePeuBouger("sud", nouvelleCase, roi.getPiece(), roi)){
                return true;
             }
        }
        //si on est pas sortie c'est que on a rien trouver donc pat
        return false;
    }

    //verifi si il peut peut bouger une piece
    /**
     * Vérifie l'état du jeu et retourne l'état de pat.

     * @param casesRoi la case contenant le roi
     * @return 3 pour indiquer que la situation est un pat
     */
    public int verificationEtatDuJeux( Cases casesRoi){
        if(peutPlusBouger(casesRoi)){
            //on peut plus bouger
            return 3;
        }
        else{
            //sinon il y a rien mais rest en echec
            return 0;
        }
    }

    //change le State pour verifier d'autre possibiliter
    /**
     * Change l'état d'analyse en fonction de l'état du jeu.
     * Retourne à l'état Echec pour continuer l'analyse.
     *
     * @return une nouvelle instance d'Echec
     */
    public AnalysePartie changeState(int etatJeux){
        if(this.listVide() && etatJeux == 0){
            //il est path c'est qui ne peut plus vraiment bouger
            return new EchecMat(this.getCoupPossible());
        }
        else{
            //sinon il y a rien on peut continuer a jouer
            return new Rien(this.getCoupPossible());
        }
        
    }
}
