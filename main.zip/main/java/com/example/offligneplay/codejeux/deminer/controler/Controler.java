package com.example.offligneplay.codejeux.deminer.controler;

import com.example.offligneplay.codejeux.deminer.model.AnalyseCoup;
import com.example.offligneplay.codejeux.deminer.vue.PlateauDeminer;
import com.example.offligneplay.codejeux.deminer.vue.CasePolygonView;

import java.util.HashMap;

public class Controler {
    private AnalyseCoup analysePartie;
    private static PlateauDeminer plateauVisuel;
    public Controler(int nbLigne, int nbCologne, PlateauDeminer plateau){
        this.analysePartie = new AnalyseCoup(nbLigne, nbCologne);
        this.plateauVisuel = plateau;
    }

    public void creuser(String cases, HashMap<String, CasePolygonView> jeuxVisuel){
        this.analysePartie.creuser(cases,  jeuxVisuel);
    }
    public void poserDrapeau(String cases, HashMap<String, CasePolygonView> jeuxVisuel){
        this.analysePartie.poserDrapeau(cases,  jeuxVisuel);
    }
    public static void finDePartie(String message){
        plateauVisuel.finDePartie(message);
    }
}
