package com.example.offligneplay.codejeux.deminer.model;

public abstract class Etat {

    public abstract Etat analyse(Plateau plateauJeux, Plateau plateauIndice);

    public abstract Etat changeEtat();
}
