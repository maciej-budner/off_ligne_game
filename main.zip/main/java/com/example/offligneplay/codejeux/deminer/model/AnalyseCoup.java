package com.example.offligneplay.codejeux.deminer.model;

import android.graphics.Color;
import android.util.Log;

import com.example.offligneplay.codejeux.deminer.controler.Controler;
import com.example.offligneplay.codejeux.deminer.vue.CasePolygonView;

import java.util.HashMap;

public class AnalyseCoup {
    private Plateau plateauIndice;
    private Plateau plateauJeux;
    private Etat etatJeux;
    private int[] couleurMap;

    public AnalyseCoup(){
        this.plateauIndice = null;
        this.plateauJeux = null;
        this.etatJeux = null;
        this.couleurMap = null;
    }
    public AnalyseCoup(int nbligne, int nbCologne){
        this.plateauIndice = new Plateau(nbligne, nbCologne);
        this.plateauJeux = new Plateau(nbligne, nbCologne);
        this.plateauJeux.inisialiserPlateauJeux();
        this.plateauIndice.inisialiserPlateauJeux();
        this.plateauIndice.placerBombe();
        this.plateauIndice.indiceBombeAutour();
        this.etatJeux =new Neutre();

        this.couleurMap = new int[]{Color.WHITE, Color.CYAN, Color.BLUE, Color.GREEN, Color.BLACK, Color.RED, Color.MAGENTA, Color.YELLOW};
    }

    /**
     * affiche dans le plateau du jeux du joueur les indice sur les bambe
     * @param ligne la ligne que on affiche
     * @param cologne la cologne que on affiche
     * @param boutanVisuel les bouton de notre visuel
     */
    public void afficherIndice(int ligne, int cologne, HashMap<String, CasePolygonView> boutanVisuel) {
        int nbLigne = this.plateauIndice.getNbLigne();
        int nbCologne = this.plateauIndice.getNbCologne();

        if (ligne < 0 || ligne >= nbLigne || cologne < 0 || cologne >= nbCologne) {
            return;
        }

        if (!this.plateauJeux.getCase(ligne, cologne).equals("")) {
            return;
        }
        int idCase = (cologne * nbLigne) + ligne + 1;
        String cases = String.valueOf(idCase);
        CasePolygonView visuel = boutanVisuel.get(cases);

        String contenuCase = this.plateauIndice.getCase(ligne, cologne);

        this.plateauJeux.setCasePlateau(ligne, cologne, this.plateauIndice);

        if (contenuCase.equals("B")) {
            // Bombe
            if (visuel != null) {
                visuel.deplacementPiece("\uD83D\uDCA3", Color.RED);
            }
        } else if (!contenuCase.equals("0")) {
            if (visuel != null) {
                int val = Integer.parseInt(contenuCase);
                visuel.deplacementPiece(contenuCase, this.couleurMap[val]);
            }
        } else {
            if (visuel != null) {
                visuel.deplacementPiece(contenuCase, this.couleurMap[0]);
            }

            afficherIndice(ligne + 1, cologne, boutanVisuel);
            afficherIndice(ligne + 1, cologne - 1, boutanVisuel);
            afficherIndice(ligne + 1, cologne + 1, boutanVisuel);
            afficherIndice(ligne, cologne - 1, boutanVisuel);
            afficherIndice(ligne, cologne + 1, boutanVisuel);
            afficherIndice(ligne - 1, cologne, boutanVisuel);
            afficherIndice(ligne - 1, cologne - 1, boutanVisuel);
            afficherIndice(ligne - 1, cologne + 1, boutanVisuel);
        }
    }
    /**
     * creuse sur le plateauJeux
     * @param caseCreuser la case choisie pour intéragire
     * @param boutanVisuel les bouton du joueur
     */
    public void creuser(String caseCreuser, HashMap<String, CasePolygonView> boutanVisuel){

        if(caseCreuser == ""){
            return; //si case non selectionner on fait rien
        }

        int numCase = Integer.parseInt(caseCreuser) -1;//la case 1 c'est la case 0 dans le tableau
        int nbCologne = numCase / this.plateauIndice.getNbLigne();
        int nbLigne = numCase% this.plateauIndice.getNbLigne();
        if(this.plateauJeux.getCase(nbLigne, nbCologne) != "" || this.plateauJeux.getCase(nbLigne, nbCologne) == "D"){
            return;//on creuse pas sur des case deja afficher
        }
        afficherIndice(nbLigne, nbCologne, boutanVisuel);
        analysePartie();
    }

    /**
     * on pose ou retire un drapeau de la cases
     * @param caseDrapeau la case voulue
     * @param boutanVisuel les bouton visuel du jeux
     */
    public void poserDrapeau(String caseDrapeau, HashMap<String, CasePolygonView> boutanVisuel){
        Log.d("test", "placerDrapeau");
        if(caseDrapeau.equals("")){
            Log.d("test", "null");
            return; //si case non selectionner on fait rien
        }
        int numCase = Integer.parseInt(caseDrapeau) -1;//la case 1 c'est la case 0 dans le tableau
        int nbCologne = numCase / this.plateauIndice.getNbLigne();
        int nbLigne = numCase% this.plateauIndice.getNbLigne();
        if( !this.plateauJeux.getCase(nbLigne, nbCologne).equals("D") && !this.plateauJeux.getCase(nbLigne, nbCologne).equals("") ){
            Log.d("test", "peut pas");
            return;//on met pas de drapeau sur des case deja afficher
        }

        //si il y a un drapeu on le retir sinon on le met
        if(this.plateauJeux.getCase(nbLigne, nbCologne).equals("D")){
            Log.d("test", "retirer Drapeau");
            this.plateauJeux.setText(nbLigne, nbCologne, "");
            CasePolygonView visuel = boutanVisuel.get(caseDrapeau);
            visuel.deplacementPiece("", Color.TRANSPARENT);
        }
        else {
            Log.d("test", "mitDrapeau");
            this.plateauJeux.setText(nbLigne, nbCologne, "D");
            CasePolygonView visuel = boutanVisuel.get(caseDrapeau);
            visuel.deplacementPiece("\uD83D\uDEA9", Color.CYAN);
        }
    }

    public void analysePartie(){
        this.etatJeux =  this.etatJeux.analyse(this.plateauJeux, this.plateauIndice);

        if(this.etatJeux.getClass() == Victoire.class){
            Controler.finDePartie("Vous avez gagner");
        }
        else if(this.etatJeux.getClass() == Defaite.class){
            Controler.finDePartie("Vous avez perdu");
        }
        //sinon on continuer de jouer
    }
}
