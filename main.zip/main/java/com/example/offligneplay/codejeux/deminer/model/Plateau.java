package com.example.offligneplay.codejeux.deminer.model;
import static java.lang.Math.random;


public class Plateau {
    private String[][] plateau;
    private int nbLigne;
    private int nbCologne;

    private int nbBombe;

    public Plateau(){
        this.plateau = new String[1][1];
        this.nbLigne = 1;
        this.nbCologne = 1;
        this.nbBombe = 0;
    }

    public Plateau(int nbLigne, int nbCologne){
        this.plateau = new String[nbLigne][nbCologne];
        this.nbLigne = nbLigne;
        this.nbCologne = nbCologne;
        this.nbBombe = 0;
    }

    /**
     * inisialise le plateau de jeux avec des caractere vide
     */
    public void inisialiserPlateauJeux(){
        for(int i = 0; i< this.nbLigne; i++){
            for(int j = 0; j<this.nbCologne; j++){
                this.plateau[i][j] = "";
            }
        }
    }

    /**
     * Place les bambe dans le plateau de manier aléatoire et le nombre de bambe et aussi aléatoire
     * entre 30 a 50 bambe
     */
    public void placerBombe(){
        int nbBombe = 30 + (int)(random() *21); //de 30 a 50
        this.nbBombe = nbBombe;
        while(nbBombe > 0){
            int ligne = (int)(random() * this.nbLigne);
            int cologne = (int)(random() * this.nbCologne);
            if( this.plateau[ligne][cologne] != "B") {//si pas de bombe en place une bombe
                this.plateau[ligne][cologne] = "B";
                nbBombe -= 1;
            }
        }

    }

    /**
     * calcule le nombre de bombe autour d'une case
     * @param ligne la case que on va vérifier autour
     * @param cologne la case que on va vérifier autour
     * @return le nombre de bombe
     */
    public int calculeNBBombe(int ligne, int cologne){
        int nbBombe = 0;

        // Parcours des 8 cases adjacentes (-1, 0, +1)
        for (int dLigne = -1; dLigne <= 1; dLigne++) {
            for (int dCol = -1; dCol <= 1; dCol++) {

                // On ignore la case centrale elle-même
                if (dLigne == 0 && dCol == 0) continue;

                int nLigne = ligne + dLigne;
                int nCol = cologne + dCol;

                // 1. Vérification des bordures du plateau
                if (nLigne >= 0 && nLigne < this.nbLigne && nCol >= 0 && nCol < this.nbCologne) {
                    // 2. Si c'est une bombe, on incrémente (Utiliser .equals() pour String)
                    if ("B".equals(this.plateau[nLigne][nCol])) {
                        nbBombe++;
                    }
                }
            }
        }
        return nbBombe;
    }

    /**
     * une fonction qui va calculer le nombre de bombe autour de chaque case pour avoir des indices lors du jeu
     *
     */
    public void indiceBombeAutour(){
        for (int i = 0; i < this.nbLigne; i++) {
            for (int j = 0; j < this.nbCologne; j++) {
                if (!"B".equals(this.plateau[i][j])) {
                    int nbBombe = calculeNBBombe(i, j);
                    this.plateau[i][j] = String.valueOf(nbBombe);
                }
            }
        }
    }

    /**
     * recupére l'indice de la case du plateau
     * @param ligne la ligne de la case
     * @param cologne la cologne de la case
     * @return l'indice de la case
     */
    public String getCase(int ligne, int cologne){
        return this.plateau[ligne][cologne];
    }

    /**
     * met l'indice que l'autre plateau à dans se plateau
     * @param indiceLigne la ligne de la case
     * @param indiceCologne la cologne de la case
     * @param autrePlateau l'autre plateau qui contient l'indice
     */
    public void setCasePlateau(int indiceLigne, int indiceCologne, Plateau autrePlateau){
        this.plateau[indiceLigne][indiceCologne] = autrePlateau.getCase(indiceLigne, indiceCologne);
    }

    /**
     * recupére le valeur priver nbLigne
     * @return le nombre de ligne
     */
    public int getNbLigne(){
        return this.nbLigne;
    }

    public void setText(int ligne, int cologne, String text){
        this.plateau[ligne][cologne] = text;
    }

    /**
     * recupére le valeur priver nbCologne
     * @return le nombre de cologne
     */
    public int getNbCologne(){
        return this.nbCologne;
    }

    /**
     * donne le nombre de bambe
     * @return le nombre de bombe
     */
    public int getNbBombe(){
        return this.nbBombe;
    }
}
