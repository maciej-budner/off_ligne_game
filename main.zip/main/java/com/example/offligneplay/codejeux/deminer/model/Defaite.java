package com.example.offligneplay.codejeux.deminer.model;

public class Defaite extends Etat{

    public Defaite(){}

    /**
     * analyse l'etat de la partie en se relayant avec les difairant etat pour savoir qui est vrai
     * ici on regarde si une bombe est decouvers
     * @param plateauJeux le plateau que le joueur voie
     * @param plateauIndice le plateau avec les indice sur les bombe
     * @return etat du jeux
     */
    public Etat analyse(Plateau plateauJeux, Plateau plateauIndice) {
        boolean bombeTrouver = false;
        for(int i = 0; i< plateauJeux.getNbLigne(); i++){
            for(int j = 0; j< plateauJeux.getNbCologne(); j++){
                if(plateauJeux.getCase(i, j) == "B"){
                    bombeTrouver = true;
                }
            }
        }

        if(bombeTrouver){
            return this;
        }
        else {
            Etat etatPartie = this.changeEtat();
            etatPartie = etatPartie.analyse(plateauJeux, plateauIndice);
            return etatPartie;
        }
    }

    /**
     * change L'etat pour analyser la partie
     * @return letat defaite
     */
    @Override
    public Etat changeEtat() {
        return new Victoire();
    }
}
