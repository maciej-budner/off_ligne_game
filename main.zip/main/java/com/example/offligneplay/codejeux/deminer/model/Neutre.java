package com.example.offligneplay.codejeux.deminer.model;

public class Neutre extends Etat{

    public Neutre(){    }

    /**
     * analyse l'etat de la partie en se relayant avec les difairant etat pour savoir qui est vrai
     * @param plateauJeux le plateau que le joueur voie
     * @param plateauIndice le plateau avec les indice sur les bombe
     * @return etat du jeux
     */
    public Etat analyse(Plateau plateauJeux, Plateau plateauIndice) {
        Etat etatPartie = this.changeEtat();
        etatPartie = etatPartie.analyse(plateauJeux, plateauIndice);
        return etatPartie;
    }

    /**
     * change L'etat pour analyser la partie
     * @return letat defaite
     */
    @Override
    public Etat changeEtat() {
        return new Defaite();
    }
}
