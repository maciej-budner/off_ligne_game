package com.example.offligneplay.codejeux.deminer.vue

import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.offligneplay.MainActivity

import com.example.offligneplay.codejeux.deminer.controler.Controler
import com.example.offligneplay.codejeux.deminer.vue.CasePolygonView
import com.example.offligneplay.codejeux.echec.vue.AccueilEchec
import com.example.offligneplay.codejeux.echec.vue.PlateauEchec
import com.example.offligneplay.databinding.ActivityPlateauDeminerBinding


class PlateauDeminer : AppCompatActivity() {
    private lateinit var ui : ActivityPlateauDeminerBinding
    private val mesBoutons = HashMap<String, CasePolygonView>()
    private lateinit var jeuRoot: ConstraintLayout
    private lateinit var clickEvent : Controler

    private lateinit var ancienBoutonClick : String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivityPlateauDeminerBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(ui.root)
        val nbLigne = 20
        val nbCologne = 12
        clickEvent = Controler(nbLigne, nbCologne, this)
        jeuRoot = ui.main
        ancienBoutonClick = ""

        // Masquer la barre de statut (status bar) et la barre de navigation
        val decorView = window.decorView
        val uiOptions =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        decorView.systemUiVisibility = uiOptions

        construirePlateau()

        ui.sorti.setOnClickListener{
            val mainMenu = Intent(this, MainActivity::class.java)
            startActivity(mainMenu)
            finish()
        }

        ui.creuser.setOnClickListener {
            clickEvent.creuser(ancienBoutonClick, mesBoutons)
            mesBoutons[ancienBoutonClick]?.setGlow(false, Color.TRANSPARENT)
            Log.d("test", "On creuse")
            ancienBoutonClick = ""
            ui.drapeau.setEnabled(false)
            ui.creuser.setEnabled(false)
            jeuRoot.postInvalidate()
        }
        ui.drapeau.setOnClickListener {
            clickEvent.poserDrapeau(ancienBoutonClick, mesBoutons)
            mesBoutons[ancienBoutonClick]?.setGlow(false, Color.TRANSPARENT)
            Log.d("test", "pose drapeau")
            ancienBoutonClick = ""
            ui.drapeau.setEnabled(false)
            ui.creuser.setEnabled(false)
            jeuRoot.postInvalidate()
        }
    }

    fun construirePlateau() {
        jeuRoot.post {
            val largeurEcran = jeuRoot.width.toFloat()
            val hauteurEcran = jeuRoot.height.toFloat()

            // Dimensions brutes du plateau (12 colonnes, 20 lignes)
            val largeurPlateauBrute = 12 * 44f  // 528f
            val hauteurPlateauBrute = 20 * 44f  // 880f

            // Calcul de l'échelle max pour que le plateau rentre à 100% dans l'écran (avec une marge de sécurité)
            val echelleX = (largeurEcran * 0.9f) / largeurPlateauBrute
            val echelleY = (hauteurEcran * 0.8f) / hauteurPlateauBrute
            val echelle = minOf(echelleX, echelleY) // On prend la plus petite pour ne pas déformer

            // Centrage parfait du plateau au milieu de l'écran
            val xOffset = (largeurEcran - (largeurPlateauBrute * echelle)) / 2f
            val yOffset = (hauteurEcran - (hauteurPlateauBrute * echelle)) / 2f

            val demiTaille = 19.0f
            val xInitial = 0.0
            val yInital = 0.0
            var x = xInitial
            var y = yInital
            var nbCologne = 0

            for (i in 1 until 241) {
                val caseId = i.toString()

                val cx = (x.toFloat() * echelle) + xOffset
                val cy = (y.toFloat() * echelle) + yOffset
                val tailleAgrandie = demiTaille * echelle

                val pointsPolygone = floatArrayOf(
                    cx - tailleAgrandie, cy - tailleAgrandie,
                    cx + tailleAgrandie, cy - tailleAgrandie,
                    cx + tailleAgrandie, cy + tailleAgrandie,
                    cx - tailleAgrandie, cy + tailleAgrandie
                )

                val casePolygon = CasePolygonView(this, caseId, Color.GRAY, pointsPolygone) { id ->
                    clickButton(id)
                }

                val layoutParams = ConstraintLayout.LayoutParams(
                    ConstraintLayout.LayoutParams.MATCH_PARENT,
                    ConstraintLayout.LayoutParams.MATCH_PARENT
                )
                casePolygon.layoutParams = layoutParams

                jeuRoot.addView(casePolygon)
                mesBoutons[caseId] = casePolygon

                if (i % 20 == 0 && i != 0) {
                    nbCologne += 1
                    x = xInitial + nbCologne * 44
                    y = yInital
                } else {
                    y += 44.0 // Orientation vers le bas (+Y) pour un affichage standard
                }
            }
        }
    }

    private fun clickButton(caseChoisie: String) {
        if(ancienBoutonClick != ""){
            mesBoutons[ancienBoutonClick]?.setGlow(false, Color.TRANSPARENT)
        }
        ancienBoutonClick = caseChoisie
        Log.d("JEU", "Case cliquée : $caseChoisie")
        mesBoutons[caseChoisie]?.setGlow(true, Color.YELLOW)
        // Ici tu feras appel à ton : clickEvent.eventApuisCase(mesBoutons, caseChoisie, statutLabel)
        ui.creuser.setEnabled(true)
        ui.drapeau.setEnabled(true)
    }


    fun finDePartie(message: String?) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Fin de partie")
        builder.setMessage(message + "\nQue voulez-vous faire ?")
        builder.setCancelable(false) // Bloque le clic en dehors pour obliger un choix

        // 1. Bouton "Rejouer"
        builder.setPositiveButton("Rejouer", object : DialogInterface.OnClickListener {
            override fun onClick(dialog: DialogInterface?, which: Int) {
                // Relance la même Activity avec les paramètres de joueurs
                val intent = Intent(this@PlateauDeminer, PlateauDeminer::class.java)
                startActivity(intent)
                finish() // Ferme la partie actuelle
            }
        })

        // 2. Bouton "Revenir au menu"
        builder.setNegativeButton("Revenir au menu", object : DialogInterface.OnClickListener {
            override fun onClick(dialog: DialogInterface?, which: Int) {
                // Ouvre le menu principal (ex: MenuActivity)
                val intent: Intent = Intent(this@PlateauDeminer ,MainActivity::class.java) // Remplace par le nom de ton Activity Menu
                startActivity(intent)
                finish() // Ferme la partie actuelle
            }
        })

        builder.show()
    }
}
