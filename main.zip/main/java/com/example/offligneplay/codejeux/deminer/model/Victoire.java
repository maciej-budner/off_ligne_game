package com.example.offligneplay.codejeux.deminer.model;

public class Victoire extends Etat{
    public Victoire(){}

    /**
     * analyse l'etat de la partie en se relayant avec les difairant etat pour savoir qui est vrai
     * ici on regarde si tout creuser sauf bambe
     * @param plateauJeux le plateau que le joueur voie
     * @param plateauIndice le plateau avec les indice sur les bombe
     * @return etat du jeux
     */
    public Etat analyse(Plateau plateauJeux, Plateau plateauIndice) {
        int nbCaseNonCreuser = 0;
        for(int i = 0; i< plateauJeux.getNbLigne(); i++){
            for(int j = 0; j< plateauJeux.getNbCologne(); j++){
                if(plateauJeux.getCase(i, j) == "" || plateauJeux.getCase(i, j) == "D" ){
                    nbCaseNonCreuser += 1;
                }
            }
        }

        if(nbCaseNonCreuser == plateauIndice.getNbBombe()){
            return this;
        }
        else {
            return this.changeEtat();
        }
    }

    /**
     * change L'etat pour analyser la partie
     * @return letat defaite
     */
    @Override
    public Etat changeEtat() {
        return new Neutre();
    }
}
