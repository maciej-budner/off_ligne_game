package com.example.offligneplay.codejeux.yalta.model.plateau;

import android.graphics.Color;

/**
 * Classe abstraite représentant une pièce d'échecs.
 * Définit les propriétés communes à toutes les pièces du jeu.
 * 
 * @author Maciej Budner
 */
public abstract  class Piece {
    /** Couleur de la pièce ("green", "red", "blue") */
    private String couleur;
    /** Indique si c'est le premier mouvement de la pièce */
    private boolean premierMouvement;
    /** Nombre de coups effectués par la pièce */
    private int nbCoup;
    /** Valeur en points de la pièce */
    private int pointPiece;
    /** Indique si la prise en passant est possible */
    private boolean coupPassantPossible;

    /**
     * Constructeur par défaut de la classe Piece.
     * Initialise une pièce sans couleur ni valeur.
     */
    public Piece() {
        this.couleur = null;
        this.premierMouvement = true;
        this.pointPiece = 0;
        this.nbCoup = 0;
        this.coupPassantPossible = false;
    }
    /**
     * Constructeur de la classe Piece avec couleur et valeur.
     * 
     * @param couleur la couleur de la pièce
     * @param pointPiece la valeur en points de la pièce
     */
    public Piece(String couleur, int pointPiece) {
        this.couleur = couleur;
        this.premierMouvement = true;
        this.pointPiece = pointPiece;
        this.nbCoup = 0;
        this.coupPassantPossible = false;
    }
    /**
     * Retourne le type de déplacement de la pièce.
     * Méthode abstraite à implémenter par chaque type de pièce.
     * 
     * @return une chaîne décrivant le type de déplacement
     */
    abstract public String deplacement();

    public boolean isPremierMouvement() {
        return premierMouvement;
    }
    public void augmenteNbCoup(){
        this.nbCoup +=1;
    }
    public void diminuNbCoup(){
        this.nbCoup -=1;
    }
    public int getNbCoup(){
        return this.nbCoup;
    }
    public void setPremierMouvement(boolean premierMouvement) {
        this.premierMouvement = premierMouvement;
    }
    public String getCouleurPiece(){
        return this.couleur;
    }
    public int getPointPiece(){
        return this.pointPiece;
    }
    public boolean getCoupPassantPosible(){
        return this.coupPassantPossible;
    }
    public void setCoupPassantPossible(boolean coup){
        this.coupPassantPossible = coup;
    }
    public int getCouleurPieceAndroid(){
        if(this.couleur == "red"){
            return Color.RED;
        }
        else if(this.couleur == "blue"){
            return Color.BLUE;
        }
        else{
            return Color.GREEN;
        }
    }

    
    
}
