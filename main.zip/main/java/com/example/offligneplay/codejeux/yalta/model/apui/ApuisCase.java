package com.example.offligneplay.codejeux.yalta.model.apui;


import java.util.HashMap;
import com.example.offligneplay.codejeux.yalta.controler.ClickEvent;
import com.example.offligneplay.codejeux.yalta.model.IAPlayeur;
import com.example.offligneplay.codejeux.yalta.model.JoueurPlayeur;
import com.example.offligneplay.codejeux.yalta.model.Playeur;
import com.example.offligneplay.codejeux.yalta.model.analyse.AnalysePartie;
import com.example.offligneplay.codejeux.yalta.model.analyse.Echec;
import com.example.offligneplay.codejeux.yalta.model.analyse.EchecMat;
import com.example.offligneplay.codejeux.yalta.model.plateau.*;
import com.example.offligneplay.codejeux.yalta.vue.CasePolygonView;
import com.example.offligneplay.codejeux.yalta.vue.PlateauYalta;

/**
 * La classe ApuisCase gère la logique de jeu et les interactions avec le plateau d'échecs.
 * Elle coordonne les mouvements des pièces, la gestion des joueurs, et l'analyse de l'état du jeu.
 * C'est le cœur de la logique métier du jeu d'échecs à 3 joueurs.
 * 
 * @author Maciej Budner
 */
public class ApuisCase {
    /** Plateau de jeu original */
    private Plateau plateauHoriginal;
    /** Logique de gestion des mouvements */
    private LogiqueMouvement logiqueMouvement;
    /** Tableau des joueurs (humains et IA) */
    private Playeur[] joueur;
    /** Tableau des couleurs des joueurs */
    private String couleur[] = {"green","red","blue"};
    /** Index du joueur actuel (0: green, 1: red, 2: blue) */
    private int autourDuJoueur;
    /** Analyseur de l'état de la partie */
    private AnalysePartie analyseurPartie;
    /** Indique si une pièce a été sélectionnée */
    private boolean apuilierSurPiece;
    /** État de la partie pour le joueur actuel */
    private int etatPartiejoueur;
    /** Sauvegarde de la case de la pièce à déplacer */
    private String sauveCasePieceBouge;

    /**Acces a la vue de kotlin*/
    private PlateauYalta activity;

    /** acces au controler*/
    private ClickEvent clickEvent;

    /**
     * Constructeur par défaut d'ApuisCase.
     * Initialise une instance sans configuration de joueurs.
     */
    public ApuisCase(PlateauYalta activity, ClickEvent click){
        this.clickEvent = click;
        this.plateauHoriginal = new Plateau();
        this.joueur = new Playeur[] {null, null, null};
        this.autourDuJoueur =0;
        this.analyseurPartie = new Echec();
        this.etatPartiejoueur =0;
        this.sauveCasePieceBouge = "";
        this.logiqueMouvement = null;
        this.activity = activity;
        
    }
    /**
     * Constructeur d'ApuisCase avec configuration des joueurs.
     * Initialise le plateau et les joueurs selon le nombre d'IA spécifié.
     * 
     * @param joueur le nombre de joueurs humains
     * @param ia le nombre d'intelligences artificielles
     */
    public ApuisCase(int joueur, int ia, PlateauYalta activity,ClickEvent click){
        this.clickEvent = click;
        this.plateauHoriginal = new Plateau();
        this.logiqueMouvement = new LogiqueMouvement();
        if(ia >1){//2 ia
            this.joueur = new Playeur[] {new JoueurPlayeur(),new IAPlayeur(),new IAPlayeur()};
        }
        else if(ia == 1){//1 ia
            this.joueur = new Playeur[] {new JoueurPlayeur(),new JoueurPlayeur(),new IAPlayeur()};
        }
        else{//0ia
            this.joueur = new Playeur[] {new JoueurPlayeur(),new JoueurPlayeur(),new JoueurPlayeur()};
        }
        this.autourDuJoueur = 0;
        this.analyseurPartie = new Echec();
        this.etatPartiejoueur =0;
        this.sauveCasePieceBouge = "";
        this.activity = activity;
    }

    /**
     * Démarre la partie en initialisant le plateau.
     * Configure les pièces dans leurs positions de départ.
     */
    public void startGame(){
        //les 2 plateau sont identique pour le moment
        this.plateauHoriginal.setStartPartie();
    }

    /**
     * Réinitialise l'apparence visuelle du plateau.
     * Supprime tous les effets visuels des boutons du plateau.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     */
    public void resetVisuelPlateau(HashMap<String, CasePolygonView> mesBouton){
        for (CasePolygonView button : mesBouton.values()) {
            button.setGlow(false, android.graphics.Color.TRANSPARENT);
        }
    }

    /**
     * Passe au joueur suivant dans l'ordre de jeu.
     * Gère la rotation entre les 3 joueurs (green → red → blue → green).
     */
    public void tourJoueurSuivant(){
        if(this.autourDuJoueur ==2){
            this.autourDuJoueur =0;
        }
        else{
            this.autourDuJoueur +=1;
        }
    }
    /**
     * Réinitialise les mouvements possibles sur toutes les cases du plateau.
     * Remet à zéro l'indicateur de coup possible pour chaque case.
     */
    public void resetPlateauMouvement(){
        for (Cases elem : this.plateauHoriginal.getPlateau().values()) {
            elem.setCoupPossible(0);
        }
    }
    /**
     * Réinitialise l'état de prise en passant des pions du joueur actuel.
     * Désactive la possibilité de prise en passant pour les pions du joueur courant.
     */
    public void resetPionPassant(){
        for(Cases cases : this.plateauHoriginal.getPlateau().values()){
            if(cases.getPiece() != null &&
                cases.getPiece().getCouleurPiece() == this.couleur[this.autourDuJoueur]&&
                cases.getPiece().getCoupPassantPosible()){
                    cases.getPiece().setCoupPassantPossible(false);
            }
        }
    }

    /**
     * Gère l'événement de clic sur une case du plateau.
     * Affiche les mouvements possibles ou effectue le déplacement d'une pièce.
     * Modifie directement l'interface visuelle du plateau.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param laCaseVoulue l'identifiant de la case cliquée
     */
    public void eventApuisCase(HashMap<String, CasePolygonView> mesBouton,String laCaseVoulue){
        if(this.apuilierSurPiece){
            //on avais apuis sur une piece avant donc on veut se deplacer
            //faut verifier si il a pas apuis sur un case avec autre piece
            //Et reset si c'est sa piece 
            System.out.println("la case voulu a coup possible : "+this.plateauHoriginal.getCoupPossibleCase(laCaseVoulue));
            if(this.plateauHoriginal.pieceOnCase(laCaseVoulue) && this.plateauHoriginal.getCoupPossibleCase(laCaseVoulue) ==0){
                //si il y une piece 2 cas c'est le notre on change 
                if(this.plateauHoriginal.getCouleurPiece(laCaseVoulue) == this.couleur[this.autourDuJoueur]){
                    this.apuilierSurPiece = false;
                    this.sauveCasePieceBouge ="";
                    resetPlateauMouvement();
                    resetVisuelPlateau(mesBouton);
                    eventApuisCase(mesBouton, laCaseVoulue);//on re appel la fonction
                }//sinon on fait rien
            }
            else{
                //on regarde si il a apuis sur une bonne case et on evite les apuis sur la meme case
                if(this.plateauHoriginal.getCoupPossibleCase(laCaseVoulue) !=0 && laCaseVoulue != this.sauveCasePieceBouge ){
                    //test pour pas manger le roi
                    Cases cases = this.plateauHoriginal.getCasesInPosition(laCaseVoulue);
                    if(cases.getPiece() != null && cases.getPiece().getClass() == Roi.class){
                        //on ne peut pas manger le roi
                        return;
                    }
                    //on a un deplacement
                    System.out.println("deplacement de la piece de "+this.sauveCasePieceBouge+" a "+laCaseVoulue);
                    //sauvegarde si il y a un pion
                    Piece pieceMangee = this.plateauHoriginal.getCasesInPosition(laCaseVoulue).getPiece();
                    CasePolygonView labelPieceMangee = null;
                    if(pieceMangee != null){
                        //secu car tout les label ne sont pas defini en null
                        labelPieceMangee = mesBouton.get(laCaseVoulue);
                    }
                    deplacementPiece(mesBouton,laCaseVoulue);
                    //on verifie si on a bien bouger le pion qui nous met plus en echec
                    if(this.etatPartiejoueur == 1){
                        //null sur la case que on ignore car on veut savoir si il y a echec
                        if(this.analyseurPartie.bougePionMiseEchecRoi(null, this.plateauHoriginal.getCasesInPosition(this.plateauHoriginal.getRoiSelonCouleur(this.couleur[this.autourDuJoueur])))){
                            System.out.print("refait ton coup car tes toujours en echec");
                            //toujour en echec anule le coup
                            //lacasesVoulu c'est actuel et this.sauv avant
                            CasePolygonView buttonPieceMaintenant = mesBouton.get(laCaseVoulue);
                            CasePolygonView buttonPieceAvant = mesBouton.get(this.sauveCasePieceBouge);

                            Cases casesMaintenant = this.plateauHoriginal.getCasesInPosition(laCaseVoulue);
                            Cases casesAvant = this.plateauHoriginal.getCasesInPosition(this.sauveCasePieceBouge);
                            //anule dans visuel
                            buttonPieceAvant.deplacementPiece(buttonPieceMaintenant.getPiece(), buttonPieceMaintenant.getcouleurPiece());
                            buttonPieceMaintenant.deplacementPiece("", android.graphics.Color.TRANSPARENT);
                            //anule dans plateau
                            casesAvant.setPiece(casesMaintenant.getPiece());
                            casesMaintenant.setPiece(null);
                            //remet piece manger
                            mesBouton.get(laCaseVoulue).deplacementPiece(labelPieceMangee.getPiece(), labelPieceMangee.getcouleurPiece());
                            plateauHoriginal.getCasesInPosition(laCaseVoulue).setPiece(pieceMangee);
                            
                            //si c'est le premier mouvement faut aussi reset 1er mouvement
                            if(casesAvant.getPiece().getNbCoup() == 1){
                                casesAvant.getPiece().setPremierMouvement(true);
                                casesAvant.getPiece().diminuNbCoup();
                                if(casesAvant.getPiece().getClass() == Pion.class){
                                    //remet le coup du passant non possible
                                    casesAvant.getPiece().setCoupPassantPossible(false);
                                }
                            }
                            else{//sinon juste nbCoup diminut
                                casesAvant.getPiece().diminuNbCoup();
                            }
                            activity.changeText("joueur "+this.couleur[this.autourDuJoueur] + " vous etes toujour en echec apres se coup coup annuler retry");
                            return;//on peut pas bouger cette cases
                        }
                    }
                    //on remet a O pour le joueur suivant
                    this.apuilierSurPiece = false;
                    tourJoueurSuivant();
                    activity.changeText("C'est au tour du joueur "+this.couleur[this.autourDuJoueur]);
                    this.sauveCasePieceBouge ="";
                    resetVisuelPlateau(mesBouton);
                    resetPlateauMouvement();
                    //reset des coup du passant de nos pion
                    resetPionPassant();
                    //et faudra verifier l'etat de l'autre joueur
                    this.etatPartiejoueur = verifieEtatDuJeux( this.plateauHoriginal.getCasesInPosition(this.plateauHoriginal.getRoiSelonCouleur(this.couleur[this.autourDuJoueur])));

                    //faut verifier si c'est une ia
                    if(this.joueur[this.autourDuJoueur].getClass() == IAPlayeur.class){
                        this.joueur[this.autourDuJoueur].mouvementIa(mesBouton, this.plateauHoriginal, this.couleur[this.autourDuJoueur], this.logiqueMouvement, this.analyseurPartie.getCoupPossible(), etatPartiejoueur, this.analyseurPartie);
                        this.apuilierSurPiece = true;
                        if(this.joueur[this.autourDuJoueur].getCoupDepart().isEmpty()){
                            //si vide en arrete la partie
                            this.analyseurPartie.resetList();//car il est pas vide mais en trouve pas de coup
                            this.etatPartiejoueur = 1;
                            this.analyseurPartie.changeState(this.etatPartiejoueur);//pour mettre en echec mat
                            this.etatPartiejoueur = verifieEtatDuJeux( this.plateauHoriginal.getCasesInPosition(this.plateauHoriginal.getRoiSelonCouleur(this.couleur[this.autourDuJoueur])));
                        }
                        this.sauveCasePieceBouge =  this.joueur[this.autourDuJoueur].getCoupDepart();
                        this.plateauHoriginal.getCasesInPosition(this.joueur[this.autourDuJoueur].getCoupArriver()).setCoupPossible(1);
                        System.out.println(this.sauveCasePieceBouge +" arrive "+this.joueur[this.autourDuJoueur].getCoupArriver());
                        eventApuisCase(mesBouton, this.joueur[this.autourDuJoueur].getCoupArriver());
                    }
                }
                
                //sinon on fait rien
            }
            
        }
        else{
            //on veut connaitre la position
            //on regarde si il y a un pion ici
            if(this.plateauHoriginal.pieceOnCase(laCaseVoulue)){
                //si il est on echec faut qui est cliquer sur la bonne case qui le protege
                if(this.etatPartiejoueur == 1 && !(this.analyseurPartie.getCoupPossible().contains(laCaseVoulue))){
                    System.out.println("tu peut pas bouger cette piece");
                    return;//c'est pas la bonne cases qui faut bouger
                }
                //on a une piece donc on analyse les mouvement si c'est le bon pion du joueur
                if(this.couleur[this.autourDuJoueur] == this.plateauHoriginal.getCouleurPiece(laCaseVoulue)){
                    //le joueur a bien apuiler sur sont pion
                    if(this.etatPartiejoueur != 1){
                        //faut verifier si ce pion ne va pas nous mettre en echec si on le bouge
                        if(this.plateauHoriginal.getCasesInPosition(laCaseVoulue).getPiece().getClass() != Roi.class){
                            //si on a pas apuilui sur le roi on verifie si on le bougean il n'est pas en echec
                            if(this.analyseurPartie.bougePionMiseEchecRoi(this.plateauHoriginal.getCasesInPosition(laCaseVoulue), this.plateauHoriginal.getCasesInPosition(this.plateauHoriginal.getRoiSelonCouleur(this.couleur[this.autourDuJoueur])))){
                                return;//on peut pas bouger cette cases
                            }
                        }
                    }//sinon on peut alors on continue
                    this.sauveCasePieceBouge = laCaseVoulue;
                    this.apuilierSurPiece = true;

                    //analyse les mouvement possible
                    montrePosibiliter(mesBouton,laCaseVoulue, this.plateauHoriginal.getCasesInPosition(laCaseVoulue));
                }
                
            }
            
        }
    }

    /**
     * Affiche les mouvements possibles d'une pièce.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param laCaseVoulue l'identifiant de la case de destination
     * @param cases la case de départ
     */
    public void montrePosibiliter(HashMap<String, CasePolygonView> mesBouton,String laCaseVoulue, Cases cases) {
        this.logiqueMouvement.logiqueMouvement(new MontrePosibiliter(), mesBouton, laCaseVoulue, cases, cases);
    }

    /**
     * Met à jour la position du roi dans le plateau.
     * 
     * @param caseRoi la case où se trouve le roi
     */
    public void roiSeDeplace(Cases caseRoi){
        Piece piece = caseRoi.getPiece();
        if(piece.getClass() == Roi.class){//c'est un roi
            if(piece.getCouleurPiece() == "red"){
                this.plateauHoriginal.setRoiRed(caseRoi.getIdCase());
            }
            else if(piece.getCouleurPiece() == "green"){
                this.plateauHoriginal.setRoiGreen(caseRoi.getIdCase());
            }
            else{
                this.plateauHoriginal.setRoiBlue(caseRoi.getIdCase());
            }
        }
    }
    /**
     * Déplace une pièce sur le plateau.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param laCaseVoulue l'identifiant de la case de destination
     */
    public void deplacementPiece(HashMap<String, CasePolygonView> mesBouton,String laCaseVoulue){
        this.logiqueMouvement.logiqueMouvement(new Deplacement(this.joueur[this.autourDuJoueur].getClass() == IAPlayeur.class, this.clickEvent), mesBouton, laCaseVoulue, this.plateauHoriginal.getCasesInPosition(this.sauveCasePieceBouge), this.plateauHoriginal.getCasesInPosition(laCaseVoulue));
        //une roi le deplacement fait posiblement le roi c'est deplacer
        roiSeDeplace(this.plateauHoriginal.getCasesInPosition(laCaseVoulue));

    }
    /**
     * Vérifie l'état du jeu après un mouvement.
     * 
     * @param roi la case du roi
     * @return l'état du jeu (0: rien, 1: échec, 2: échec et mat)
     */
    public int verifieEtatDuJeux(Cases roi){
        this.analyseurPartie.resetList();//pour le joueur suivant
        System.out.println("etat class :"+this.analyseurPartie.getClass().getSimpleName());
        int etat = 0;
        System.out.println("l'etat du jeu est " +this.etatPartiejoueur);
        //on verifie l'etat et on change le state(etat) du jeux selon le resulta
        etat = this.analyseurPartie.verificationEtatDuJeux(roi);
        this.analyseurPartie = this.analyseurPartie.changeState(etat);
        Cases pionAttaquant =this.analyseurPartie.quiMetEnEchec(roi);
        //verifi si l'etat est mat alors fin de partie sinon faut verifier si pat
        if((this.analyseurPartie.getClass() == EchecMat.class && etat == 1) || etat ==2){
            //fin de parti, notre changeState a detecter fin de partie
            System.out.println("mat");
            System.out.println(this.analyseurPartie.getCoupPossible());
            String gagnant = "";
            if(this.analyseurPartie.bougePionMiseEchecRoi(pionAttaquant, roi)){
                //si il est on echec sans la cases du pion qui devrai attaquer alors c'est un autre qui la mit en echec
                Cases casepion = this.analyseurPartie.quiMetEnEchec(roi);
                gagnant = casepion.getPiece().getCouleurPiece();
            }
            else{
                gagnant = pionAttaquant.getPiece().getCouleurPiece();
            }
            int nbJouer=0;
            int nbIA=0;
            for(int i =0; i<this.joueur.length; i++){
                if(this.joueur[i].getClass() == IAPlayeur.class){
                    nbIA ++;
                }
                else{
                    nbJouer ++;
                }
            }
            this.clickEvent.finParti("Victoire du joueur " + gagnant + " !!!", nbJouer, nbIA);
            return 2;
        }
        else if(etat == 1){
            //on est en echec
            System.out.println("echec");
            activity.changeText("joueur "+this.couleur[this.autourDuJoueur] + " c'est votre tour et vous etes en echec");
            System.out.println(this.analyseurPartie.getCoupPossible());
            return 1;
        }
        else{
            //on est a 0 donc faut verifier pat
            etat = this.analyseurPartie.verificationEtatDuJeux( roi);
            this.analyseurPartie = this.analyseurPartie.changeState(etat);
            if(etat == 3){
                //il y a pat
                //TODO:faut verifier si il sont pas 2 a l'etre a pat sinon en pass sont tour
                System.out.println("pat");
                System.out.println(this.analyseurPartie.getCoupPossible());
                int nbJouer=0;
                int nbIA=0;
                for(int i =0; i<this.joueur.length; i++){
                    if(this.joueur[i].getClass() == IAPlayeur.class){
                        nbIA ++;
                    }
                    else{
                        nbJouer ++;
                    }
                }

                this.clickEvent.finParti("Egaliter!\n le joueur "+roi.getPiece().getCouleurPiece()+" ne peut plus bouger",  nbJouer, nbIA);
                return 3;
            }
            else{
                //l'etat est a rien donc on peut continuer a jouer sans aucun etat
                //mais faut revenir a l'etat echec
                this.analyseurPartie.resetList();
                this.analyseurPartie = this.analyseurPartie.changeState(etat);
                System.out.println("rien");
                return 0;
            }
        }

    }
}
