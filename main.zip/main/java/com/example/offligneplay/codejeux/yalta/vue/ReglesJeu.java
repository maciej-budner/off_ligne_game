package com.example.offligneplay.codejeux.yalta.vue;

import android.content.Context;
import androidx.appcompat.app.AlertDialog;

public class ReglesJeu {

    // Interface callback pour récupérer le choix du joueur
    public interface PromotionCallback {
        void onPieceChoisie(String pieceSymbol);
    }

    public static void demandePromotion(Context context, String couleurJoueur, PromotionCallback callback) {
        // Liste des pièces Unicode : Tour (♜), Cavalier (♞), Fou (♝), Dame (♛)
        // (Ou la version blanche selon le joueur si besoin)
        final String[] pieces = {"\u265B", "\u265C", "\u265D", "\u265E"}; // Dame, Tour, Fou, Cavalier
        final String[] nomsPieces = {"Dame (♛)", "Tour (♜)", "Fou (♝)", "Cavalier (♞)"};

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("⭐ Promotion du Pion");
        builder.setMessage("Félicitations ! Votre pion a atteint le bord. Choisissez sa promotion :");

        // Affiche la liste des choix sous forme de menu déroulant / liste
        builder.setItems(nomsPieces, (dialog, which) -> {
            String pieceChoisie = pieces[which];
            System.out.println("choisi: " + pieceChoisie);

            // On renvoie la pièce choisie via le callback
            callback.onPieceChoisie(pieceChoisie);
        });

        // Empêche de fermer la boîte de dialogue en cliquant à côté (obligatoire de choisir)
        builder.setCancelable(false);

        // Affiche la boîte de dialogue
        builder.show();
    }
}
