package com.example.offligneplay.codejeux.yalta.model.analyse;

import java.util.HashMap;
import java.util.HashSet;

import com.example.offligneplay.codejeux.yalta.model.apui.MontrePosibiliter;
import com.example.offligneplay.codejeux.yalta.model.plateau.*;

/**
 * La classe Echec représente l'état d'échec dans une partie d'échecs.
 * Elle gère la détection des situations d'échec, la recherche des coups de défense possibles,
 * et l'analyse des menaces contre le roi.
 * 
 * @author Maciej Budner
 */
public class Echec extends AnalysePartie{
    /**
     * Constructeur par défaut de la classe Echec.
     * Initialise une liste vide de coups possibles.
     */
    public Echec(){
        super();
    }
    
    /**
     * Constructeur de la classe Echec avec une liste de coups existante.
     * 
     * @param coupPossible l'ensemble des coups possibles à initialiser
     */
    public Echec(HashSet<String> coupPossible){
        super(coupPossible);
    }
    
    
    /**
     * Vérifie et ajoue dans la list, récursivement si on peut défendre en attaquant.
     * 
     * @param direction la direction d'analyse
     * @param cases la case actuelle
     * @param pionAttaquant la case du pion attaquant
     * @param couleurRoi la couleur du roi
     * @param depart la cases de depart avant recurciviter
     */
    public void defenceAttaqueRecurcive(String direction, Cases cases,Cases pionAttaquant, String couleurRoi,Cases depart){
        if(cases == null){//dehord du plateau
            return;
        }
        //on prend le suivant
        Cases nouvelleCase = getCaseSuivante(direction, cases);
        if(nouvelleCase ==null){
            return ;//rien trouver donc pas echec
        }
        else if(nouvelleCase.getPiece() != null){
            //on a un pion faut voir si c'est le notre ou pas
            if(nouvelleCase.getPiece().getCouleurPiece() == pionAttaquant.getPiece().getCouleurPiece() || nouvelleCase.getPiece().getCouleurPiece() != couleurRoi){
                //ces notre pion plus besoin de regarder si attaquer dans cette direction
                return ;
            }
            if(nouvelleCase.getPiece().getClass() == Roi.class){
                //c'es un roi en touche pas ici
                return;
            }
            else{
                //c'es un ennemi
                if(quipeutAttaquerRoi(nouvelleCase.getPiece(), direction, pionAttaquant, nouvelleCase,depart)){
                    //on a trouver que sur cette cases on peut bouger
                    this.addInList(nouvelleCase.getIdCase());
                    return;
                }
                else{
                    return;
                }
            }
        }
        else{
            //on peut continuer
            //on regarde si on est pas dans le cas où on a pas put mettre de lien sudest et sud ouest
            direction = changeDirection(cases.getIdCase(), nouvelleCase.getIdCase(), direction);
            defenceAttaqueRecurcive(direction, nouvelleCase,pionAttaquant,couleurRoi,depart);
        }
    }
    
    /**
     * Vérifie et ajoue dans la list, si on peut défendre en attanquant avec notre cavalier.
     * 
     * @param cases la case actuelle
     * @param notrePiece notre pièce pour déterminer les ennemis
     * @param couleurRoi la couleur du roi
     */
    public void defendreAvecCavalier(Cases cases, Piece notrePiece, String couleurRoi){
        Cases casesEntreDeux = null;
        if(cases.getNord() !=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getNord().getNord();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getOuest() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getOuest().getPiece() !=null){
                        if(casesEntreDeux.getOuest().getPiece().getCouleurPiece() == couleurRoi 
                            && casesEntreDeux.getOuest().getPiece().getClass() == Cavalier.class){
                            //le cavalier peut manger l'attaquant
                            this.addInList(casesEntreDeux.getOuest().getIdCase());
                        }
                    }
                }
                if(casesEntreDeux.getEst() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getEst().getPiece() !=null){
                        if(casesEntreDeux.getEst().getPiece().getCouleurPiece() == couleurRoi 
                            && casesEntreDeux.getEst().getPiece().getClass() == Cavalier.class){
                            //le cavalier peut manger l'attaquant
                            this.addInList(casesEntreDeux.getEst().getIdCase());
                        }
                    }
                }
            }
        }
        if(cases.getSud()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getSud().getSud();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getOuest() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getOuest().getPiece() !=null){
                        if(casesEntreDeux.getOuest().getPiece().getCouleurPiece() == couleurRoi 
                            && casesEntreDeux.getOuest().getPiece().getClass() == Cavalier.class){
                            //le cavalier peut manger l'attaquant
                            this.addInList(casesEntreDeux.getOuest().getIdCase());
                        }
                    }
                }
                if(casesEntreDeux.getEst() != null){
                    if(casesEntreDeux.getEst() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getEst().getPiece() !=null){
                            if(casesEntreDeux.getEst().getPiece().getCouleurPiece() == couleurRoi 
                                && casesEntreDeux.getEst().getPiece().getClass() == Cavalier.class){
                                //le cavalier peut manger l'attaquant
                                this.addInList(casesEntreDeux.getEst().getIdCase());
                            }
                        }
                    }
                }
            }
        }
        //nord sud case possible
        if(cases.getEst()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getEst().getEst();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getNord() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getNord().getPiece() !=null){
                        if(casesEntreDeux.getNord().getPiece().getCouleurPiece() == couleurRoi 
                            && casesEntreDeux.getNord().getPiece().getClass() == Cavalier.class){
                            //le cavalier peut manger l'attaquant
                            this.addInList(casesEntreDeux.getNord().getIdCase());
                        }
                    }
                }
                if(casesEntreDeux.getSud() != null){
                    if(casesEntreDeux.getSud() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getSud().getPiece() !=null){
                            if(casesEntreDeux.getSud().getPiece().getCouleurPiece() == couleurRoi 
                                && casesEntreDeux.getSud().getPiece().getClass() == Cavalier.class){
                                //le cavalier peut manger l'attaquant
                                this.addInList(casesEntreDeux.getSud().getIdCase());
                            }
                        }
                    }
                }
            }
        }
        if(cases.getOuest()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getOuest().getOuest();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getNord() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getNord().getPiece() !=null){
                        if(casesEntreDeux.getNord().getPiece().getCouleurPiece()== couleurRoi 
                            && casesEntreDeux.getNord().getPiece().getClass() == Cavalier.class){
                            //le cavalier peut manger l'attaquant
                            this.addInList(casesEntreDeux.getNord().getIdCase());
                        }
                    }
                }
                if(casesEntreDeux.getSud() != null){
                    if(casesEntreDeux.getSud() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getSud().getPiece() !=null){
                            if(casesEntreDeux.getSud().getPiece().getCouleurPiece() == couleurRoi 
                                && casesEntreDeux.getSud().getPiece().getClass() == Cavalier.class){
                                //le cavalier peut manger l'attaquant
                                this.addInList(casesEntreDeux.getSud().getIdCase());
                            }
                        }
                    }
                }
            }
        }
        return;
    }
    
    /**
     * Vérifie et ajoute dans la liste les cases cliquables possibles pour se défendre.
     * 
     * @param cases la case actuelle
     * @param pionAttaquant la case du pion attaquant
     * @param couleurRoi la couleur du roi
     */
    public void deffenceAttaquePiece(Cases cases,Cases pionAttaquant, String couleurRoi){
        //defendre on mangean l'attaquant
        defenceAttaqueRecurcive("nord", cases,pionAttaquant,couleurRoi,cases); 
        defenceAttaqueRecurcive("sud", cases,pionAttaquant,couleurRoi,cases) ;
        defenceAttaqueRecurcive("sudEst", cases,pionAttaquant,couleurRoi,cases); 
        defenceAttaqueRecurcive("sudOuest", cases,pionAttaquant,couleurRoi,cases); 
        defenceAttaqueRecurcive("nordEst", cases,pionAttaquant,couleurRoi,cases) ;
        defenceAttaqueRecurcive("nordOuest", cases,pionAttaquant,couleurRoi,cases); 
        defenceAttaqueRecurcive("est", cases,pionAttaquant,couleurRoi,cases) ;
        defenceAttaqueRecurcive("ouest", cases,pionAttaquant,couleurRoi,cases); 
            
        defendreAvecCavalier(cases, pionAttaquant.getPiece(),couleurRoi);
            
    }

    /**
     * regarde si le roi peut avancer sur cette case pour se protèger de l'echec
     * @param cases la case a vérifier
     * @param casesRoi la case du roi
     * @return true si le roi peut avancer sur cette case, false sinon
     */
    public boolean roiPeutAvancer(Cases cases, Cases casesRoi){
        if(cases == null){//hord du plateau
            return false;
        }
        else if(cases.getPiece() != null && cases.getPiece().getCouleurPiece() == casesRoi.getPiece().getCouleurPiece()){
            //case occupee par une piece de la meme couleur
            return false;
        }
        else if(roiEnEchec(cases, casesRoi)){
            //cases en echec
            return false;
        }
        return true;
    }

    /**
     * Vérifie et ajoute dans la liste la cases du roi qui peut bouger.
     * 
     * @param cases la case actuelle
     * @param casesRoi la case du roi
     */
    public void bougerRoi(Cases cases, Cases casesRoi){
        if(cases == null){//hord du plateau
            return;
        }
        if(roiPeutAvancer(cases.getNord(),casesRoi) || 
            roiPeutAvancer(cases.getSud(),casesRoi) ||
            roiPeutAvancer(cases.getEst(),casesRoi) ||
            roiPeutAvancer(cases.getOuest(),casesRoi) ||
            roiPeutAvancer(cases.getNordEst(),casesRoi) ||
            roiPeutAvancer(cases.getNordOuest(),casesRoi) ||
            roiPeutAvancer(cases.getSudEst(),casesRoi) ||
            roiPeutAvancer(cases.getSudOuest(),casesRoi) 
        ){
            this.addInList(casesRoi.getIdCase());
        }
        
    }

    /**
     * Vérifie si le roi est attaqué dans cette direction.
     * 
     * @param direction la direction d'analyse
     * @param cases la case actuelle
     * @param roi la case du roi
     * @return true si le roi est attaqué dans cette direction, false sinon
     */
    public boolean attaqueRoiDeCetteDirection(String direction, Cases cases, Cases roi){
        //on prend le suivant
        Cases nouvelleCase = getCaseSuivante(direction, cases);
        if(nouvelleCase == null){
            return false;//cases vide on est dehord du plateau
        }
        else if(roi == nouvelleCase){
            //on attauqe a cette direction
            return true;
        }
        else{
            direction = changeDirection(cases.getIdCase(), nouvelleCase.getIdCase(), direction);
            return attaqueRoiDeCetteDirection(direction, nouvelleCase, roi);
        }


    }

    /**
     * Détermine la direction d'attaque du pion vers le roi.
     * 
     * @param attaquand la case de l'attaquant
     * @param roi la case du roi
     * @return la direction d'attaque
     */
    public String pionAttaqueDirection(Cases attaquand, Cases roi){
        String direction = "";
        if(attaqueRoiDeCetteDirection("nord", attaquand, roi)){
            direction = "nord";
        }
        else if(attaqueRoiDeCetteDirection("sud", attaquand, roi)){
            direction = "sud";
        }
        else if(attaqueRoiDeCetteDirection("sudOuest", attaquand, roi)){
            direction = "sudOuest";
        }
        else if(attaqueRoiDeCetteDirection("sudEst", attaquand, roi)){
            direction = "sudEst";
        }
        else if(attaqueRoiDeCetteDirection("nordOuest", attaquand, roi)){
            direction = "nordOuest";
        }
        else if(attaqueRoiDeCetteDirection("nordEst", attaquand, roi)){
            direction = "nordEst";
        }
        else if(attaqueRoiDeCetteDirection("est", attaquand, roi)){
            direction = "est";
        }
        else if(attaqueRoiDeCetteDirection("ouest", attaquand, roi)){
            direction = "ouest";
        }

        return direction;

    }

    /**
     * Vérifie si on peut mettre une pièce dans cette case.
     * 
     * @param direction la direction d'analyse
     * @param cases la case actuelle
     * @param depart la case de départ
     * @param roi la piece du roi
     */
    public void mettrePieceIci(String direction, Cases cases, Cases depart, Piece roi){
        if(cases == null){//dehord plateau
            return;
        }
        Cases nouvelleCases = getCaseSuivante(direction, cases);
        if(nouvelleCases == null){
            return;
        }
        if(nouvelleCases == depart){
            return;//on est sur la cases ou la piece attaque
        }
        else if(nouvelleCases.getPiece() != null){
            if(nouvelleCases.getPiece().getCouleurPiece() == roi.getCouleurPiece()){
                //on est sur notre piece mais seul le fou, reine et tour peuvent se mettre ici
                //roi sera toujour echec, pion peut que avancer de l'avant et on a deja verifier si attaque
                //cavalier on verifi autre par
                Piece piece = nouvelleCases.getPiece();
                //le fou peut avancer diago et tour tout droit dout les test
                if(piece.getClass() == Reine.class ||
                    (piece.getClass() == Fou.class &&
                    (cases.getNordEst() == nouvelleCases ||
                    cases.getNordOuest() == nouvelleCases ||
                    cases.getSudEst() == nouvelleCases ||
                    cases.getSudOuest() == nouvelleCases)
                    ) ||
                    (piece.getClass() == Tour.class&&
                    (cases.getNord() == nouvelleCases ||
                    cases.getOuest() == nouvelleCases ||
                    cases.getEst() == nouvelleCases ||
                    cases.getSud() == nouvelleCases)
                    )){
                        this.addInList(nouvelleCases.getIdCase());
                        return;
                    }
                else{
                    return;
                }
            }
            else{
                //piece adverse
                return;
            }
        }
        else{
            direction = changeDirection(cases.getIdCase(), nouvelleCases.getIdCase(), direction);
            mettrePieceIci(direction, nouvelleCases, depart, roi);
        }
    }

    /**
     * Défend le roi avec une pièce.
     * 
     * @param cases la case actuelle
     * @param roi la piece du roi
     */
    public void defendreAvecPiece(Cases cases, Piece roi){
        System.out.println("case ou en regarde si en pet def " + cases.getIdCase());
        mettrePieceIci("nord", cases, cases,roi); 
        mettrePieceIci("sud", cases, cases,roi) ;
        mettrePieceIci("sudEst", cases, cases,roi); 
        mettrePieceIci("sudOuest", cases, cases,roi); 
        mettrePieceIci("nordEst", cases,cases,roi) ;
        mettrePieceIci("nordOuest", cases,cases,roi); 
        mettrePieceIci("est", cases,cases,roi) ;
        mettrePieceIci("ouest", cases,cases,roi); 
    }

    /**
     * Met une pièce défensive dans une direction du pion qui attaque le roi.
     * 
     * @param direction la direction d'analyse
     * @param cases la case actuelle
     * @param pionAttaquant la case du pion attaquant
     * @param roi la case du roi
     */
    public void mettrePieceDefencive(String direction, Cases cases, Cases pionAttaquant, Cases roi){
        Cases nouvelleCase = getCaseSuivante(direction, cases);
        if(nouvelleCase == null){
            return;
        }
        else if(nouvelleCase == roi){
            return;//on a vue toute les posibiliter
        }
        else{
            System.out.println("regarde la case : " + nouvelleCase.getIdCase());
            //on regarde si le cavalier peut se placer ici
            defendreAvecPiece(nouvelleCase, roi.getPiece());
            defendreAvecCavalier(nouvelleCase, roi.getPiece(), roi.getPiece().getCouleurPiece());
            direction = changeDirection(cases.getIdCase(), nouvelleCase.getIdCase(), direction);
            mettrePieceDefencive(direction, nouvelleCase, pionAttaquant, roi);
        }
    }
    
    /**
     * Vérifie si le roi est en échec, si il l'est on donne les coup possible pour le joueur
     *
     * @param casesRoi la case contenant le roi
     * @return 1 si le roi est en échec, 0 sinon
     */
    public int verificationEtatDuJeux(Cases casesRoi){
        System.out.println("roi echec?");
        if(roiEnEchec(casesRoi, casesRoi)){
            System.out.println("roi echec");
            Cases pionAttaquant = quiMetEnEchec(casesRoi);
            //roi en echec faut voir qui attaque, de quelle direction et les coup possible
            Piece pieceAttaquant = pionAttaquant.getPiece();
            if(pieceAttaquant.getClass() == Cavalier.class || pieceAttaquant.getClass() == Pion.class){
                System.out.println("tu rentre la pour bleu");
                //si c'est un cavalier ou pion qui attaque soit on le mange soit bouge roi si ces cases sont pas attaquer
                deffenceAttaquePiece(pionAttaquant, pionAttaquant, casesRoi.getPiece().getCouleurPiece());
                //defendre en bougeon le roi
                bougerRoi(casesRoi, casesRoi);
            }
            else{
                //c'est autre pion on peut soit le manger si possible, blocker la tragectoire, bouger roi, manger avec autre pion
                //mais faut dabors savoir de quelle coter il attaque
                deffenceAttaquePiece(pionAttaquant, pionAttaquant, casesRoi.getPiece().getCouleurPiece());
                //defendre en bougeon le roi
                bougerRoi(casesRoi, casesRoi);
                //verifie si on peut pas mettre un pion devant
                //verifie par ou il attaque
                String direction = pionAttaqueDirection(pionAttaquant, casesRoi);
                System.out.println("direction : " + direction);
                //regarde si on peut mettre un pion devant pour defendre
                mettrePieceDefencive(direction, pionAttaquant, pionAttaquant, casesRoi);
            }
            //verif si double echec
            System.out.println("echec si ignora attaque:"+roiEnEchecIgnoreUneCase(casesRoi, pionAttaquant, casesRoi, false));
            if(roiEnEchecIgnoreUneCase(casesRoi, pionAttaquant, casesRoi, false)){
                //verifie si tout les case sont en echec
                //si cases bull en mais vrai car pas d'echapatoir
                boolean outPlateau[] = {casesRoi.getNord() == null,casesRoi.getSud()== null,casesRoi.getSudEst()== null,
                    casesRoi.getSudOuest()== null,casesRoi.getNordEst()== null,casesRoi.getNordOuest()== null,
                    casesRoi.getEst()== null,casesRoi.getOuest()== null};
                if(this.listCantient(casesRoi.getIdCase()) &&( 
                (outPlateau[0] || roiEnEchecIgnoreUneCase(casesRoi.getNord(),casesRoi, casesRoi, false)) &&
                (outPlateau[1] || roiEnEchecIgnoreUneCase(casesRoi.getSud(),casesRoi, casesRoi, false)) &&
                (outPlateau[2] || roiEnEchecIgnoreUneCase(casesRoi.getSudEst(),casesRoi, casesRoi, false)) &&
                (outPlateau[3] || roiEnEchecIgnoreUneCase(casesRoi.getSudOuest(),casesRoi, casesRoi, false)) &&
                (outPlateau[4] || roiEnEchecIgnoreUneCase(casesRoi.getNordEst(),casesRoi, casesRoi, false)) &&
                (outPlateau[5] || roiEnEchecIgnoreUneCase(casesRoi.getNordOuest(),casesRoi, casesRoi, false)) &&
                (outPlateau[6] || roiEnEchecIgnoreUneCase(casesRoi.getEst(),casesRoi, casesRoi, false)) &&
                (outPlateau[7] || roiEnEchecIgnoreUneCase(casesRoi.getOuest(),casesRoi, casesRoi, false)))){
                    System.out.println("je suis en echecmat la");
                    this.resetList();
                    return 2;//il y a aucun endroie ou en peut se defendre
                }
                else if(!(this.listCantient(casesRoi.getIdCase())) && roiEnEchecIgnoreUneCase(casesRoi, getCaseSuivante(pionAttaqueDirection(pionAttaquant, casesRoi), casesRoi), casesRoi, true)){
                    //regarde si toujour en echec meme si cette case existeplus si oui mat
                    System.out.println("fin");
                    this.resetList();
                    return 2;
                }
                else{//sinon echec
                    return 1;
                    
                }
            }
            else{
            return 1;}
        }
        else{
            return 0;
        }
    }

    /**
     * Change le State pour verifier d'autre possibiliter
     * 
     * @param etatJeux l'état du jeu actuel
     * @return une nouvelle instance d'EchecMat
     */
    public AnalysePartie changeState(int etatJeux){
        if(this.listVide() && etatJeux == 1){
            //il est on echec et mat
            return new EchecMat(this.getCoupPossible());
        }
        else if(etatJeux == 1){
            //on change pas d'etat
            return new Echec(this.getCoupPossible());
        }
        else{
            //faut verifier si il y a path
            return new Pat(this.getCoupPossible());
        }
        
    }
   
}
