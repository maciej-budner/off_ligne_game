package com.example.offligneplay.codejeux.yalta.model.apui;

import android.graphics.Color;

import java.util.HashMap;
import com.example.offligneplay.codejeux.yalta.model.plateau.*;
import com.example.offligneplay.codejeux.yalta.vue.CasePolygonView;


/**
 * La classe MontrePosibiliter implémente l'interface Mouvement pour afficher les possibilités de déplacement.
 * Elle gère l'affichage visuel des mouvements possibles pour chaque pièce sur le plateau.
 * 
 * @author Maciej Budner
 */
public class MontrePosibiliter implements Mouvement{
    
    /**
     * Constructeur par défaut de la classe MontrePosibiliter.
     */
    public MontrePosibiliter(){

    }

    /**
     * Récupère la case suivante dans une direction donnée.
     * Utilisée pour naviguer sur le plateau lors de l'analyse des mouvements.
     * 
     * @param directionSuivante la direction de recherche ("nord", "sud", "est", "ouest", etc.)
     * @param cases la case de départ
     * @return la case suivante dans la direction spécifiée, ou null si hors plateau
     */
    public Cases getCaseSuivante(String directionSuivante, Cases cases){
        switch(directionSuivante){
            case "nord":
                return cases.getNord();
            case "nordEst":
                return cases.getNordEst();
            case "nordOuest":
                return cases.getNordOuest();
            case "est":
                return cases.getEst();
            case "ouest":
                return cases.getOuest();
            case "sud":
                return cases.getSud();
            case "sudEst":
                return cases.getSudEst();
            case "sudOuest":
                return cases.getSudOuest();
            default:
                return null;
        }

    }

    /**
     * Corrige la direction pour les cas spéciaux du plateau à 3 joueurs.
     * Gère les anomalies de positionnement entre les cases I5-L5 et I9-L9.
     * 
     * @param depart la case de départ
     * @param arriver la case d'arrivée
     * @param direction la direction initiale
     * @return la direction corrigée si nécessaire
     */
    public String changeDirection(String depart, String arriver, String direction){
        switch(direction){
            case "sudEst":
                if ((depart == "J9" && arriver == "I5")||
                    (depart == "K9" && arriver == "J5")||
                    (depart == "L9" && arriver == "K5")||
                    (depart == "I5" && arriver =="J9")||
                    (depart == "J5" && arriver == "K9")||
                    (depart == "K5" && arriver == "L9")){
                    return "nordOuest";
                }
                else{
                    return direction;
                }
            case "sudOuest":
                if ((depart == "I9" && arriver == "J5")||
                    (depart == "J9" && arriver == "K5")||
                    (depart == "K9" && arriver == "L5")||
                    (depart == "J5" && arriver =="I9")||
                    (depart == "K5" && arriver == "J9")||
                    (depart == "L5" && arriver == "K9")) {
                    return "nordEst";
                }
                else{
                    return direction;
                }
            default:
                return direction;
        }
    }
    
    /**
     * Analyse récursivement les mouvements possibles depuis une case donnée.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param pion la pièce à analyser
     * @param cases la case de départ
     * @param directionDeplacement la direction du mouvement
     */
    public void analyseMouvementRecursif(HashMap<String, CasePolygonView> mesBouton, Piece pion, Cases cases, String directionDeplacement){
        //si null on arrete, si notre pion on arrete, si on attaque on change couleur attaque et arrete, sinon contineu
        //on prend le suivant
        Cases nouvelleCase = getCaseSuivante(directionDeplacement, cases);

        if(nouvelleCase == null){
            return;
        }
        else if(nouvelleCase.getPiece() != null){
            if(nouvelleCase.getPiece().getCouleurPiece() == pion.getCouleurPiece()){
                //notre pion
                return;
            }
            else{
                //on peut l'attaquer
                CasePolygonView lebutton = mesBouton.get(nouvelleCase.getIdCase());
                lebutton.setGlow(true, android.graphics.Color.RED);
                nouvelleCase.setCoupPossible(2);
                return;
            }
        }
        else{
            //on peut continuer
            //on regarde si on est pas dans le cas où on a pas put mettre de lien sudest et sud ouest
            directionDeplacement = changeDirection(cases.getIdCase(), nouvelleCase.getIdCase(), directionDeplacement);
            CasePolygonView lebutton = mesBouton.get(nouvelleCase.getIdCase());
            lebutton.setGlow(true, android.graphics.Color.YELLOW);
            nouvelleCase.setCoupPossible(1);
            analyseMouvementRecursif(mesBouton, pion, nouvelleCase, directionDeplacement);
        }
    }

    /**
     * Vérifie les attaques possibles du pion.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param cases la case à analyser
     * @param pion la pièce à analyser
     */
    public void attaquePionPossible(HashMap<String, CasePolygonView> mesBouton, Cases cases,  Piece pion){
        //verifier si il y a un pion on face et que c'est pas la meme couleur
        if(cases !=null){
            if(cases.getPiece() != null && pion.getCouleurPiece() != cases.getPiece().getCouleurPiece()){
                CasePolygonView lebutton = mesBouton.get(cases.getIdCase());
                lebutton.setGlow(true, Color.RED);
                cases.setCoupPossible(2);//on peut attaquer
            }
        }
    }
    /**
     * Vérifie les mouvements possibles du pion.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param cases la case à analyser
     */
    public void mouvementPion(HashMap<String, CasePolygonView> mesBouton, Cases cases){
        //verifier si il y a pas un pion on face
        if(cases !=null){
            if(cases.getPiece() == null){
                CasePolygonView lebutton = mesBouton.get(cases.getIdCase());
                lebutton.setGlow(true, Color.YELLOW);
                cases.setCoupPossible(1);//on peut bouger
            }
        }
    }
    /**
     * Regarde si les cases adjacentes au cavalier sont libres.
     * 
     * @param coterGauche la direction gauche du cavalier
     * @param coterDroit la direction droite du cavalier
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param pion la pièce à analyser
     * @param cases la case de départ
     */
    public void regardeSiCaseLibreCavalier(String coterGauche, String coterDroit, HashMap<String, CasePolygonView> mesBouton, Piece pion,Cases cases){
        Cases casesCoterGauche = getCaseSuivante(coterGauche, cases);
        Cases casesCoterDroite = getCaseSuivante(coterDroit, cases);

        //regarde si null ou si peut attacker
        if(casesCoterGauche != null){
            Piece piece = casesCoterGauche.getPiece();
            if(piece == null){
                //deplacement normal
                CasePolygonView lebutton = mesBouton.get(casesCoterGauche.getIdCase());
                lebutton.setGlow(true, Color.YELLOW);
                casesCoterGauche.setCoupPossible(1);
            }
            else{
                //il y a un pion faut voir si c'est le notre
                if(piece.getCouleurPiece() != pion.getCouleurPiece()){
                    //c'est pas le notre on peut l'attaquer
                    CasePolygonView lebutton = mesBouton.get(casesCoterGauche.getIdCase());
                    lebutton.setGlow(true, Color.RED);
                    casesCoterGauche.setCoupPossible(2);
                }
                //sinon peut peut meme pas se deplacer
            }
        }
        if(casesCoterDroite != null){
            Piece piece = casesCoterDroite.getPiece();
            if(piece == null){
                //deplacement normal
                CasePolygonView lebutton = mesBouton.get(casesCoterDroite.getIdCase());
                lebutton.setGlow(true, Color.YELLOW);
                casesCoterDroite.setCoupPossible(1);
            }
            else{
                //il y a un pion faut voir si c'est le notre
                if(piece.getCouleurPiece() != pion.getCouleurPiece()){
                    //c'est pas le notre on peut l'attaquer
                    CasePolygonView lebutton = mesBouton.get(casesCoterDroite.getIdCase());
                    lebutton.setGlow(true, Color.RED);
                    casesCoterDroite.setCoupPossible(2);
                }
                //sinon peut peut meme pas se deplacer
            }
        }
        //sinon on peut pas se deplacer
    }
    /**
     * Vérifie si une case est attaquée par un cavalier.
     * 
     * @param cases la case à analyser
     * @param notrePiece la pièce qui attaque
     * @return true si la case est attaquée par un cavalier, false sinon
     */
    public boolean attaquerParCavalier(Cases cases, Piece notrePiece){
        Cases casesEntreDeux = null;
        boolean caseAttaquer = false;
        if(cases.getNord() !=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getNord().getNord();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getOuest() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getOuest().getPiece() !=null){
                        if(casesEntreDeux.getOuest().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getOuest().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = true;
                        }
                    }
                }
                if(casesEntreDeux.getEst() != null){
                    if(casesEntreDeux.getEst() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getEst().getPiece() !=null){
                            if(casesEntreDeux.getEst().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getEst().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = true;
                            }
                        }
                    }
                }
            }
        }
        if(cases.getSud()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getSud().getSud();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getOuest() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getOuest().getPiece() !=null){
                        if(casesEntreDeux.getOuest().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getOuest().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = true;
                        }
                    }
                }
                if(casesEntreDeux.getEst() != null){
                    if(casesEntreDeux.getEst() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getEst().getPiece() !=null){
                            if(casesEntreDeux.getEst().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getEst().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = true;
                            }
                        }
                    }
                }
            }
        }
        //nord sud case possible
        if(cases.getEst()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getEst().getEst();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getNord() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getNord().getPiece() !=null){
                        if(casesEntreDeux.getNord().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getNord().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = true;
                        }
                    }
                }
                if(casesEntreDeux.getSud() != null){
                    if(casesEntreDeux.getSud() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getSud().getPiece() !=null){
                            if(casesEntreDeux.getSud().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getSud().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = true;
                            }
                        }
                    }
                }
            }
        }
        if(cases.getOuest()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getOuest().getOuest();
            if(casesEntreDeux !=null){
                //faut regarder si il y a un cavalier
                if(casesEntreDeux.getNord() != null){
                    //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                    if(casesEntreDeux.getNord().getPiece() !=null){
                        if(casesEntreDeux.getNord().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                            && casesEntreDeux.getNord().getPiece().getClass() == Cavalier.class){
                            caseAttaquer = true;
                        }
                    }
                }
                if(casesEntreDeux.getSud() != null){
                    if(casesEntreDeux.getSud() != null){
                        //faut regarde si il y a une piece et que c'est pas la notre et que cest un cavalier
                        if(casesEntreDeux.getSud().getPiece() !=null){
                            if(casesEntreDeux.getSud().getPiece().getCouleurPiece() != notrePiece.getCouleurPiece() 
                                && casesEntreDeux.getSud().getPiece().getClass() == Cavalier.class){
                                caseAttaquer = true;
                            }
                        }
                    }
                }
            }
        }
        return caseAttaquer;
    }
    
    /**
     * Analyse les mouvements possibles du cavalier.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param pion la pièce à analyser
     * @param cases la case de départ
     */
    public void mouvementCavalier(HashMap<String, CasePolygonView> mesBouton, Piece pion,Cases cases){
        //regarder 2 case nord, sud, est, ouest
        Cases casesEntreDeux =null;
        //est ouest case possible
        if(cases.getNord() !=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getNord().getNord();
            if(casesEntreDeux !=null){
                regardeSiCaseLibreCavalier("ouest", "est", mesBouton,  pion, casesEntreDeux);
            }
        }
        if(cases.getSud()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getSud().getSud();
            if(casesEntreDeux !=null){
                regardeSiCaseLibreCavalier("ouest", "est", mesBouton,  pion, casesEntreDeux);
            }
        }
        //nord sud case possible
        if(cases.getEst()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getEst().getEst();
            if(casesEntreDeux !=null){
                regardeSiCaseLibreCavalier("sud", "nord", mesBouton,  pion, casesEntreDeux);
            }
        }
        if(cases.getOuest()!=null){
            //on peut regarder la case suivante
            casesEntreDeux = cases.getOuest().getOuest();
            if(casesEntreDeux !=null){
                regardeSiCaseLibreCavalier("sud", "nord", mesBouton,  pion, casesEntreDeux);
            }
        }
    }
    /**
     * Détermine si un pion peut attaquer une position ou le roi peut se placer
     * 
     * @param couleur la couleur du pion ("red", "green", "blue")
     * @param caseId l'identifiant de la case où se trouve le pion
     * @param casePion la case ou il y a le pion
     * @param caseRoi la case ou il u a le Roi
     * @param depart la case de depart avant récusiviter
     * @return true si le pion peut attaquer dans cette direction, false sinon
     */
    public boolean attaqueDuPion(String couleur,String caseId, Cases casePion, Cases caseRoi, Cases depart){
        String ecouteur = "";
        ecouteur = ecouteur.copyValueOf(caseId.toCharArray(), 1, caseId.length()-1);
        System.out.println("casesPion:"+caseId+" caseDepart:"+depart.getIdCase()+" couleur:"+couleur);
        switch (couleur) {
            case "green":
                //dans tout les cas il attaque nord
                if(depart == casePion.getNordEst() || depart == casePion.getNordOuest()){
                    System.out.println("P V att");
                    return true;
                }
                else{
                    return false;
                }
            case "red":
                
                if(onDeplacePionHaut(caseId) && Integer.parseInt(ecouteur) <=8){
                    //attaque nord
                    if(depart == casePion.getNordEst() || depart == casePion.getNordOuest()){
                        System.out.println("P R att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }//obliger de séparer car c'est pas les meme case tester
                else if(!(bleuDansCasEaH(caseId)) && Integer.parseInt(ecouteur) <=8){
                    //attaque nord
                    if(depart == casePion.getNordEst() || depart == casePion.getNordOuest()){
                        System.out.println("P R att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else{
                    //sinon attaque sud
                    if(depart == casePion.getSudEst() || depart == casePion.getSudOuest()){
                        System.out.println("P R att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }
            default:  //pion bleu
                if(onDeplacePionHaut(caseId) && Integer.parseInt(ecouteur) >8){
                    //attaque nord
                    if(depart == casePion.getNordEst() || depart == casePion.getNordOuest()){
                        System.out.println("P B att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }//obliger de séparer car c'est pas les meme case tester
                else if(bleuDansCasEaH(caseId)&& Integer.parseInt(ecouteur) >8){
                    //attaque nord
                    if(depart == casePion.getNordEst() || depart == casePion.getNordOuest()){
                        System.out.println("P B att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else{
                    //sinon attaque sud
                    if(depart == casePion.getSudEst() || depart == casePion.getSudOuest()){
                        System.out.println("P B att");
                        return true;
                    }
                    else{
                        return false;
                    }
                }
        }
    }
    /**
     * Détermine si une pièce donnée peut attaquer le roi dans une direction spécifique.
     * Analyse les capacités d'attaque de chaque type de pièce selon la direction.
     * 
     * @param attaquant la pièce potentielle attaquant
     * @param direction la direction d'analyse
     * @param roi la case contenant le roi
     * @param positionPiece la position de la pièce attaquant
     * @param depart la case de depart avant récusiviter
     * @return true si la pièce peut attaquer le roi dans cette direction, false sinon
     */
    public boolean quipeutAttaquerRoi(Piece attaquant, String direction, Cases roi, Cases positionPiece, Cases depart){
        switch(direction){
            case "nord":
                //tour,reigne
                if(attaquant.getClass() == Tour.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            case "nordEst":
                //fou, pion, reine
                if(attaquant.getClass() == Pion.class){
                    //c'est un pion donc faut que il eest audessu du roi
                    if((attaqueDuPion(attaquant.getCouleurPiece(),positionPiece.getIdCase(),positionPiece, roi,depart))){
                        //!attaqueduPion car la direstion c'est celle du roi pas du pion donc c'est inverser
                        return true; //le pion attaque le roi
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Fou.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else{
                    return false;
                }
            case "nordOuest":
                //fou, pion, reine
                if(attaquant.getClass() == Pion.class){
                    //c'est un pion donc faut que il y est audessu du roi
                    if((attaqueDuPion(attaquant.getCouleurPiece(),positionPiece.getIdCase(),positionPiece, roi,depart))){
                        //!attaqueduPion car la direstion c'est celle du roi pas du pion donc c'est inverser
                        //le pion attaque
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Fou.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else{
                    return false;
                }
            case "est":
                //tour, reigne
                if(attaquant.getClass() == Tour.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            case "ouest":
                //tour, reigne
                if(attaquant.getClass() == Tour.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            case "sud":
                //tour, reigne
                if(attaquant.getClass() == Tour.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acotes
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            case "sudEst":
                //fou, reine
                if(attaquant.getClass() == Fou.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Pion.class){
                    //c'est un pion donc faut que il y est audessu du roi
                    if((attaqueDuPion(attaquant.getCouleurPiece(),positionPiece.getIdCase(),positionPiece, roi,depart))){
                        //!attaqueduPion car la direstion c'est celle du roi pas du pion donc c'est inverser
                        //le pion attaque
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            case "sudOuest":
                //fou, reine
                if(attaquant.getClass() == Fou.class || attaquant.getClass() == Reine.class){
                    //elle se fait attaquer
                    return true;
                }
                else if(attaquant.getClass() == Pion.class){
                    //c'est un pion donc faut que il y est audessu du roi
                    if((attaqueDuPion(attaquant.getCouleurPiece(),positionPiece.getIdCase(),positionPiece, roi,depart))){
                        //!attaqueduPion car la direstion c'est celle du roi pas du pion donc c'est inverser
                        //le pion attaque
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else if(attaquant.getClass() == Roi.class){
                    //si il y a un roi dans cette direction faut voir si il y a une bar qui separe
                    if(depart.sonVoisin(positionPiece)){
                        return true;//si le depart voisin du roi adverse en peut pas se mettre cote acote
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            default:
                return false;
        }
    }
   
    /**
     * Fonction récursive pour vérifier si le roi est en échec.
     * 
     * @param direction la direction à analyser
     * @param cases la case actuelle
     * @param caseRoi la case du roi
     * @param depart la case de depart avant récusiviter
     * @return true si le roi est en échec, false sinon
     */
    public boolean recurciviterDuRoiEchec(String direction, Cases cases, Cases caseRoi,Cases depart){
        if(cases == null){
            return false; //hors du plateau
        }

        //on prend le suivant
        //System.out.println(direction+" "+cases.getIdCase());
        Cases nouvelleCase = getCaseSuivante(direction, cases);
        if(nouvelleCase ==null){
            return false;//rien trouver donc pas echec
        }
        else if(nouvelleCase.getPiece() != null){
            //on a un pion faut voir si c'est le notre ou pas
            if(nouvelleCase.getPiece().getCouleurPiece() == caseRoi.getPiece().getCouleurPiece()){
                //ces notre pion plus besoin de regarder si attaquer dans cette direction
                return false;
            }
            else{
                //c'es un ennemi
                if(quipeutAttaquerRoi(nouvelleCase.getPiece(), direction, caseRoi, nouvelleCase,depart)){
                    System.out.println(" attaquer");
                    return true;
                }
                else{
                    return false;
                }
            }
        }
        else{
            //on peut continuer
            //on regarde si on est pas dans le cas où on a pas put mettre de lien sudest et sud ouest
            direction = changeDirection(cases.getIdCase(), nouvelleCase.getIdCase(), direction);
            return recurciviterDuRoiEchec(direction, nouvelleCase,caseRoi,depart);
        }
    }
   

    /**
     * Vérifie si le roi est en échec.
     * 
     * @param cases la case actuelle
     * @param caseRoi la case du roi
     * @return true si le roi est en échec, false sinon
     */
    public boolean roiEnEchec(Cases cases, Cases caseRoi){
        if(recurciviterDuRoiEchec("nord", cases,caseRoi,cases) ||
            recurciviterDuRoiEchec("sud", cases,caseRoi, cases) ||
            recurciviterDuRoiEchec("sudEst", cases,caseRoi,cases) ||
            recurciviterDuRoiEchec("sudOuest", cases,caseRoi,cases) ||
            recurciviterDuRoiEchec("nordEst", cases,caseRoi,cases) ||
            recurciviterDuRoiEchec("nordOuest", cases,caseRoi, cases) ||
            recurciviterDuRoiEchec("est", cases,caseRoi,cases) ||
            recurciviterDuRoiEchec("ouest", cases,caseRoi,cases) 
            ){
            return true;
        }//verifier pour le cavalier car cas special sur comment il attaque
        if(attaquerParCavalier(cases, caseRoi.getPiece())){
            return true;
        }
        else{
            return false;
        }
        
    }
    /**
     * Vérifie si le roi peut bouger sur une case donnée.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param cases la case à analyser
     * @param caseRoi la case du roi
     * @param pion la pièce qui attaque
     */
    public void roiPeutBougerIci(HashMap<String, CasePolygonView> mesBouton,Cases cases, Cases caseRoi,Piece pion){
        if(cases != null && roiEnEchec(cases, caseRoi) != true){
            //on peut avancer 
            //on regarde si on peut attaquer
            if(cases.getPiece() != null ){
                if(cases.getPiece().getCouleurPiece() != pion.getCouleurPiece()){
                    CasePolygonView lebutton = mesBouton.get(cases.getIdCase());
                    lebutton.setGlow(true, Color.RED);
                    cases.setCoupPossible(2);
                }
            }
            else{//sinon on peut bouger
                System.out.println("le roi peut bouger ici");//verifi si il passe par la pour boufer mes pion
                CasePolygonView lebutton = mesBouton.get(cases.getIdCase());
                lebutton.setGlow(true, Color.YELLOW);
                cases.setCoupPossible(1);
            }
        }
    }

    /**
     * Vérifie si le roi peut faire le roque.
     * 
     * @param direction la direction à analyser
     * @param cases la case actuelle
     * @return true si le roi peut faire le roque, false sinon
     */
    public boolean peutFaireLerock(String direction, Cases cases){
        //si c'est null c'est que c'est bon on a fini
        //on prend le suivant
        Cases nouvelleCase = getCaseSuivante(direction, cases);
        if(nouvelleCase == null){
            return false;//on a fini est on a rien trouver
        }
        else if(nouvelleCase.getPiece() != null && nouvelleCase.getPiece().isPremierMouvement() && nouvelleCase.getPiece().getClass() == Tour.class){
            //si il y a un pion, que c'est sont premier mouvement et que c'est une tour alors on est arriver a la position de la tour
            return true;
        }
        else if(nouvelleCase.getPiece() != null){
            //si il y a une piece on peut pas faire le rock, vue que on a tester la condition ou il le peut
            return false;
        }
        else{
            //il y a pas de piece donc on continue de regarder
            return peutFaireLerock(direction, nouvelleCase);
        }
    }

    /**
     * Analyse les mouvements possibles du roi.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param pion la pièce à analyser
     * @param cases la case de départ
     * @param caseRoi la case du roi
     */
    public void mouvementRoi(HashMap<String, CasePolygonView> mesBouton, Piece pion,Cases cases, Cases caseRoi){
        if(pion.isPremierMouvement()){
            if(pion.getCouleurPiece() == "red"){
                //on regarde si il y a pas de pion et si les tour on pas bouger
                if(peutFaireLerock("ouest", cases) ){
                    //on peut faire le rock sauf si il est on echec
                    if(roiEnEchec(cases, caseRoi) != true){
                        
                        if(roiEnEchec(cases.getOuest().getOuest(), caseRoi) != true){
                            //on regarde si on peut faire le grand rock
                            CasePolygonView lebutton = mesBouton.get(cases.getOuest().getOuest().getIdCase());
                            lebutton.setGlow(true, Color.YELLOW);
                            cases.getOuest().getOuest().setCoupPossible(1);
                        }
                    }
                    
                }
                if(peutFaireLerock("est", cases)){
                    if(roiEnEchec(cases, caseRoi) != true){
                        //regarde si par asar l'endroit du rock n'est pas attaquer
                        if(roiEnEchec(cases.getEst().getEst(), caseRoi) != true){
                            //on regarde si on peut faire le petie rock
                            CasePolygonView lebutton = mesBouton.get(cases.getEst().getEst().getIdCase());
                            lebutton.setGlow(true, Color.YELLOW);
                            cases.getEst().getEst().setCoupPossible(1);
                        }
                    }
                }
            }
            else{
                //on regarde si il y a pas de pion et si les tour on pas bouger
                if(peutFaireLerock("ouest", cases) ){
                    //on peut faire le rock sauf si il est on echec
                    if(roiEnEchec(cases, caseRoi) != true){
                        
                        if(roiEnEchec(cases.getOuest().getOuest(), caseRoi) != true){
                            //on regarde si on peut faire le grand rock
                            CasePolygonView lebutton = mesBouton.get(cases.getOuest().getOuest().getIdCase());
                            lebutton.setGlow(true, Color.YELLOW);
                            cases.getOuest().getOuest().setCoupPossible(1);
                        }
                    }
                    
                }
                if(peutFaireLerock("est", cases)){
                    if(roiEnEchec(cases, caseRoi) != true){
                        //regarde si par asar l'endroit du rock n'est pas attaquer
                        if(roiEnEchec(cases.getEst().getEst(), caseRoi) != true){
                            //on regarde si on peut faire le petie rock
                            CasePolygonView lebutton = mesBouton.get(cases.getEst().getEst().getIdCase());
                            lebutton.setGlow(true, Color.YELLOW);
                            cases.getEst().getEst().setCoupPossible(1);
                        }
                    }
                }
            }
        }
        //sinon on regarde si les 8 case autour sont safe
        roiPeutBougerIci( mesBouton,cases.getNord(), caseRoi, pion);
        roiPeutBougerIci( mesBouton,cases.getSud(),caseRoi, pion);
        roiPeutBougerIci( mesBouton,cases.getEst(),caseRoi, pion);
        roiPeutBougerIci( mesBouton,cases.getOuest(),caseRoi, pion);
        roiPeutBougerIci( mesBouton,cases.getNordEst(),caseRoi, pion);
        roiPeutBougerIci( mesBouton,cases.getNordOuest(),caseRoi, pion);
        roiPeutBougerIci( mesBouton,cases.getSudEst(),caseRoi, pion);
        roiPeutBougerIci( mesBouton,cases.getSudOuest(),caseRoi, pion);
    }
    /**
     * Vérifie si le pion est dans la cases du haut
     * 
     * @param laCaseVoulue la case cible
     * @return true si le pion est en haut, false sinon
     */
    public boolean onDeplacePionHaut(String laCaseVoulue){
        if((laCaseVoulue.contains("I") || 
            laCaseVoulue.contains("J") || 
            laCaseVoulue.contains("K") || 
            laCaseVoulue.contains("L") )){
            return true;
        }
        else{
            return false;
        }
    }
    /**
     * Vérifie si le pion est dans la cases du E a H
     * 
     * @param laCaseVoulue la case cible
     * @return true si le pion est dans E a H, false sinon
     */
    public boolean bleuDansCasEaH(String laCaseVoulue){
        if((laCaseVoulue.contains("E") || 
            laCaseVoulue.contains("G") || 
            laCaseVoulue.contains("F") || 
            laCaseVoulue.contains("H") )){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * Vérifie si le pion peut faire le coup du passant.
     * 
     * @param mouvementPion le mouvement du pion
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param casesPionAttaquant la case du pion attaquant
     * @param pionAttaquant la pièce attaquante
     */
    public void coupDuPassant(String mouvementPion ,HashMap<String, CasePolygonView> mesBouton,Cases casesPionAttaquant,Piece pionAttaquant){
        //verifi si a gauche et a droite il y a une piece pion
        Piece pieceVoisin = null;
        Cases casesAAttaquer =null;
        if(casesPionAttaquant.getOuest() != null){
            pieceVoisin = casesPionAttaquant.getOuest().getPiece();
            if(pieceVoisin != null && pieceVoisin.getClass() == Pion.class &&
                pieceVoisin.getCouleurPiece() != pionAttaquant.getCouleurPiece() &&
                pieceVoisin.getCoupPassantPosible()){
                    //si il y a un pion, de couleur different et que c'est sont premier mouvement on peut attaquer
                    casesAAttaquer = getCaseSuivante(mouvementPion, casesPionAttaquant.getOuest());
                    if(casesAAttaquer !=null){//securiter
                        CasePolygonView lebutton = mesBouton.get(casesAAttaquer.getIdCase());
                        lebutton.setGlow(true, Color.RED);
                        casesAAttaquer.setCoupPossible(2);
                    }
                }
        }
        if(casesPionAttaquant.getEst() != null){
            pieceVoisin = casesPionAttaquant.getEst().getPiece();
            if(pieceVoisin != null && pieceVoisin.getClass() == Pion.class &&
                pieceVoisin.getCouleurPiece() != pionAttaquant.getCouleurPiece() &&
                pieceVoisin.getCoupPassantPosible()){
                    //si il y a un pion, de couleur different et que c'est sont premier mouvement on peut attaquer
                    casesAAttaquer = getCaseSuivante(mouvementPion, casesPionAttaquant.getEst());
                    if(casesAAttaquer !=null){//securiter
                        CasePolygonView lebutton = mesBouton.get(casesAAttaquer.getIdCase());
                        lebutton.setGlow(true, Color.RED);
                        casesAAttaquer.setCoupPossible(2);
                    }
                }
        }
    }

    /**
     * Analyse les mouvements possibles d'une pièce.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param laCaseVoulue la case cible
     * @param cases la case de départ
     * @param sertARien une case inutile
     */
    @Override
    public void mouvement(HashMap<String, CasePolygonView> mesBouton,String laCaseVoulue, Cases cases, Cases sertARien){
        Piece pion = cases.getPiece();
        String deplacementPiece = pion.deplacement();
        CasePolygonView lebutton = mesBouton.get(laCaseVoulue);
        lebutton.setGlow(true, Color.YELLOW);//on change le stille
        switch(deplacementPiece){
            case "1caseAvant":
                System.out.println("mouvement 1 case avant");
                //les pion rouge et bleu ne vont pas au nord mais au sud sauf plateau haut
                String ecouteur = "";
                ecouteur = ecouteur.copyValueOf(laCaseVoulue.toCharArray(), 1, laCaseVoulue.length()-1);
                if(pion.getCouleurPiece() == "green"){
                    //mouvemenet pion
                    //avant soit attaque coter
                    //avance de 1
                    if(onDeplacePionHaut(laCaseVoulue) && Integer.parseInt(ecouteur) >8){
                        //on se deplace vers le sud vue que le haut du plateau va de droite a sud et droite au nord
                        mouvementPion(mesBouton, cases.getSud());
                    }
                    else{
                        mouvementPion(mesBouton, cases.getNord());
                    }

                    //regarde si peut attaquer et l'attaque change pas
                    attaquePionPossible(mesBouton, cases.getNordEst(),  pion);
                    attaquePionPossible(mesBouton, cases.getNordOuest(),  pion);
                    coupDuPassant("nord",mesBouton, cases, pion);
                    //si premier mouveemnt 2 case
                    if (pion.isPremierMouvement() && cases.getNord().getPiece() == null) {
                        //si premier mouvement on sais que c'est pas null
                        mouvementPion(mesBouton, cases.getNord().getNord());
                    }
                }
                else if(pion.getCouleurPiece() == "red" && onDeplacePionHaut(laCaseVoulue)){//plateau haux ont vers le nord
                    //mouvemenet pion du plateau haut qui se deplace vers le nord
                    //avant soit attaque coter
                    //avance de 1
                    System.out.println("mouvement 1 case avant");
                    mouvementPion(mesBouton, cases.getNord());
                    //regarde si peut attaquer et faut regarder si il est pas dans le lien I5 I9 
                    if(Integer.parseInt(ecouteur) >8){
                        attaquePionPossible(mesBouton, cases.getSudEst(),  pion);
                        attaquePionPossible(mesBouton, cases.getSudOuest(),  pion);
                        coupDuPassant("sud",mesBouton, cases, pion);
                    }
                    else{
                        attaquePionPossible(mesBouton, cases.getNordEst(), pion);
                        attaquePionPossible(mesBouton, cases.getNordOuest(), pion);
                        coupDuPassant("nord",mesBouton, cases, pion);
                    }
                    //si premier mouveemnt 2 case
                    if (pion.isPremierMouvement() && cases.getNord().getPiece() == null) {
                        //si premier mouvement on sais que c'est pas null
                        mouvementPion(mesBouton, cases.getNord().getNord());
                    }
                }
                else{
                    //avant soit attaque coter
                    //avance de 1
                    System.out.println("mouvement 1 case avant");
                    //Attention si le pion blue va dans la case E il va au nord
                    if(pion.getCouleurPiece() == "blue" && bleuDansCasEaH(laCaseVoulue)){
                        mouvementPion(mesBouton, cases.getNord());
                    }
                    else{
                        mouvementPion(mesBouton, cases.getSud());
                    }
                    //regarde si peut attaquer
                    //on verifie si le bleu n'est pas dans le lien I5 I9
                    if(pion.getCouleurPiece() == "blue" && onDeplacePionHaut(laCaseVoulue) && Integer.parseInt(ecouteur) >8){
                        attaquePionPossible(mesBouton, cases.getNordEst(),  pion);
                        attaquePionPossible(mesBouton, cases.getNordOuest(),  pion);
                        coupDuPassant("sud",mesBouton, cases, pion);
                    }
                    else{
                        attaquePionPossible(mesBouton, cases.getSudEst(), pion);
                        attaquePionPossible(mesBouton, cases.getSudOuest(), pion);
                        coupDuPassant("sud",mesBouton, cases,pion);
                    }
                    //si premier mouveemnt 2 case
                    if (pion.isPremierMouvement() && cases.getSud().getPiece() == null) {
                        //si premier mouvement on sais que c'est pas null
                        mouvementPion(mesBouton, cases.getSud().getSud());
                    }
                }
                break;
            case "diagonal":
                System.out.println("mouvement diagonal");
                //fou deplacement   
                analyseMouvementRecursif(mesBouton, pion,cases,  "nordEst");
                analyseMouvementRecursif(mesBouton, pion,cases,  "nordOuest");
                analyseMouvementRecursif(mesBouton, pion,cases,  "sudEst");
                analyseMouvementRecursif(mesBouton, pion,cases, "sudOuest");

                break;
            case "Saut":
                //cavalier
                System.out.println("mouvement saut");
                mouvementCavalier(mesBouton, pion,cases);
                break;
            case "autour":
                System.out.println("mouvement autour");
                //roi
                //le problem c'est si l'endroit est attaquer, il peut pas aller sur ces case
                mouvementRoi(mesBouton, pion,cases, cases);
                break;
            case "toutDroit":
                System.out.println("mouvement tout droit");
                //tour
                analyseMouvementRecursif(mesBouton, pion,cases, "nord");
                analyseMouvementRecursif(mesBouton, pion,cases,  "ouest");
                analyseMouvementRecursif(mesBouton, pion,cases,  "sud");
                analyseMouvementRecursif(mesBouton, pion,cases,  "est");
                break;
            case "partout":
                System.out.println("mouvement partout");
                //reine
                analyseMouvementRecursif(mesBouton, pion,cases,  "nord");
                analyseMouvementRecursif(mesBouton, pion,cases,  "ouest");
                analyseMouvementRecursif(mesBouton, pion,cases,  "sud");
                analyseMouvementRecursif(mesBouton, pion,cases,  "est");
                analyseMouvementRecursif(mesBouton, pion,cases,"nordEst");
                analyseMouvementRecursif(mesBouton, pion,cases,  "nordOuest");
                analyseMouvementRecursif(mesBouton, pion,cases,  "sudEst");
                analyseMouvementRecursif(mesBouton, pion,cases,  "sudOuest");
                break;
        }
    }

}
