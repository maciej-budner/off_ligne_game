package com.example.offligneplay.codejeux.yalta.controler;


import java.util.HashMap;

import com.example.offligneplay.codejeux.yalta.model.apui.ApuisCase;
import com.example.offligneplay.codejeux.yalta.vue.CasePolygonView;
import com.example.offligneplay.codejeux.yalta.vue.PlateauYalta;

/**
 * La classe ClickEvent gère les événements de clic sur les cases du plateau de jeu.
 * Elle fait le lien entre l'interface graphique et la logique de jeu.
 *
 * @author Maciej Budner
 */
public class ClickEvent {
    /** Instance de ApuisCase pour gérer la logique de jeu */
    private ApuisCase apuisCase;
    private PlateauYalta view;

    /**
     * Constructeur par défaut de ClickEvent.
     * Initialise une nouvelle instance d'ApuisCase.
     */
    public ClickEvent(PlateauYalta notreView){
        this.view = notreView;
        apuisCase = new ApuisCase(this.view, this);
    }

    /**
     * Constructeur de ClickEvent avec configuration des joueurs.
     *
     * @param joueur le nombre de joueurs humains
     * @param ia le nombre d'intelligences artificielles
     */
    public ClickEvent(int joueur, int ia,PlateauYalta notreView){
        this.view = notreView;
        System.out.println("Plateau");
        apuisCase = new ApuisCase(joueur, ia, this.view, this);
        apuisCase.startGame();//on demare la partie car on a des joueur
        System.out.println("Plateau fin creation");
    }

    /**
     * Gère l'événement de clic sur une case du plateau.
     *
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param laCaseVoulue l'identifiant de la case cliquée
     */
    public void eventApuisCase(HashMap<String, CasePolygonView> mesBouton, String laCaseVoulue){
        System.out.println("eventApuisCase sur la case : " + laCaseVoulue);
        this.apuisCase.eventApuisCase(mesBouton, laCaseVoulue);
    }

    /**
     * Demande au joueur de choisir la pièce de promotion du pion.
     *
     */
    public void demandePromotion(PlateauYalta.PromotionCallback callback) {
        this.view.demandePromotion(callback);
    }

    /**
     * Affiche l'écran de fin de partie avec le message approprié.
     *
     * @param message le message de fin de partie à afficher
     * @param nbJoueur le nombre de joueurs humains
     * @param nbIA le nombre d'intelligences artificielles
     */
    public void finParti(String message, int nbJoueur, int nbIA) {
        if (this.view != null) {
            this.view.finDePartie(message, nbJoueur, nbIA);
        }
    }
}


