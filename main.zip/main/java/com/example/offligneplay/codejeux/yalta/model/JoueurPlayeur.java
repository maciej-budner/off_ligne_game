package com.example.offligneplay.codejeux.yalta.model;

import java.util.HashMap;
import java.util.HashSet;

import com.example.offligneplay.codejeux.yalta.model.analyse.*;
import com.example.offligneplay.codejeux.yalta.model.plateau.*;
import com.example.offligneplay.codejeux.yalta.model.apui.LogiqueMouvement;
import com.example.offligneplay.codejeux.yalta.vue.CasePolygonView;

/**
 * La classe JoueurPlayeur représente un joueur humain.
 * Elle gère les interactions du joueur avec l'interface graphique.
 * 
 * @author Maciej Budner
 */
public class JoueurPlayeur extends Playeur{

    /**
     * Constructeur par défaut de la classe JoueurPlayeur.
     * Initialise un joueur humain avec les paramètres par défaut.
     */
    public JoueurPlayeur(){
        super();
    }
    
    /**
     * Gère le mouvement d'une pièce par le joueur humain.
     * elle sert a rien car la logique est dans apuiCase mais sa class mere abstract oblige
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param plateau le plateau de jeu
     * @param couleurjoueur la couleur du joueur
     * @param logiqueMouvement la logique de mouvement
     * @param coupPossible les coups possibles
     * @param etatPartie l'état de la partie
     * @param analyseurPartie l'analyseur de partie
     */
    public void mouvementIa(HashMap<String, CasePolygonView> mesBouton, Plateau plateau,
                            String couleurjoueur, LogiqueMouvement logiqueMouvement,
                            HashSet<String> coupPossible, int etatPartie, AnalysePartie analyseurPartie){
        return;
    }
}
