package com.example.offligneplay.codejeux.yalta.model.plateau;

public class Roi extends Piece {
    public Roi() {
        super();
    }
    public Roi(String couleur, int point) {
        super(couleur, point);
    }

    @Override
    public String deplacement() {
        return "autour";
    }
    
}
