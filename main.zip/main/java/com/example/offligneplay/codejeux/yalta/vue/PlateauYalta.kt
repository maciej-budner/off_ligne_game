package com.example.offligneplay.codejeux.yalta.vue

import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.offligneplay.codejeux.yalta.controler.ClickEvent
import com.example.offligneplay.codejeux.yalta.model.apui.ApuisCase
import com.example.offligneplay.databinding.ActivityPlateauYaltaBinding

class PlateauYalta : AppCompatActivity() {

    private lateinit var ui: ActivityPlateauYaltaBinding
    private val mesBoutons = HashMap<String, CasePolygonView>()
    private lateinit var tourJoueur: TextView
    private lateinit var jeuRoot: ConstraintLayout
    private lateinit var clickEvent : ClickEvent
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivityPlateauYaltaBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(ui.root)

        // Masquer la barre de statut (status bar) et la barre de navigation
        val decorView = window.decorView
        val uiOptions =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        decorView.systemUiVisibility = uiOptions

        //jeux
        jeuRoot = ui.main
        tourJoueur = ui.statutJeuLabel
        Log.d("debug","Extra:${intent.extras}")
        var nbplayeur = intent.getIntExtra("NB_JOUEURS",3)
        var nbIA = intent.getIntExtra("NB_IA",0)
        Log.d("debug", "extrait:nbj=${nbplayeur}, nbIa=${nbIA}")
        this.clickEvent = ClickEvent(nbplayeur,nbIA, this)

        creerPlateau()

        //ecouteur
        ui.sorti.setOnClickListener {
            val accueil = Intent(this, Accueil::class.java)
            startActivity(accueil)
            finish()
        }

    }

    private fun ajouterTexte(valeur: String, x: Float, y: Float) {
        val tv = TextView(this).apply {
            text = valeur
            textSize = 14f
            setTextColor(Color.DKGRAY)
            translationX = x - 15f // Ajustement pour centrer le texte sur son propre axe
            translationY = y - 20f
        }
        jeuRoot.addView(tv)
    }

    private fun creerPlateau(){
        //visieul
        val idCases = arrayOf(
            "A1","A2","A3","A4","A5","A6","A7","A8",
            "B1","B2","B3","B4","B5","B6","B7","B8",
            "C1","C2","C3","C4","C5","C6","C7","C8",
            "D1","D2","D3","D4","D5","D6","D7","D8",
            "E1","E2","E3","E4","E9","E10","E11","E12",
            "F1","F2","F3","F4","F9","F10","F11","F12",
            "G1","G2","G3","G4","G9","G10","G11","G12",
            "H1","H2","H3","H4","H9","H10","H11","H12",
            "I8","I7","I6","I5","I9","I10","I11","I12",
            "J8","J7","J6","J5","J9","J10","J11","J12",
            "K8","K7","K6","K5","K9","K10","K11","K12",
            "L8","L7","L6","L5","L9","L10","L11","L12"
        )

        val couleurBouton = arrayOf(
            "black","white","black","white","black","white","black","white",
            "white","black","white","black","white","black","white","black",
            "black","white","black","white","black","white","black","white",
            "white","black","white","black","white","black","white","black",
            "black","white","black","white","black","white","black","white",
            "white","black","white","black","white","black","white","black",
            "black","white","black","white","black","white","black","white",
            "white","black","white","black","white","black","white","black",
            "white","black","white","black","white","black","white","black",
            "black","white","black","white","black","white","black","white",
            "white","black","white","black","white","black","white","black",
            "black","white","black","white","black","white","black","white"
        )

        // Tes coordonnées JavaFX (X, Y) d'origine
        val coordonnesBouton = arrayOf(
            // A1 à A8
            doubleArrayOf(-82.55, 270.6), doubleArrayOf(-92.23, 248.73), doubleArrayOf(-101.67, 226.21), doubleArrayOf(-111.98, 204.08),
            doubleArrayOf(-124.8, 183.53), doubleArrayOf(-137.84, 163.37), doubleArrayOf(-152.93, 144.07), doubleArrayOf(-166.9, 125.11),
            // B1 à B8
            doubleArrayOf(-58.44, 267.43), doubleArrayOf(-64.95, 239.63), doubleArrayOf(-71.18, 213.8), doubleArrayOf(-79.13, 186.63),
            doubleArrayOf(-92.24, 163.48), doubleArrayOf(-111.99, 143.8), doubleArrayOf(-132.14, 123.22), doubleArrayOf(-152.23, 104.38),
            // C1 à C8
            doubleArrayOf(-34.32, 264.41), doubleArrayOf(-38.04, 231.99), doubleArrayOf(-41.22, 201.0), doubleArrayOf(-46.37, 170.01),
            doubleArrayOf(-61.41, 143.31), doubleArrayOf(-87.14, 123.44), doubleArrayOf(-112.5, 104.06), doubleArrayOf(-137.45, 84.42),
            // D1 à D8
            doubleArrayOf(-10.53, 262.82), doubleArrayOf(-11.8, 224.86), doubleArrayOf(-13.12, 188.17), doubleArrayOf(-13.88, 151.61),
            doubleArrayOf(-30.28, 123.5), doubleArrayOf(-62.38, 102.82), doubleArrayOf(-92.66, 84.06), doubleArrayOf(-123.46, 65.16),
            // E1 à E12
            doubleArrayOf(13.34, 263.04), doubleArrayOf(14.22, 225.42), doubleArrayOf(16.51, 188.87), doubleArrayOf(18.69, 152.08),
            doubleArrayOf(35.28, 124.56), doubleArrayOf(65.23, 105.02), doubleArrayOf(95.68, 84.48), doubleArrayOf(126.98, 65.04),
            // F1 à F12
            doubleArrayOf(37.16, 265.19), doubleArrayOf(41.67, 232.72), doubleArrayOf(47.09, 201.9), doubleArrayOf(51.47, 170.08),
            doubleArrayOf(65.77, 144.92), doubleArrayOf(90.55, 124.36), doubleArrayOf(115.4, 104.53), doubleArrayOf(140.21, 85.01),
            // G1 à G12
            // G1 à G12
            doubleArrayOf(61.07, 267.28), doubleArrayOf(67.97, 240.67), doubleArrayOf(75.93, 213.05), doubleArrayOf(84.0, 186.6),
            doubleArrayOf(95.72, 163.1), doubleArrayOf(114.62, 142.58), doubleArrayOf(135.43, 123.85), doubleArrayOf(155.44, 104.02),
            // H1 à H12
            doubleArrayOf(86.64, 270.59), doubleArrayOf(95.36, 248.31), doubleArrayOf(105.5, 226.06), doubleArrayOf(116.41, 203.63),
            doubleArrayOf(127.71, 182.29), doubleArrayOf(141.15, 162.7), doubleArrayOf(156.33, 143.28), doubleArrayOf(170.29, 123.54),
            // I8 à I12
            doubleArrayOf(-111.56, 44.31), doubleArrayOf(-78.64, 61.5), doubleArrayOf(-47.1, 78.63), doubleArrayOf(-13.9, 95.34),
            doubleArrayOf(18.15, 95.8), doubleArrayOf(51.15, 79.09), doubleArrayOf(83.6, 61.25), doubleArrayOf(114.88, 44.07),
            // J8 à J12
            doubleArrayOf(-101.62, 22.45), doubleArrayOf(-72.1, 35.31), doubleArrayOf(-42.65, 46.97), doubleArrayOf(-12.54, 58.91),
            doubleArrayOf(17.72, 57.87), doubleArrayOf(47.17, 47.11), doubleArrayOf(75.77, 33.79), doubleArrayOf(104.73, 21.98),
            // K8 à K12
            doubleArrayOf(-91.64, 0.71), doubleArrayOf(-65.86, 9.13), doubleArrayOf(-38.37, 16.24), doubleArrayOf(-11.6, 22.41),
            doubleArrayOf(15.63, 21.8), doubleArrayOf(41.68, 15.77), doubleArrayOf(68.5, 7.53), doubleArrayOf(95.79, -0.24),
            // L8 à L12
            doubleArrayOf(-82.04, -20.96), doubleArrayOf(-57.98, -17.78), doubleArrayOf(-34.33, -15.75), doubleArrayOf(-10.58, -13.94),
            doubleArrayOf(13.31, -14.08), doubleArrayOf(37.55, -15.82), doubleArrayOf(61.46, -17.96), doubleArrayOf(85.54, -22.17)
        )

        val formeButton: Array<DoubleArray> = arrayOf(
            // A1 à A8
            doubleArrayOf(-75.0352, 197.9773, -55.7313, 192.6820, -50.7784, 211.3930, -67.2881, 211.3930), // A1
            doubleArrayOf(-61.7849, 174.5214, -84.1853, 182.1319, -75.0352, 197.9773, -55.7313, 192.6820), // A2
            doubleArrayOf(-84.1853, 182.1319, -92.5836, 167.5886, -67.2881, 155.8104, -61.7849, 174.5214), // A3
            doubleArrayOf(-76.6436, 137.0995, -101.0456, 152.9348, -92.5836, 167.5886, -67.2881, 155.8104), // A4
            doubleArrayOf(-101.0456, 152.9348, -110.0582, 137.3277, -86.5493, 122.7911, -76.6436, 137.0995), // A5
            doubleArrayOf(-110.0582, 137.3277, -118.3188, 123.0227, -100.8578, 107.3820, -86.5493, 122.7911), // A6
            doubleArrayOf(-118.3188, 123.0227, -127.1937, 107.6540, -113.5151, 93.6240, -100.8578, 107.3820), // A7
            doubleArrayOf(-127.1937, 107.6540, -134.9777, 94.1743, -126.8548, 80.0246, -113.5151, 93.6240), // A8

            // B1 à B8
            doubleArrayOf(-55.7313, 192.6820, -37.5, 187.5, -32.6177, 211.3930, -50.7784, 211.3930), // B1
            doubleArrayOf(-40.3223, 165.7162, -61.7849, 174.5214, -55.7313, 192.6820, -37.5, 187.5), // B2
            doubleArrayOf(-67.2881, 155.8104, -44.1745, 145.9046, -40.3223, 165.7162, -61.7849, 174.5214), // B3
            doubleArrayOf(-49.6778, 122.7911, -76.6436, 137.0995, -67.2881, 155.8104, -44.1745, 145.9046), // B4
            doubleArrayOf(-86.5493, 122.7911, -66.1874, 107.9324, -49.6778, 122.7911, -76.6436, 137.0995), // B5
            doubleArrayOf(-83.2474, 93.0737, -66.1874, 107.9324, -86.5493, 122.7911, -100.8578, 107.3820), // B6
            doubleArrayOf(-100.3074, 76.5640, -83.2474, 93.0737, -100.8578, 107.3820, -113.5151, 93.6240), // B7
            doubleArrayOf(-126.8548, 80.0246, -117.1697, 63.1538, -100.3074, 76.5640, -113.5151, 93.6240), // B8

            // C1 à C8
            doubleArrayOf(-37.5, 187.5, -17.7590, 184.4272, -15.5578, 211.3930, -32.6177, 211.3930), // C1
            doubleArrayOf(-19.41, 159.1124, -40.3223, 165.7162, -37.5, 187.5, -17.7590, 184.4272), // C2
            doubleArrayOf(-44.1745, 145.9046, -21.0610, 133.7975, -19.41, 159.1124, -40.3223, 165.7162), // C3
            doubleArrayOf(-24.3629, 108.4827, -49.6778, 122.7911, -44.1745, 145.9046, -21.0610, 133.7975), // C4
            doubleArrayOf(-66.1874, 107.9324, -45.8255, 91.4227, -24.3629, 108.4827, -49.6778, 122.7911), // C5
            doubleArrayOf(-66.1874, 107.9324, -45.8255, 91.4227, -67.8384, 77.6646, -83.2474, 93.0737), // C6
            doubleArrayOf(-87.0997, 63.9065, -67.8384, 77.6646, -83.2474, 93.0737, -100.3074, 76.5640), // C7
            doubleArrayOf(-117.1697, 63.1538, -109.4912, 49.7783, -87.0997, 63.9065, -100.3074, 76.5640), // C8

            // D1 à D8
            doubleArrayOf(-17.7590, 184.4272, 0.4016, 182.2259, 0.9518, 211.3930, -15.5578, 211.3930), // D1
            doubleArrayOf(0.0, 150.0, -19.41, 159.1124, -17.7590, 184.4272, 0.4016, 182.2259), // D2
            doubleArrayOf(-21.0610, 133.7975, 0.9518, 122.7911, 0.0, 150.0, -19.41, 159.1124), // D3
            doubleArrayOf(2.0525, 91.9730, -24.3629, 108.4827, -21.0610, 133.7975, 0.9518, 122.7911), // D4
            doubleArrayOf(-45.8255, 91.4227, -24.3629, 77.6646, 2.0525, 91.9730, -24.3629, 108.4827), // D5
            doubleArrayOf(-67.8384, 77.6646, -50.2280, 62.2556, -24.3629, 77.6646, -45.8255, 91.4227), // D6
            doubleArrayOf(-87.0997, 63.9065, -74.4422, 48.4976, -50.2280, 62.2556, -67.8384, 77.6646), // D7
            doubleArrayOf(-109.4912, 49.7783, -100.2109, 33.6127, -74.4422, 48.4976, -87.0997, 63.9065), // D8

            // E1, E2, E3, E4, E9, E10, E11, E12
            doubleArrayOf(0.4016, 182.2259, 20.7635, 185.5278, 18.5622, 211.3930, 0.9518, 211.3930), // E1
            doubleArrayOf(22.9648, 160.2130, 0.0, 150.0, 0.4016, 182.2259, 20.7635, 185.5278), // E2
            doubleArrayOf(0.9518, 122.7911, 25.7164, 134.3478, 22.9648, 160.2130, 0.0, 150.0), // E3
            doubleArrayOf(28.4680, 108.4827, 2.0525, 91.9730, 0.9518, 122.7911, 25.7164, 134.3478), // E4
            doubleArrayOf(2.0525, 91.9730, 26.2667, 78.7653, 49.9306, 94.1743, 28.4680, 108.4827), // E9
            doubleArrayOf(52.6822, 63.3563, 26.2667, 78.7653, 49.9306, 94.1743, 69.1919, 78.7653), // E10
            doubleArrayOf(77.9970, 47.9472, 52.6822, 63.3563, 69.1919, 78.7653, 89.0035, 63.3563), // E11
            doubleArrayOf(111.7676, 49.4814, 102.9477, 34.3113, 77.9970, 47.9472, 89.0035, 63.3563), // E12

            // F1 à F12 (F1, F2, F3, F4, F9, F10, F11, F12)
            doubleArrayOf(20.7635, 185.5278, 37.5, 187.5, 35.0719, 211.3930, 18.5622, 211.3930), // F1
            doubleArrayOf(44.4273, 167.3672, 22.9648, 160.2130, 20.7635, 185.5278, 37.5, 187.5), // F2
            doubleArrayOf(25.7164, 134.3478, 48.8299, 144.8039, 44.4273, 167.3672, 22.9648, 160.2130), // F3
            doubleArrayOf(52.6822, 123.8917, 28.4680, 108.4827, 25.7164, 134.3478, 48.8299, 144.8039), // F4
            doubleArrayOf(49.9306, 94.1743, 68.0912, 107.3820, 52.6822, 123.8917, 28.4680, 108.4827), // F9
            doubleArrayOf(49.9306, 94.1743, 69.1919, 78.7653, 85.1512, 93.0737, 68.0912, 107.3820), // F10
            doubleArrayOf(69.1919, 78.7653, 89.0035, 63.3563, 103.3118, 78.7653, 85.1512, 93.0737), // F11
            doubleArrayOf(89.0035, 63.3563, 111.7676, 49.4814, 119.3139, 62.4611, 103.3118, 78.7653), // F12

            // G1 à G12 (G1, G2, G3, G4, G9, G10, G11, G12)
            doubleArrayOf(37.5, 187.5, 58.7357, 193.2323, 53.2325, 211.3930, 35.0719, 211.3930), // G1
            doubleArrayOf(63.6887, 173.4207, 44.4273, 167.3672, 37.5, 187.5, 58.7357, 193.2323), // G2
            doubleArrayOf(48.8299, 144.8039, 71.3931, 155.2601, 63.6887, 173.4207, 44.4273, 167.3672), // G3
            doubleArrayOf(79.0976, 137.0995, 52.6822, 123.8917, 48.8299, 144.8039, 71.3931, 155.2601), // G4
            doubleArrayOf(68.0912, 107.3820, 89.0035, 120.5898, 79.0976, 137.0995, 52.6822, 123.8917), // G9
            doubleArrayOf(85.1512, 93.0737, 68.0912, 107.3820, 89.0035, 120.5898, 102.7615, 106.8317), // G10
            doubleArrayOf(103.3118, 78.7653, 85.1512, 93.0737, 102.7615, 106.8317, 116.5196, 93.0737), // G11
            doubleArrayOf(116.5196, 93.0737, 103.3118, 78.7653, 119.3139, 62.4611, 128.4507, 78.1765), // G12

            // H1 à H12 (H1, H2, H3, H4, H9, H10, H11, H12)
            doubleArrayOf(58.7357, 193.2323, 78.4404, 197.1008, 70.2925, 211.3930, 53.2325, 211.3930), // H1
            doubleArrayOf(63.6887, 173.4207, 58.7357, 193.2323, 78.4404, 197.1008, 86.4865, 182.9871), // H2
            doubleArrayOf(63.6887, 173.4207, 71.3931, 155.2601, 95.4111, 167.3324, 86.4865, 182.9871), // H3
            doubleArrayOf(95.4111, 167.3324, 104.0657, 152.1514, 79.0976, 137.0995, 71.3931, 155.2601), // H4
            doubleArrayOf(104.0657, 152.1514, 112.2468, 137.8010, 89.0035, 120.5898, 79.0976, 137.0995), // H9
            doubleArrayOf(89.0035, 120.5898, 102.7615, 106.8317, 120.9015, 122.6198, 112.2468, 137.8010), // H10
            doubleArrayOf(120.9015, 122.6198, 130.0961, 106.4916, 116.5196, 93.0737, 102.7615, 106.8317), // H11
            doubleArrayOf(130.0961, 106.4916, 137.4318, 93.6240, 128.4507, 78.1765, 116.5196, 93.0737), // H12

            // I8, I7, I6, I5, I9, I10, I11, I12
            doubleArrayOf(-100.2109, 33.6127, -91.6127, 18.6352, -68.3887, 31.4375, -74.4422, 48.4976), // I8
            doubleArrayOf(-52.6822, 63.3563, -77.9970, 47.9472, -70.2925, 29.7866, -49.9306, 40.7930), // I7
            doubleArrayOf(-50.2280, 62.2556, -44.1745, 41.3434, -22.7120, 52.9001, -24.3629, 77.6646), // I6
            doubleArrayOf(-24.3629, 77.6646, -22.7120, 52.9001, 2.0525, 62.2556, 2.0525, 91.9730), // I5
            doubleArrayOf(2.0525, 62.2556, 25.1660, 53.4504, 26.2667, 78.7653, 2.0525, 91.9730), // I9
            doubleArrayOf(25.1660, 53.4504, 49.9306, 40.7930, 52.6822, 63.3563, 26.2667, 78.7653), // I10
            doubleArrayOf(49.9306, 40.7930, 70.2925, 29.7866, 77.9970, 47.9472, 52.6822, 63.3563), // I11
            doubleArrayOf(70.2925, 29.7866, 94.1668, 19.2081, 102.9477, 34.3113, 77.9970, 47.9472), // I12

            // J8, J7, J6, J5, J9, J10, J11, J12
            doubleArrayOf(-70.2925, 29.7866, -64.7893, 11.0756, -85.5861, 4.4493, -94.1668, 19.2081), // J8
            doubleArrayOf(-49.9306, 40.7930, -70.2925, 29.7866, -64.7893, 11.0756, -43.3267, 19.3304), // J7
            doubleArrayOf(-22.7120, 52.9001, -19.9604, 27.5853, -41.9732, 18.7802, -44.1745, 41.3434), // J6
            doubleArrayOf(-19.9604, 27.5853, 2.0525, 32.5382, 2.0525, 62.2556, -22.7120, 52.9001), // J5
            doubleArrayOf(2.0525, 32.5382, 24.0654, 24.8337, 25.1660, 53.4504, 2.0525, 62.2556), // J9
            doubleArrayOf(24.0654, 24.8337, 43.3267, 19.3304, 49.9306, 40.7930, 25.1660, 53.4504), // J10
            doubleArrayOf(43.3267, 19.3304, 64.7893, 11.0756, 70.2925, 29.7866, 49.9306, 40.7930), // J11
            doubleArrayOf(94.1668, 19.2081, 85.5861, 4.4493, 64.7893, 11.0756, 70.2925, 29.7866), // J12

            // K8, K7, K6, K5, K9, K10, K11, K12
            doubleArrayOf(-82.8121, 3.3051, -75.0632, -10.1930, -55.7313, -4.8837, -62.3351, 12.7266), // K8
            doubleArrayOf(-62.3351, 12.7266, -55.7313, -4.8837, -37.5, 0.0, -41.9732, 18.7802), // K7
            doubleArrayOf(-41.9732, 18.7802, -37.5, 0.0, -17.7590, 0.6195, -19.9604, 27.5853), // K6
            doubleArrayOf(-19.9604, 27.5853, -17.7590, 0.6195, 0.9518, 5.0221, 2.0525, 32.5382), // K5
            doubleArrayOf(2.0525, 32.5382, 0.9518, 5.0221, 20.7635, 1.7201, 24.0654, 24.8337), // K9
            doubleArrayOf(24.0654, 24.8337, 20.7635, 1.7201, 37.5, 0.0, 43.3267, 19.3304), // K10
            doubleArrayOf(43.3267, 19.3304, 37.5, 0.0, 60.3867, -7.6353, 64.7893, 11.0756), // K11
            doubleArrayOf(85.5861, 4.4493, 76.9442, -10.4147, 60.3867, -7.6353, 64.7893, 11.0756), // K12

            // L8, L7, L6, L5, L9, L10, L11, L12
            doubleArrayOf(-75.0632, -10.1930, -66.7377, -24.6953, -49.6778, -24.6953, -55.7313, -4.8837), // L8
            doubleArrayOf(-37.5, 0.0, -32.0675, -24.6953, -49.6778, -24.6953, -55.7313, -4.8837), // L7
            doubleArrayOf(-37.5, 0.0, -32.0675, -24.6953, -15.5578, -24.6953, -17.7590, 0.6195), // L6
            doubleArrayOf(-15.5578, -24.6953, -0.1487, -24.6953, 0.9518, 5.0221, -17.7590, 0.6195), // L5
            doubleArrayOf(-0.1487, -24.6953, 19.1125, -24.6953, 20.7635, 1.7201, 0.9518, 5.0221), // L9
            doubleArrayOf(19.1125, -24.6953, 35.6222, -24.6953, 37.5, 0.0, 20.7635, 1.7201), // L10
            doubleArrayOf(35.6222, -24.6953, 52.1318, -24.6953, 60.3867, -7.6353, 37.5, 0.0), // L11
            doubleArrayOf(52.1318, -24.6953, 60.3867, -7.6353, 76.9442, -10.4147, 67.5409, -24.6953) // L12
        )

        val xOffset = 500f
        val yOffset = 1000f
        val echelle = 2.5f

        // 1. Génération des 96 boutons du plateau
        for (i in 0 until 96) {
            val caseId = idCases[i]
            val couleur = if (couleurBouton[i] == "black") Color.BLACK else Color.WHITE

            // Extraction et conversion des 4 sommets réels d'origine JavaFX
            val pointsPolygone = floatArrayOf(
                (formeButton[i][0] * echelle).toFloat() + xOffset, (formeButton[i][1] * echelle).toFloat() + yOffset, // Coin 1 (X, Y)
                (formeButton[i][2] * echelle).toFloat() + xOffset, (formeButton[i][3] * echelle).toFloat() + yOffset, // Coin 2 (X, Y)
                (formeButton[i][4] * echelle).toFloat() + xOffset, (formeButton[i][5] * echelle).toFloat() + yOffset, // Coin 3 (X, Y)
                (formeButton[i][6] * echelle).toFloat() + xOffset, (formeButton[i][7] * echelle).toFloat() + yOffset  // Coin 4 (X, Y)
            )

            // Création de notre vue polygonale sur-mesure
            val casePolygon = CasePolygonView(this, caseId, couleur, pointsPolygone) { id ->
                clickButton(id)
            }

            // Configuration pour que la vue occupe tout l'espace et puisse dessiner ses coordonnées absolues
            val layoutParams = ConstraintLayout.LayoutParams(
                ConstraintLayout.LayoutParams.MATCH_PARENT,
                ConstraintLayout.LayoutParams.MATCH_PARENT
            )
            casePolygon.layoutParams = layoutParams

            jeuRoot.addView(casePolygon)
            mesBoutons[caseId] = casePolygon

            val centerX = (pointsPolygone[0] + pointsPolygone[2] + pointsPolygone[4] + pointsPolygone[6]) / 4
            val centerY = (pointsPolygone[1] + pointsPolygone[3] + pointsPolygone[5] + pointsPolygone[7]) / 4

            val lettre = caseId.first().toString()
            val chiffre = caseId.substring(1)

            // ==========================================
            // 1. LES LETTRES (Bords extérieurs horizontaux/obliques)
            // ==========================================

            // En bas (Vert) : Déjà fait !
            if (chiffre == "1" && (lettre in "A".."H")) {
                ajouterTexte(lettre, centerX, centerY + 60f)
            }

            // En haut à gauche (Blocs A à B, rangée 8)
            if (chiffre == "8" && (lettre in "A".."D")) {
                // Décalage vers le haut et légèrement à gauche
                ajouterTexte(lettre, centerX - 40f, centerY - 40f)
            }

            // En haut à gauche (Blocs I à L, rangée 8)
            if (chiffre == "8" && (lettre in "I".."L")) {
                // Décalage vers le haut et légèrement à gauche
                ajouterTexte(lettre, centerX - 40f, centerY - 40f)
            }

            // En haut à droite (Blocs E à H, rangée 12)
            if (chiffre == "12" && (lettre in "E".."H")) {
                // Décalage vers le haut et légèrement à droite
                ajouterTexte(lettre, centerX + 40f, centerY - 40f)
            }
            // En haut à gauche (Blocs I à L, rangée 8)
            if (chiffre == "12" && (lettre in "I".."L")) {
                // Décalage vers le haut et légèrement à gauche
                ajouterTexte(lettre, centerX + 50f, centerY - 40f)
            }


            // ==========================================
            // 2. LES CHIFFRES (Flancs extérieurs verticaux/obliques)
            // ==========================================

            // Flanc gauche inférieur (A1 à A8) : Déjà fait !
            if (lettre == "A" && chiffre.toInt() <= 8) {
                ajouterTexte(chiffre, centerX - 60f, centerY + 10f)
            }

            // Flanc gauche supérieur (Toutes les cases L de l'aile supérieure)
            if (lettre == "L") {
                // Décalage vers la gauche (centerX - 60f) car c'est le flanc extérieur gauche
                ajouterTexte(chiffre, centerX , centerY - 70f)
            }


            // Flanc droit complet (H1 à H12) : Tout le grand côté du joueur Rouge
            if (lettre == "H") {
                ajouterTexte(chiffre, centerX + 60f, centerY + 10f)
            }

        }

        // 2. Placement des pièces initiales (Pions et figures)
        val piecesInitiales: Array<Array<String>> = arrayOf(
            arrayOf("♜", "♞", "♝", "♛", "♚", "♝", "♞", "♜"), // Ligne index 0[cite: 1]
            arrayOf("♟", "♟", "♟", "♟", "♟", "♟", "♟", "♟")  // Ligne index 1[cite: 1]
        )

        val positionPiece = arrayOf(
            arrayOf("A1","B1","C1","D1","E1","F1","G1","H1"), // Vert (Bas)
            arrayOf("A2","B2","C2","D2","E2","F2","G2","H2"),
            arrayOf("H12","G12","F12","E12","I12","J12","K12","L12"), // Rouge
            arrayOf("H11","G11","F11","E11","I11","J11","K11","L11"),
            arrayOf("A8","B8","C8","D8","I8","J8","K8","L8"), // Bleu
            arrayOf("A7","B7","C7","D7","I7","J7","K7","L7")
        )

        val couleursJoueurs = arrayOf(Color.GREEN, Color.RED, Color.BLUE)

        // Distribution des pièces Unicode sur les boutons stockés
        for (i in 0 until 6 step 2) {
            val indexCouleur = i / 2
            val couleurCourante = couleursJoueurs[indexCouleur]

            for (j in 0 until 8) {
                // Pièces spéciales
                mesBoutons[positionPiece[i][j]]?.apply {
                    textePiece = piecesInitiales[0][j]
                    couleurPiece = couleurCourante
                    invalidate() // Force le rafraîchissement du dessin
                }

                // Pions
                mesBoutons[positionPiece[i + 1][j]]?.apply {
                    textePiece = piecesInitiales[1][j]
                    couleurPiece = couleurCourante
                    invalidate()
                }
            }
        }
    }

    private fun clickButton(caseChoisie: String) {
        Log.d("JEU", "Case cliquée : $caseChoisie")
        // Ici tu feras appel à ton : clickEvent.eventApuisCase(mesBoutons, caseChoisie, statutLabel)
        this.clickEvent.eventApuisCase(this.mesBoutons, caseChoisie)
    }

    fun changeText(text: String){
        ui.statutJeuLabel.text = text
    }

    interface PromotionCallback {
        fun onPieceChoisie(unicodePiece: String?)
    }

    fun demandePromotion(callback: PromotionCallback) {
        // Ordre des pièces : Tour ♜, Cavalier ♞, Fou ♝, Dame ♛
        val optionsTexte = arrayOf<String?>("Dame (♛)", "Tour (♜)", "Fou (♝)", "Cavalier (♞)")
        val unicodePieces = arrayOf<String>("\u265B", "\u265C", "\u265D", "\u265E")

        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Promotion du Pion 👑")
        builder.setMessage("Félicitations ! Choisissez la pièce de promotion :")


        // Empêche le joueur de fermer le dialogue en cliquant à côté sans choisir
        builder.setCancelable(false)

        builder.setItems(optionsTexte, object : DialogInterface.OnClickListener {
            override fun onClick(dialog: DialogInterface?, which: Int) {
                val pieceChoisie = unicodePieces[which]
                // On déclenche le callback avec la pièce choisie
                callback.onPieceChoisie(pieceChoisie)
            }
        })

        builder.show()
    }
    fun finDePartie(message: String?, nbJoueurs: Int, nbIA: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Fin de partie 🏆")
        builder.setMessage(message + "\nQue voulez-vous faire ?")
        builder.setCancelable(false) // Bloque le clic en dehors pour obliger un choix

        // 1. Bouton "Rejouer"
        builder.setPositiveButton("Rejouer", object : DialogInterface.OnClickListener {
            override fun onClick(dialog: DialogInterface?, which: Int) {
                // Relance la même Activity avec les paramètres de joueurs
                val intent = Intent(this@PlateauYalta, PlateauYalta::class.java)
                intent.putExtra("NB_JOUEURS", nbJoueurs)
                intent.putExtra("NB_IA", nbIA)
                startActivity(intent)
                finish() // Ferme la partie actuelle
            }
        })

        // 2. Bouton "Revenir au menu"
        builder.setNegativeButton("Revenir au menu", object : DialogInterface.OnClickListener {
            override fun onClick(dialog: DialogInterface?, which: Int) {
                // Ouvre le menu principal (ex: MenuActivity)
                val intent: Intent = Intent(
                    this@PlateauYalta,
                    Accueil::class.java
                ) // Remplace par le nom de ton Activity Menu
                startActivity(intent)
                finish() // Ferme la partie actuelle
            }
        })

        builder.show()
    }
}