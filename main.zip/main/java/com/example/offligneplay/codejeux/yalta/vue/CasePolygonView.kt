package com.example.offligneplay.codejeux.yalta.vue

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Region
import android.view.MotionEvent
import android.view.View

class CasePolygonView(
    context: Context,
    val idCase: String,
    val couleur: Int,
    // Les 4 sommets du polygone [x1,y1, x2,y2, x3,y3, x4,y4]
    private val points: FloatArray,
    private val onClick: (String) -> Unit
) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = couleur
        style = Paint.Style.FILL
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = if (couleur == android.graphics.Color.BLACK) android.graphics.Color.WHITE else android.graphics.Color.BLACK
        textSize = 45f
        textAlign = Paint.Align.CENTER
    }

    private val path = Path()
    private val region = Region()
    var textePiece: String = ""
    var couleurPiece: Int = android.graphics.Color.TRANSPARENT

    init {
        // Construction du polygone point par point
        path.moveTo(points[0], points[1])
        path.lineTo(points[2], points[3])
        path.lineTo(points[4], points[5])
        path.lineTo(points[6], points[7])
        path.close()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // Permet de définir la zone de clic précise du polygone
        val rectF = android.graphics.RectF()
        path.computeBounds(rectF, true)
        region.setPath(path, Region(rectF.left.toInt(), rectF.top.toInt(), rectF.right.toInt(), rectF.bottom.toInt()))
    }
    // 1. Nouveau pinceau pour l'effet de bordure lumineuse (Glow)
    private val glowPaintMove = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE // Contour uniquement
        strokeWidth = 8f           // Épaisseur du halo
        color = android.graphics.Color.YELLOW // Couleur par défaut du glow
    }

    // 1. Nouveau pinceau pour l'effet de bordure lumineuse (Glow)
    private val glowPaintattaque = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE // Contour uniquement
        strokeWidth = 8f           // Épaisseur du halo
        color = android.graphics.Color.RED // Couleur par défaut du glow
    }

    // Variable d'état
    var estSurbrille: Boolean = false
    var couleurGlow: Int = android.graphics.Color.YELLOW

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // 1. Dessin de la case polygonale
        canvas.drawPath(path, paint)

        if (estSurbrille) {
            glowPaintMove.color = couleurGlow
            canvas.drawPath(path, glowPaintMove)
        }

        // 2. Dessin de la pièce (si présente) au centre de gravité du polygone
        if (textePiece.isNotEmpty()) {
            val cx = (points[0] + points[2] + points[4] + points[6]) / 4
            val cy = (points[1] + points[3] + points[5] + points[7]) / 4
            textPaint.color = couleurPiece
            // Ajustement mineur pour centrer le texte verticalement
            canvas.drawText(textePiece, cx, cy - ((textPaint.descent() + textPaint.ascent()) / 2), textPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            // On vérifie si le clic est STRICTEMENT à l'intérieur du polygone
            if (region.contains(event.x.toInt(), event.y.toInt())) {
                onClick(idCase)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    // 3. Méthodes faciles pour activer/désactiver le glow depuis le contrôleur
    fun setGlow(actif: Boolean, couleur: Int = android.graphics.Color.TRANSPARENT) {
        estSurbrille = actif
        couleurGlow = couleur
        invalidate() // Forcer le redessin de la case
    }

    fun getPiece():String {
        return this.textePiece
    }
    fun getcouleurPiece() : Int {
        return this.couleurPiece
    }

    fun deplacementPiece(piece:String, couleurPiece: Int){
        this.textePiece = piece
        this.couleurPiece = couleurPiece
    }

}