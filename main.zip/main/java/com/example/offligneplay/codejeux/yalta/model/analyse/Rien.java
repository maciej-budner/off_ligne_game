package com.example.offligneplay.codejeux.yalta.model.analyse;

import java.util.HashSet;

import com.example.offligneplay.codejeux.yalta.model.plateau.*;

/**
 * La classe Rien représente l'état normal d'une partie d'échecs.
 * Elle gère l'analyse lorsque le roi n'est ni en échec, ni en échec et mat, ni en pat.
 * C'est l'état par défaut du jeu où aucune menace particulière n'est présente.
 * 
 * @author Maciej Budner
 */
public class Rien extends AnalysePartie{
    /**
     * Constructeur par défaut de la classe Rien.
     * Initialise une liste vide de coups possibles.
     */
    public Rien(){
        super();
    }
    
    /**
     * Constructeur de la classe Rien avec une liste de coups existante.
     * 
     * @param coupPossible l'ensemble des coups possibles à initialiser
     */
    public Rien(HashSet<String> coupPossible){
        super(coupPossible);
    }
    

    /**
     * Vérifie l'état du jeu et retourne l'état normal.
     * Dans cet état, aucune menace particulière n'est présente.
     *
     * @param casesRoi la case contenant le roi
     * @return 0 pour indiquer que le jeu est dans un état normal
     */
    public int verificationEtatDuJeux(Cases casesRoi){
        return 0;//il fait rien
    }

    /**
     * Change l'état d'analyse en fonction de l'état du jeu.
     * Passe à l'état Echec pour vérifier si une menace est présente.
     * 
     * @param etat l'état du jeu actuel
     * @return une nouvelle instance d'Echec pour analyse
     */
    public AnalysePartie changeState(int etat){
        //revenir a l'anayle des coup possible
        return new Echec(this.getCoupPossible());
    }
}
