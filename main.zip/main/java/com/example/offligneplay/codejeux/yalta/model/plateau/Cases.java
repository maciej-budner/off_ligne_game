package com.example.offligneplay.codejeux.yalta.model.plateau;

/**
 * La classe Cases représente une case du plateau d'échecs.
 * Elle contient les références aux cases voisines, la pièce présente sur la case,
 * et les informations sur les mouvements possibles.
 * 
 * @author Maciej Budner
 */
public class Cases {
    /** Case voisine au nord-est */
    private Cases NordEst;
    /** Case voisine au nord-ouest */
    private Cases NordOuest;
    /** Case voisine au sud-est */
    private Cases SudEst;
    /** Case voisine au sud-ouest */
    private Cases SudOuest;
    /** Case voisine à l'est */
    private Cases Est;
    /** Case voisine à l'ouest */
    private Cases Ouest;
    /** Case voisine au nord */
    private Cases Nord;
    /** Case voisine au sud */
    private Cases Sud;
    /** Piece présente sur la case */
    private Piece piece;
    /** Identifiant unique de la case */
    private String idCase;
    /** Indicateur de coup possible (0: normal, 1: peut bouger, 2: peut manger) */
    private int coupPossible;

    /**
     * Constructeur par défaut de la classe Cases.
     * Initialise une case vide sans identifiant.
     */
    public Cases(){
        this.NordEst = null;
        this.NordOuest = null;
        this.SudEst = null;
        this.SudOuest = null;
        this.Est = null;
        this.Ouest = null;
        this.Nord = null;
        this.Sud = null;
        this.piece = null;
        this.idCase = null;
        this.coupPossible = 0;
    }
    /**
     * Constructeur de la classe Cases avec identifiant.
     * Initialise une case vide avec un identifiant spécifique.
     * 
     * @param idCase l'identifiant unique de la case
     */
    public Cases(String idCase){
        this.NordEst = null;
        this.NordOuest = null;
        this.SudEst = null;
        this.SudOuest = null;
        this.Est = null;
        this.Ouest = null;
        this.Nord = null;
        this.Sud = null;
        this.piece = null;
        this.idCase = idCase;
        this.coupPossible = 0;
    }
    /**
     * Définit les cases voisines de manière sécurisée.
     * N'écrase pas les références existantes si elles ne sont pas nulles.
     * 
     * @param NordEst la case voisine au nord-est
     * @param NordOuest la case voisine au nord-ouest
     * @param SudEst la case voisine au sud-est
     * @param SudOuest la case voisine au sud-ouest
     * @param Est la case voisine à l'est
     * @param Ouest la case voisine à l'ouest
     * @param Nord la case voisine au nord
     * @param Sud la case voisine au sud
     */
    public void setVoisinSecuriser(Cases NordEst, Cases NordOuest, Cases SudEst, Cases SudOuest, Cases Est, Cases Ouest, Cases Nord, Cases Sud){
        if(this.NordEst == null){
            this.NordEst = NordEst;
        }
        if(this.NordOuest == null){
            this.NordOuest = NordOuest;
        }
        if(this.SudEst == null){
            this.SudEst = SudEst;
        }
        if(this.SudOuest == null){
            this.SudOuest = SudOuest;
        }
        if(this.Est == null){
            this.Est = Est;
        }
        if(this.Ouest == null){
            this.Ouest = Ouest;
        }
        if(this.Nord == null){
            this.Nord = Nord;
        }
        if(this.Sud == null){
            this.Sud = Sud;
        }
    }
    public Cases getNordEst() {
        return this.NordEst;
    }
    public Cases getNordOuest() {
        return this.NordOuest;
    }
    public Cases getSudEst() {
        return this.SudEst;
    }
    public Cases getSudOuest() {
        return this.SudOuest;
    }
    public Cases getEst() {
        return this.Est;
    }
    public Cases getOuest() {
        return this.Ouest;
    }
    public Cases getNord() {
        return this.Nord;
    }
    public Cases getSud() {
        return this.Sud;
    }
    public Piece getPiece() {
        return this.piece;
    }
    public void setPiece(Piece piece) {
        this.piece = piece;
    }
    public int getCoupPossible() {
        return this.coupPossible;
    }
    public void setCoupPossible(int coupPossible) {
        this.coupPossible = coupPossible;
    }
    public String getIdCase() {
        return this.idCase;
    }
    
    //sa me sert pour debuger et voir si les case on les bonne relation
    public String toString(){
        String result = "id:"+this.idCase+"\n voisin:\n";
        if (this.NordOuest != null) {
            result += "NO:"+this.NordOuest.getIdCase()+" ";
        }
        if (this.Nord != null) {
            result += "N:"+this.Nord.getIdCase()+" ";
        }
        if (this.NordEst != null) {
            result += "NE:"+this.NordEst.getIdCase()+" ";
        }
        if (this.Ouest != null) {
            result += "O:"+this.Ouest.getIdCase()+" ";
        }
        result +="C:"+this.idCase+" ";
        if (this.Est != null) {
            result += "E:"+this.Est.getIdCase()+" ";
        }
        if (this.SudOuest != null) {
            result += "SO:"+this.SudOuest.getIdCase()+" ";
        }
        if (this.Sud != null) {
            result += "S:"+this.Sud.getIdCase()+" ";
        }
        if (this.SudEst != null) {
            result += "SE:"+this.SudEst.getIdCase()+" ";
        }
        return result+"\n";
    }
    
    /**
     * Vérifie si une case est voisine de cette case.
     * 
     * @param cases la case à vérifier
     * @return true si les cases sont voisines, false sinon
     */
    public boolean sonVoisin(Cases cases){
        if(this.NordOuest == cases || 
            this.Nord == cases || 
            this.NordEst == cases || 
            this.Ouest == cases || 
            this.Est == cases || 
            this.SudOuest == cases || 
            this.Sud == cases || 
            this.SudEst == cases){
            return true;
        }
        return false;
    }
    
}
