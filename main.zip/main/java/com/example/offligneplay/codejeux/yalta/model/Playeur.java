package com.example.offligneplay.codejeux.yalta.model;


import java.util.HashMap;
import java.util.HashSet;

import com.example.offligneplay.codejeux.yalta.model.analyse.*;
import com.example.offligneplay.codejeux.yalta.model.plateau.*;
import com.example.offligneplay.codejeux.yalta.model.apui.LogiqueMouvement;
import com.example.offligneplay.codejeux.yalta.vue.CasePolygonView;

/**
 * Classe abstraite représentant un joueur d'échecs.
 * Définit les propriétés et comportements communs à tous les types de joueurs.
 * 
 * @author Maciej Budner
 */
public abstract class Playeur {
    /** HashMap des coups possibles pour chaque pièce */
    private HashMap<String, HashSet<String>> coupPossible;
    /** Case de départ du coup en cours */
    private String coupDepart;
    /** Case d'arrivée du coup en cours */
    private String coupArriver;
    
    /**
     * Constructeur par défaut de la classe Playeur.
     * Initialise les structures de données pour gérer les coups.
     */
    public Playeur(){
        this.coupPossible = new HashMap<String, HashSet<String>>();
        this.coupArriver = "";
        this.coupDepart = "";
    }

    /**
     * Récupère la case de départ du coup en cours.
     * 
     * @return la case de départ
     */
    public String getCoupDepart(){
        return this.coupDepart;
    }
    /**
     * Définit la case de départ du coup.
     * 
     * @param depart la case de départ
     */
    public void setCoupDepart(String depart){
        this.coupDepart = depart;
    }
    /**
     * Récupère la case d'arrivée du coup en cours.
     * 
     * @return la case d'arrivée
     */
    public String getCoupArriver(){
        return this.coupArriver;
    }
    public void setCoupArriver(String arriver){
        this.coupArriver = arriver;
    }
    public HashMap<String, HashSet<String>> getCoupPosible(){
        return this.coupPossible;
    }

    public void resetCoupPossible(){
        this.coupPossible.clear();
    }
    public void resetSauvegardeCoup(){
        this.coupArriver ="";
        this.coupDepart = "";
    }
    /**
     * Ajoute une pièce aux coups possibles.
     * 
     * @param positionPion la position de la pièce
     */
    public void addCleer(String positionPion){
        this.coupPossible.put(positionPion, new HashSet<String>());
    }
    /**
     * Ajoute un coup possible à une pièce.
     * 
     * @param cleer la pièce
     * @param coup le coup possible
     */
    public void addCoupPossibleAtCleer(String cleer, String coup){
        HashSet<String> newCoup = this.coupPossible.get(cleer);
        if(newCoup == null){
            addCleer(cleer);
            newCoup = this.coupPossible.get(cleer);
        }
        newCoup.add(coup);
    }
    /**
     * Méthode abstraite pour le mouvement de l'IA.
     * 
     * @param mesBouton les boutons du plateau
     * @param plateau le plateau de jeu
     * @param couleurjoueur la couleur du joueur
     * @param logiqueMouvement la logique de mouvement
     * @param coupPossible les coups possibles
     * @param etatPartie l'état de la partie
     * @param analyseurPartie l'analyseur de partie
     */
    public abstract void mouvementIa(HashMap<String, CasePolygonView> mesBouton, Plateau plateau,
                                     String couleurjoueur, LogiqueMouvement logiqueMouvement,
                                     HashSet<String> coupPossible, int etatPartie, AnalysePartie analyseurPartie);
}
