package com.example.offligneplay.codejeux.yalta.model.plateau;

public class Reine extends Piece {
    public Reine() {
        super();
    }
    public Reine(String couleur, int point) {
        super(couleur, point);
    }

    @Override
    public String deplacement() {
        return "partout";
    }
    
}