package com.example.offligneplay.codejeux.yalta.model.plateau;

public class Cavalier extends Piece {
    public Cavalier() {
        super();
    }
    public Cavalier(String couleur, int point) {
        super(couleur, point);
    }

    @Override
    public String deplacement() {
        return "Saut";
    }
}
