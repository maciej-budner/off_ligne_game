package com.example.offligneplay.codejeux.yalta.model;


import java.util.HashMap;
import java.util.HashSet;

import com.example.offligneplay.codejeux.yalta.model.analyse.*;
import com.example.offligneplay.codejeux.yalta.model.plateau.*;
import com.example.offligneplay.codejeux.yalta.vue.CasePolygonView;

import com.example.offligneplay.codejeux.yalta.model.apui.LogiqueMouvement;
import com.example.offligneplay.codejeux.yalta.model.apui.MontrePosibiliter;
import com.example.offligneplay.codejeux.yalta.model.analyse.AnalysePartie;
import java.util.concurrent.locks.ReentrantLock;


/**
 * La classe IAPlayeur représente un joueur IA.
 * Elle gère les interactions de l'IA avec l'interface graphique.
 * 
 * @author Maciej Budner
 */
public class IAPlayeur extends Playeur{
    private HashMap<String, CasePolygonView> mesBouton;
    private Plateau plateau;
    private LogiqueMouvement logiqueMouvement;
    private MontrePosibiliter montrePosibiliter;
    private AnalysePartie analyseurPartie;
    private String couleurjoueur;
    private HashSet<String> coupPossible;
    private String[] couleurAdvers;
    private Cases casesDepart;
    private Cases coupArriver ;
    private Cases roi;
    private int pointCoup;
    private int scoreMouvement ;
    private String casePion;
    
    public IAPlayeur() {
        super();
        mesBouton= new HashMap<String, CasePolygonView>();
        plateau= null;
        logiqueMouvement= null;
        montrePosibiliter= null;
        analyseurPartie= null;
        couleurjoueur= "";
        coupPossible= new HashSet<String>();
        couleurAdvers = new String[]{"",""};
        casesDepart= null;
        coupArriver= null ;
        roi = null;
        pointCoup = 0;
        scoreMouvement = 0;
        casePion = "";
    }
    /**
     * Retourne les couleurs adverses du joueur.
     * 
     * @param couleurjoueur la couleur du joueur
     * @return un tableau contenant les couleurs adverses
     */
    public String[] getCouleurAdverse(String couleurjoueur){
        if(couleurjoueur == "green"){
            return new String[] {"red", "blue"};}
        else if(couleurjoueur == "red"){
            return new String[] {"green", "blue"};}
        else{
            return new String[] {"green", "red"};}
        
    }

    /**
     * Stocke les coups possibles d'un pion et reset le plateau.
     * 
     * @param mesBouton les boutons du plateau
     * @param plateau le plateau de jeu
     * @param positionPion la position du pion
     */
    public void sctockerCoupPosible(HashMap<String, CasePolygonView> mesBouton, Plateau plateau, String positionPion){
        for (Cases elem : plateau.getPlateau().values()) {
            if(elem.getCoupPossible() != 0){
                this.addCoupPossibleAtCleer(positionPion, elem.getIdCase());
                CasePolygonView button = mesBouton.get(elem.getIdCase());
                button.setGlow(false, android.graphics.Color.TRANSPARENT);
                elem.setCoupPossible(0);
            }
            
        }
    }

    //TODO factoriser
    
    /**
     * va analyser les coup possible que l'ia va pouvoir faire sans coup en avance
     * 
     * @param mesBouton les bouton du plateau
     * @param plateau le plateau de jeu
     * @param couleurjoueur la couleur du joueur
     * @param logiqueMouvement la logique de mouvement
     * @param coupPossible les coups possibles
     * @param etatPartie l'état de la partie
     * @param analyseurPartie l'analyseur de partie
     */
    public void mouvementIa(HashMap<String, CasePolygonView> mesBouton, Plateau plateau,
        String couleurjoueur,LogiqueMouvement logiqueMouvement, 
        HashSet<String> coupPossible, int etatPartie, AnalysePartie analyseurPartie){
        this.resetSauvegardeCoup();//reset pour pas bouger un pion qui a deja bouger
        this.mesBouton= mesBouton;
        this.plateau= plateau;
        this.logiqueMouvement= logiqueMouvement;
        this.analyseurPartie= analyseurPartie;
        this.couleurjoueur= couleurjoueur;
        this.coupPossible= coupPossible;
    
        //si il est en echec alors en a deja nos coup possible
        if(etatPartie == 1){
            for(String positionPion : this.coupPossible){
                this.addCleer(positionPion);
            }
        }
        else{//non echec alors en va regarder tout les pion si il en un coup
            for(Cases positionPion : plateau.getPlateau().values()){
                if(positionPion.getPiece() != null && positionPion.getPiece().getCouleurPiece() == this.couleurjoueur){
                    this.addCleer(positionPion.getIdCase());
                }
            }
        }
        //stocker tout les coup possible
        for(String positionPion : this.getCoupPosible().keySet()){
            Cases casesPion = this.plateau.getCasesInPosition(positionPion);
            this.logiqueMouvement.logiqueMouvement(new MontrePosibiliter(), this.mesBouton, positionPion, casesPion, casesPion);
            //ici tout mon plateau il y aura les coup possible donc faut le parcourir et le reset
            this.sctockerCoupPosible(this.mesBouton, this.plateau, positionPion);
        }

        //j'ai tout mes coup donc faudra calculer le meileur coup
        this.pointCoup = 0;
        this.couleurAdvers = this.getCouleurAdverse(this.couleurjoueur);
        this.casesDepart = null;
        this.coupArriver = null;
        this.roi = null;
        HashSet<Thread> allThread = new HashSet<Thread>();
        final ReentrantLock mutex = new ReentrantLock();
        final ReentrantLock plateauLock = new ReentrantLock();
        
        if(etatPartie == 1){
            //en va chercher a defendre avec la piece la plus faible
            this.pointCoup = 1000;
            for(String newcasePion : this.getCoupPosible().keySet()){
                final String currentCasePion = newcasePion;
                final Cases currentCasesDepart = this.plateau.getCasesInPosition(currentCasePion);
                Thread thread = new Thread(() -> {
                    plateauLock.lock();
                    try {
                        for(String coup: this.getCoupPosible().get(currentCasePion)){
                            // Variables locales pour éviter les race conditions
                            Cases localCoupArriver = this.plateau.getCasesInPosition(coup);
                            Cases localRoi;
                            
                            // Sauvegarder l'état original
                            Piece pieceOriginale = localCoupArriver.getPiece();
                            
                            //inverse
                            localCoupArriver.setPiece(currentCasesDepart.getPiece());
                            currentCasesDepart.setPiece(null);
                            
                            //en regarde si echec 
                            //attention si on peut bouger le roi sa sera pas la bonne cases
                            if(this.plateau.getCasesInPosition(this.plateau.getRoiSelonCouleur(this.couleurjoueur)).getPiece() == null){
                                localRoi = localCoupArriver;
                            }
                            else{
                                localRoi = this.plateau.getCasesInPosition(this.plateau.getRoiSelonCouleur(this.couleurjoueur));
                            }
                            
                            if(localRoi != null && localRoi.getPiece() != null){
                                if(!(this.analyseurPartie.roiEnEchec(localRoi, localRoi))){
                                    mutex.lock();
                                    try {
                                        //je suis plus en echec donc le coup est bien mais faut verifier si c'est le meileur
                                        if(localCoupArriver.getPiece().getPointPiece() < this.pointCoup){
                                            this.setCoupDepart(currentCasePion);
                                            this.setCoupArriver(coup);
                                            this.pointCoup = localCoupArriver.getPiece().getPointPiece();
                                        }
                                    } finally {
                                        mutex.unlock();
                                    }
                                }
                            }
                            //en remet la piece a sa place 
                            currentCasesDepart.setPiece(localCoupArriver.getPiece());
                            localCoupArriver.setPiece(pieceOriginale);  
                        }
                    } finally {
                        plateauLock.unlock();
                    }
                });
                thread.start();
                allThread.add(thread);
            }
        }
        else{
            //chercher a mettre echec ou bouffer un gros pion
            //c'est la qui faut des coup en avance
            this.pointCoup = 0;
            this.scoreMouvement = 0;
            for(String newcasePion : this.getCoupPosible().keySet()){
                final String currentCasePion = newcasePion;
                final Cases currentCasesDepart = this.plateau.getCasesInPosition(currentCasePion);
                Thread thread = new Thread(() -> {
                    plateauLock.lock();
                    try {
                        int localScoreMouvement = 0;
                        for(String coup: this.getCoupPosible().get(currentCasePion)){
                            // Variables locales pour éviter les race conditions
                            Cases localCoupArriver = this.plateau.getCasesInPosition(coup);
                            
                            // Sauvegarder l'état original
                            Piece pieceOriginale = localCoupArriver.getPiece();
                            
                            //vaut regarde si il mange une piece
                            if(localCoupArriver.getPiece() !=null){
                                localScoreMouvement += localCoupArriver.getPiece().getPointPiece() *20;
                            }
                            //inverse
                            localCoupArriver.setPiece(currentCasesDepart.getPiece());
                            currentCasesDepart.setPiece(null);
                            
                            //regarde si je me fait manger
                            if(this.analyseurPartie.roiEnEchec(localCoupArriver, localCoupArriver)){
                                localScoreMouvement -= localCoupArriver.getPiece().getPointPiece() *10;
                            }
                            //en regarde si echec 
                            if(this.analyseurPartie.bougePionMiseEchecRoi(null, this.plateau.getCasesInPosition(this.plateau.getRoiSelonCouleur(this.couleurAdvers[0]))) 
                                || this.analyseurPartie.bougePionMiseEchecRoi(null, this.plateau.getCasesInPosition(this.plateau.getRoiSelonCouleur(this.couleurAdvers[1])))){
                                //si je le met en echec c'est le meileur coup (c'est pas vrai)
                                localScoreMouvement += 50;
                            }
                            //sortir des piece inportante pour controler
                            if(localCoupArriver.getPiece().getClass() !=Roi.class && localCoupArriver.getPiece().getClass() !=Pion.class){
                                if(!(localCoupArriver.sonVoisin(currentCasesDepart))){//sa sert a rien de bouger d'une cases(surtout debut)
                                localScoreMouvement +=10*(int)(Math.random() * 2);}
                            }
                            //pousser les pion pour les promotion
                            if( localCoupArriver.getPiece().getClass() ==Pion.class){
                                localScoreMouvement +=2 *(int)(Math.random() * 2);
                            }
                            if(localCoupArriver.getPiece().getClass() == Roi.class){
                                //si il fait un rock c'est bonne start
                                if(!(localCoupArriver.sonVoisin(currentCasesDepart))){
                                    //rock
                                    localScoreMouvement +=50;
                                }
                            }
                            
                            mutex.lock();
                            try {
                                if(localScoreMouvement > this.pointCoup){
                                    this.pointCoup = localScoreMouvement;
                                    this.setCoupArriver(coup);
                                    this.setCoupDepart(currentCasePion);
                                }
                            } finally {
                                mutex.unlock();
                            }
                            
                            //en remet la piece a sa place 
                            currentCasesDepart.setPiece(localCoupArriver.getPiece());
                            localCoupArriver.setPiece(pieceOriginale);
                        }
                    } finally {
                        plateauLock.unlock();
                    }
                });
                thread.start();
                allThread.add(thread);
            }
        }
        //attendre que tous les threads soient terminés
        for(Thread thread : allThread){
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //en reset les coupPossible
        this.resetCoupPossible();
    }
    
}
