package com.example.offligneplay.codejeux.yalta.model.plateau;
import java.util.HashMap;
/**
 * Classe qui représente le plateau de jeu
 * 
 * @author Maciej
 */
public class Plateau {
    private HashMap<String, Cases> plateau;
    private String positionRoiGreen;
    private String positionRoiBlue;
    private String positionRoiRed;

    /**
     * on lie les cases uniquement leur lien nord et sud
     * @param idPlateauSens le tableau des identifiants des cases
     */
    private void associerVoisinNS(String idPlateauSens[][]){
        for(int i=0; i<8; i++){
            for(int j=0; j<4; j++){
                Cases cases = this.plateau.get(idPlateauSens[i][j]);
                
                //NE,NO,SE,SO,E,OU,N,S
                if(i==0){
                    //il a pas de haut
                    cases.setVoisinSecuriser(null, null, null, null, null, null, null, this.plateau.get(idPlateauSens[i+1][j]));
                }
                else if(i==7){
                    //il a pas de bas
                    cases.setVoisinSecuriser(null, null, null, null, null, null, this.plateau.get(idPlateauSens[i-1][j]), null);
                }
                else{
                    cases.setVoisinSecuriser(null, null, null, null, null, null, this.plateau.get(idPlateauSens[i-1][j]), this.plateau.get(idPlateauSens[i+1][j]));
                }
            }
        }   
    }
    /**
     * on relie les dernier cases du plateau qui manque dont le NO et NE pour le bas et le SO et SE pour le haut
     * @param lienSpecial le tableau des liens speciaux
     */
    private void associerVoisinSpecial(String lienSpecial[][]){
        //sa va boucler que sur j car i=0 prend que les lien du est
        //et i=1 prend que les lien Ouest
            for(int j=0; j<4; j++){
                Cases caseshaut = this.plateau.get(lienSpecial[0][j]);
                Cases casesbas = this.plateau.get(lienSpecial[1][j]);
                //pas besoin de test car sa va juste me donner des cases null
                caseshaut.setVoisinSecuriser(null, null, casesbas.getEst(), casesbas.getOuest(), null, null, null, null);
                casesbas.setVoisinSecuriser(caseshaut.getEst(), caseshaut.getOuest(), null, null, null, null, null, null);
            }
        
    }
    
    /**
     * ici on inverse car le lien du tableua de haut elle est special
     * @param lienSpecial le tableau des liens speciaux
     */
    private void associerVoisinSpecialTabHau(String lienSpecial[][]){
        //sa va boucler que sur j car i=0 tprend que les lien du est
        //et i=1 prend que les lien Ouest
            for(int j=0; j<4; j++){
                Cases caseshaut = this.plateau.get(lienSpecial[0][j]);
                Cases casesbas = this.plateau.get(lienSpecial[1][j]);
                //pas besoin de test car sa va juste me donner des cases null
                caseshaut.setVoisinSecuriser(null, null, casesbas.getOuest(), casesbas.getEst(), null, null, null, null);
                casesbas.setVoisinSecuriser( null, null,caseshaut.getOuest(), caseshaut.getEst(), null, null, null, null);
            }
        
    }
    /**
     * Il est diférent car sa taille c'est de 4*8 et on associer que les est et ouest
     * @param idPlateauSens le tableau des identifiants des cases
     */
    private void associerVoisinEO(String idPlateauSens[][]){
        //on va set le nord et sud
        for(int i=0; i<4; i++){
            for(int j=0; j<8; j++){
                Cases cases = this.plateau.get(idPlateauSens[i][j]);
                //NE,NO,SE,SO,E,OU,N,S
                if(i==0){
                    //il a pas de haut
                    if(j==0){
                        //il a pas gauche
                        cases.setVoisinSecuriser(null, null, this.plateau.get(idPlateauSens[i+1][j+1]), null, this.plateau.get(idPlateauSens[i][j+1]), null, null, null);
                    }
                    else if(j==7){
                        //il a pas droite
                        cases.setVoisinSecuriser(null, null, null, this.plateau.get(idPlateauSens[i+1][j-1]), null, this.plateau.get(idPlateauSens[i][j-1]), null, null);
                    }
                    else{
                        cases.setVoisinSecuriser(null, null, this.plateau.get(idPlateauSens[i+1][j+1]), this.plateau.get(idPlateauSens[i+1][j-1]), this.plateau.get(idPlateauSens[i][j+1]), this.plateau.get(idPlateauSens[i][j-1]), null, null);
                    }
                }
                else if(i==3){
                    //il a pas de bas
                    if(j==0){
                        //il a pas gauche
                        cases.setVoisinSecuriser(this.plateau.get(idPlateauSens[i-1][j+1]), null, null, null, this.plateau.get(idPlateauSens[i][j+1]), null, null, null);
                    }
                    else if(j==7){
                        //il a pas droite
                        cases.setVoisinSecuriser(null, this.plateau.get(idPlateauSens[i-1][j-1]), null, null, null, this.plateau.get(idPlateauSens[i][j-1]), null, null);
                    }
                    else{
                        cases.setVoisinSecuriser(this.plateau.get(idPlateauSens[i-1][j+1]), this.plateau.get(idPlateauSens[i-1][j-1]), null, null, this.plateau.get(idPlateauSens[i][j+1]), this.plateau.get(idPlateauSens[i][j-1]), null, null);
                    }
                }
                else{
                    if(j==0){
                        //il a pas gauche
                        cases.setVoisinSecuriser(this.plateau.get(idPlateauSens[i-1][j+1]), null, this.plateau.get(idPlateauSens[i+1][j+1]), null, this.plateau.get(idPlateauSens[i][j+1]), null, null, null);
                    }
                    else if(j==7){
                        //il a pas droite
                        cases.setVoisinSecuriser(null, this.plateau.get(idPlateauSens[i-1][j-1]), null, this.plateau.get(idPlateauSens[i+1][j-1]), null, this.plateau.get(idPlateauSens[i][j-1]), null, null);
                    }
                    else{
                        cases.setVoisinSecuriser(this.plateau.get(idPlateauSens[i-1][j+1]), this.plateau.get(idPlateauSens[i-1][j-1]), this.plateau.get(idPlateauSens[i+1][j+1]), this.plateau.get(idPlateauSens[i+1][j-1]), this.plateau.get(idPlateauSens[i][j+1]), this.plateau.get(idPlateauSens[i][j-1]), null, null);
                    }
                }
            
                
            }
        }
    }

    /**
     * initialisation des voisins
     */
    private void initVoisin(){
        String idPlateauHautLienNS[][]={//plateau haut on prend que N et S
            {"I8","J8","K8","L8"},
            {"I7","J7","K7","L7"},
            {"I6","J6","K6","L6"},
            {"I5","J5","K5","L5"},
            {"I9","J9","K9","L9"},
            {"I10","J10","K10","L10"},
            {"I11","J11","K11","L11"},
            {"I12","J12","K12","L12"}
        };
        String idPlateauGaucheNS[][]={//plateau haut on prend que N et S
            {"A8","B8","C8","D8"},
            {"A7","B7","C7","D7"},
            {"A6","B6","C6","D6"},
            {"A5","B5","C5","D5"},
            {"A4","B4","C4","D4"},
            {"A3","B3","C3","D3"},
            {"A2","B2","C2","D2"},
            {"A1","B1","C1","D1"}
        };
        String idPlateauDroiteNS[][]={//plateau haut on prend que N et S
            {"E12","F12","G12","H12"},
            {"E11","F11","G11","H11"},
            {"E10","F10","G10","H10"},
            {"E9","F9","G9","H9"},
            {"E4","F4","G4","H4"},
            {"E3","F3","G3","H3"},
            {"E2","F2","G2","H2"},
            {"E1","F1","G1","H1"}
        };
        //TODO: savoir comment faire les lien avec le tab de haut sont avoir besoin de la liaisont special
        String idPlateauDroiteLienEO[][]={//plateau haut on prend que E et O
            {"L12","K12","J12","I12","E12","F12","G12","H12"},
            {"L11","K11","J11","I11","E11","F11","G11","H11"},
            {"L10","K10","J10","I10","E10","F10","G10","H10"},
            {"L9","K9","J9","I9","E9","F9","G9","H9"},
            
        };
        String idPlateauBasLienEO[][]={//plateau haut on prend que E et O
            {"A4","B4","C4","D4","E4","F4","G4","H4"},
            {"A3","B3","C3","D3","E3","F3","G3","H3"},
            {"A2","B2","C2","D2","E2","F2","G2","H2"},
            {"A1","B1","C1","D1","E1","F1","G1","H1"}
        };
        String idPlateauGaucheLienEO[][]={//plateau haut on prend que E et O
            {"A8","B8","C8","D8","I8","J8","K8","L8"},
            {"A7","B7","C7","D7","I7","J7","K7","L7"},
            {"A6","B6","C6","D6","I6","J6","K6","L6"},
            {"A5","B5","C5","D5","I5","J5","K5","L5"}
        };
        
        //il me reste plus que les lien special il me manque que les lien milion pour SE SO NO, NE
        //lien special où il manque que les ouest et est
        String lienSpecialGauche[][]={
            {"A5","B5","C5","D5"},
            {"A4","B4","C4","D4"}
        };
        String lienSpecialDroite[][]={
            {"E9","F9","G9","H9"},
            {"E4","F4","G4","H4"}
        };
        //TODO: le lien est chelou car il on tout les 2 un lien vers le nord et pas sud
        String lienSpecialHaut[][]={
            {"L9","K9","J9","I9"},
            {"L5","K5","J5","I5"}
        };
        //TODO: factoriser pour le faire on une seul boucle
        this.associerVoisinNS(idPlateauHautLienNS);
        this.associerVoisinNS(idPlateauDroiteNS);
        this.associerVoisinNS(idPlateauGaucheNS);
        associerVoisinEO(idPlateauGaucheLienEO);
        associerVoisinEO(idPlateauBasLienEO);
        associerVoisinEO(idPlateauDroiteLienEO);
        //vue que tout les lien sont fait sauf pour les lien bizare au milieur qui on des lien particulier
        this.associerVoisinSpecial(lienSpecialGauche);
        this.associerVoisinSpecial(lienSpecialDroite);
        this.associerVoisinSpecialTabHau(lienSpecialHaut);
        
    }

    /**
     * initialisation du plateau
     */
    private void initPlateau(){
        String idCases[] = {"A1","A2","A3","A4","A5","A6","A7","A8",
                        "B1","B2","B3","B4","B5","B6","B7","B8",
                        "C1","C2","C3","C4","C5","C6","C7","C8",
                        "D1","D2","D3","D4","D5","D6","D7","D8",
                        "E1","E2","E3","E4","E9","E10","E11","E12",
                        "F1","F2","F3","F4","F9","F10","F11","F12",
                        "G1","G2","G3","G4","G9","G10","G11","G12",
                        "H1","H2","H3","H4","H9","H10","H11","H12",
                        "I8","I7","I6","I5","I9","I10","I11","I12",
                        "J8","J7","J6","J5","J9","J10","J11","J12",
                        "K8","K7","K6","K5","K9","K10","K11","K12",
                        "L8","L7","L6","L5","L9","L10","L11","L12"};
        for(int i=0; i<96; i++){
            Cases cases = new Cases(idCases[i]);
            this.plateau.put(idCases[i], cases);
        }
        this.initVoisin();

    }
    public Plateau() {
        this.plateau = new HashMap<String, Cases>();
    }

    /**
     * retourne une piece selon son nom et sa couleur
     * @param nomPiece le nom de la piece
     * @param couleur la couleur de la piece
     * @return la piece
     */
    public Piece getPieceSelonNom(String nomPiece, String couleur){
        switch(nomPiece){
            case "Tour":
                return new Tour(couleur, 5);
            case "Cavalier":
                return new Cavalier(couleur, 3);
            case "Fou":
                return new Fou(couleur, 3);
            case "Reine":
                return new Reine(couleur, 9);
            case "Roi":
                return new Roi(couleur, 100);
            default:
                return new Pion(couleur, 1);
        }
    }

    /**
     * met les piece dans le plateau
     */
    public void setStartPartie(){
        initPlateau();//une sorte de reset
        //on sait ou est le roi
        this.positionRoiBlue="I8";
        this.positionRoiGreen="E1";
        this.positionRoiRed="I12";
        //placer les piece
        String pieces[]={"Tour","Cavalier","Fou","Reine","Roi","Fou","Cavalier","Tour"};
        String positionPiece[][]={//vert
            {"A1","B1","C1","D1","E1","F1","G1","H1"},
            {"A2","B2","C2","D2","E2","F2","G2","H2"},
            //rouge
            {"H12","G12","F12","E12","I12","J12","K12","L12"},
            {"H11","G11","F11","E11","I11","J11","K11","L11"},
            //Bleau
            {"A8","B8","C8","D8","I8","J8","K8","L8"},
            {"A7","B7","C7","D7","I7","J7","K7","L7"}
        };
        String couleur[]={"green","red","blue"};
        for(int i=0; i<6; i+=2){
            for(int j=0; j<8; j++){
                String nomPiece = pieces[j];
                String positionGrosePiece = positionPiece[i][j];
                String positionPion = positionPiece[i+1][j];
                Cases casesGrisPiece = this.plateau.get(positionGrosePiece);
                Cases casesPion = this.plateau.get(positionPion);
                String couleurPiece = couleur[i/2];
                Piece piecePion = this.getPieceSelonNom("Pion", couleurPiece);
                Piece pieceGrose = this.getPieceSelonNom(nomPiece, couleurPiece);
                
                casesGrisPiece.setPiece(pieceGrose);
                casesPion.setPiece(piecePion);
            }
        }
        //void si tout les voisin sont bien
        /*
        for (Cases elem : this.plateau.values()) {
            System.out.print(elem.toString());
            System.out.print("\n");
        }*/
    }
    
    /**
     * deplace une piece
     * @param casePiece la case de la piece
     * @param casePieceDeplacer la case de la piece a deplacer
     */
    public void deplacementPiece(String casePiece, String casePieceDeplacer){
        Cases casesDepart = this.plateau.get(casePiece);
        Cases casesArrive = this.plateau.get(casePieceDeplacer);
        Piece piece = casesDepart.getPiece();
        casesArrive.setPiece(piece);
        casesDepart.setPiece(null);
    }
    
    /**
     * retourne le plateau
     * @return le plateau
     */
    public HashMap<String, Cases> getPlateau() {
        return this.plateau;
    }
    /**
     * retourne une case selon sa position
     * @param position la position de la case
     * @return la case
     */
    public Cases getCasesInPosition(String position){
        return this.plateau.get(position);
    }
    public void setPlateau(HashMap<String, Cases> plateau){
        this.plateau = plateau;
    }
    public String getRoiRed(){
        return this.positionRoiRed;
    }
    public String getRoiBlue(){
        return this.positionRoiBlue;
    }
    public String getRoiGreen(){
        return this.positionRoiGreen;
    }
    public void setRoiRed(String newPosition){
        this.positionRoiRed = newPosition;
    }
    public void setRoiBlue(String newPosition){
        this.positionRoiBlue = newPosition;
    }
    public void setRoiGreen(String newPosition){
        this.positionRoiGreen  = newPosition;
    }
    /**
     * verifie si une piece est sur une case
     * @param position la position de la case
     * @return true si une piece est sur la case, false sinon
     */
    public boolean pieceOnCase(String position){
        Cases pieceCase = this.plateau.get(position);
        if(pieceCase.getPiece() != null){
            return true;
        }
        else{
            return false;
        }
    }
    public String getCouleurPiece(String position){
        Cases cases = this.plateau.get(position);
        Piece piece = cases.getPiece();
        return piece.getCouleurPiece();
    }

    public int getCoupPossibleCase(String position){
        Cases cases = this.plateau.get(position);
        return cases.getCoupPossible();
    }

    public String getRoiSelonCouleur(String couleur){
        if(couleur == "green"){
            return this.positionRoiGreen;
        }
        else if(couleur == "red"){
            return this.positionRoiRed;
        }
        else{
            return this.positionRoiBlue;
        }
    }

}