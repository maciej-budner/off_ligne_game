package com.example.offligneplay.codejeux.yalta.model.plateau;

public class Fou extends Piece {
    public Fou() {
        super();
    }
    public Fou(String couleur, int point) {
        super(couleur, point);
    }

    @Override
    public String deplacement() {
        return "diagonal";
    }
    
}
