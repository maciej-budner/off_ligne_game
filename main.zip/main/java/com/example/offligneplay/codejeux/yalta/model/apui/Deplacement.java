package com.example.offligneplay.codejeux.yalta.model.apui;


import java.util.HashMap;

import com.example.offligneplay.codejeux.yalta.controler.ClickEvent;
import com.example.offligneplay.codejeux.yalta.model.plateau.*;
import com.example.offligneplay.codejeux.yalta.vue.CasePolygonView;
import com.example.offligneplay.codejeux.yalta.vue.PlateauYalta;

/**
 * La classe Deplacement implémente l'interface Mouvement pour gérer les déplacements spéciaux.
 * Elle gère principalement le roque (rock) et les mouvements complexes des pièces.
 * 
 * @author Maciej Budner
 */
public class Deplacement implements Mouvement{
    private boolean iaPlayleur;
    private ClickEvent clickEvent;

    /**
     * Constructeur par défaut de la classe Deplacement.
     */
    public Deplacement(ClickEvent click){
        this.clickEvent = click;
        this.iaPlayleur = false;
    }
    public Deplacement(boolean iaPlayleur,ClickEvent click){
        this.clickEvent = click;
        this.iaPlayleur = iaPlayleur;
    }


    /**
     * Recherche récursive la case contenant la tour dans une direction donnée.
     * Utilisée pour localiser la tour lors du roque.
     * 
     * @param direction la direction de recherche ("Est" ou "Ouest")
     * @param laCases la case de départ de la recherche
     * @return la case contenant la tour, ou null si non trouvée
     */
    public Cases recuGetCaseTour(String direction, Cases laCases){
        switch (direction) {
            case "Est":
                if(laCases == null){
                    //une sécuriter si jamais sa plante quelque part
                    return null;
                }
                else if(laCases.getPiece() != null){
                    //on sais que il peut y avoir que la tour
                    return laCases;
                }
                else{
                    return recuGetCaseTour("Est",laCases.getEst());
                }    
            case "Ouest":
                if(laCases == null){
                    //une sécuriter si jamais sa plante quelque part
                    return null;
                }
                else if(laCases.getPiece() != null){
                    //on sais que il peut y avoir que la tour
                    return laCases;
                }
                else{
                    return recuGetCaseTour("Ouest",laCases.getOuest());
                } 
            default:
                return null;
        }
    }

    /**
     * Gère le mouvement de roque (rock) du roi et de la tour.
     * Déplace à la fois le roi et la tour vers leurs positions finales.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param laCaseVoulue l'identifiant de la case de destination du roi
     * @param deplacementInit la case de départ du roi
     * @param deplacementVers la case de destination du roi
     */
    public void mouvementRock(HashMap<String, CasePolygonView> mesBouton, String laCaseVoulue, Cases deplacementInit, Cases deplacementVers){
        //il faut savoir si c'est a droite ou gauche du roi
        Cases tourCase =null;
        Cases positionTourFutur =null;
        if(deplacementInit.getEst().sonVoisin(deplacementVers)){
            //alors c'est a sa droite
            tourCase = recuGetCaseTour("Est", deplacementVers);
            if(tourCase != null){//securité
                //la tour doit etre a droite de la position du roi
                positionTourFutur = deplacementVers.getOuest();
                positionTourFutur.setPiece(tourCase.getPiece());
                tourCase.setPiece(null);

                //on fait pareil sur le plateau de la vue
                CasePolygonView buttonPieceBouge = mesBouton.get(tourCase.getIdCase());
                CasePolygonView buttonPieceVers = mesBouton.get(positionTourFutur.getIdCase());
                buttonPieceVers.deplacementPiece(buttonPieceBouge.getTextePiece(), buttonPieceBouge.getcouleurPiece());
                buttonPieceBouge.deplacementPiece("", android.graphics.Color.TRANSPARENT);
            }
        }
        else{
            //c'est a sa gauche (je fait deja des verif si c'est possible donc si on peut c'est obliger)
            tourCase = recuGetCaseTour("Ouest", deplacementVers);
            if(tourCase != null){//securité
                //la tour doit etre a gauche de la position du roi
                positionTourFutur = deplacementVers.getEst();
                positionTourFutur.setPiece(tourCase.getPiece());
                tourCase.setPiece(null);

                //on fait pareil sur le plateau de la vue
                CasePolygonView buttonPieceBouge = mesBouton.get(tourCase.getIdCase());
                CasePolygonView buttonPieceVers = mesBouton.get(positionTourFutur.getIdCase());
                buttonPieceVers.deplacementPiece(buttonPieceBouge.getTextePiece(), buttonPieceBouge.getcouleurPiece());
                buttonPieceBouge.deplacementPiece("", android.graphics.Color.TRANSPARENT);
            }
        }
    }
    /**
     * Vérifie si le pion est sur la case de promotion.
     * 
     * @param deplacementInit la case de départ du pion
     * @param deplacementVers la case de destination du pion
     * @return true si le pion est sur la case de promotion, false sinon
     */
    public boolean promotion(Cases deplacementInit,Cases deplacementVers){
        //on recupere le chiffre de la case où le pion vas se deplacer
        String ecouteur = "";
        ecouteur = ecouteur.copyValueOf(deplacementVers.getIdCase().toCharArray(), 1, deplacementVers.getIdCase().length()-1);
        
        //le vert doit aller a la case 8 ou 12
        if(deplacementInit.getPiece().getCouleurPiece() == "green" &&
            (Integer.parseInt(ecouteur) ==8 || Integer.parseInt(ecouteur) == 12)){ 
                return true;
        }
        else if(deplacementInit.getPiece().getCouleurPiece() == "red" &&
            (Integer.parseInt(ecouteur) ==1 || Integer.parseInt(ecouteur) == 8)){ 
                //le rouge doit aller a la case 8 ou 1
                return true;
        }
        else if(deplacementInit.getPiece().getCouleurPiece() == "blue" &&
            (Integer.parseInt(ecouteur) ==1 || Integer.parseInt(ecouteur) == 12)){ 
                //le blue doit aller a la case 1 ou 12
                return true;
        }
        else{
            //sinon le pion n'a pas atteint la case de promotion
            return false;
        }
    }

    /**
     * Crée une nouvelle pièce après la promotion.
     * 
     * @param promotion le symbole de la pièce à créer
     * @param couleur la couleur de la pièce
     * @return la nouvelle pièce créée
     */
    public Piece creerLaNouvellePiece(String promotion, String couleur){
        switch (promotion) {
            case "\u265B":
                return new Reine(couleur, 9);
            case "\u265C":
                return new Tour(couleur, 5);
            case "\u265D":
                return new Fou(couleur,3);
            case "\u265E":
                return new Cavalier(couleur,3);
            default:
                //Securiter si il y a un probleme
                return new Reine(couleur,9);
        }
    }

    /**
     * Vérifie si le coup du passant est possible.
     * 
     * @param deplacementInit la case de départ
     * @param deplacementVers la case de destination
     * @return true si le coup du passant est possible, false sinon
     */
    public boolean coupDuPassantPossible(Cases deplacementInit,Cases deplacementVers){
       if(deplacementVers.getCoupPossible() == 2 && deplacementInit.getPiece() != null){
            //si on peut manger et qui n'a pas de piece c'est que on a vue que c'est un coup du passont
            return true;
       }
       else{
            return false;
       }
    }

    /**
     * Gère le coup du passant en mangeant le pion adverse.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param deplacementInit la case de départ
     * @param deplacementVers la case de destination
     */
    public void coupDuPassantPionAdverseManger(HashMap<String, CasePolygonView> mesBouton,Cases deplacementInit, Cases deplacementVers){
        Cases casesPionManger = null;
        Piece pieceJoueur = deplacementInit.getPiece();
        Piece pieceManger = null;
        //regarde si la piece manger est a droite
        if(deplacementInit.getEst() != null){
            pieceManger = deplacementInit.getEst().getPiece();
            if(pieceManger != null && pieceManger.getCouleurPiece() != pieceJoueur.getCouleurPiece()){
                //obligatoire pour pas faire disparaitre un pion qui n'est pas manger
                if(deplacementVers.sonVoisin(deplacementInit.getEst())){
                    casesPionManger = deplacementInit.getEst();}
            }
        }
        //regarde si la piece manger est a gauche
        if(deplacementInit.getOuest() != null){
            pieceManger = deplacementInit.getOuest().getPiece();
            if(pieceManger != null && pieceManger.getCouleurPiece() != pieceJoueur.getCouleurPiece()){
                //obligatoire pour pas faire disparaitre un pion qui n'est pas manger
                if(deplacementVers.sonVoisin(deplacementInit.getOuest())){
                    casesPionManger = deplacementInit.getOuest();}
            }
        }
        if(casesPionManger != null){//securiter
        casesPionManger.setPiece(null);
        CasePolygonView buttonPieceManger = mesBouton.get(casesPionManger.getIdCase());
        buttonPieceManger.deplacementPiece("", android.graphics.Color.TRANSPARENT);}
    }

    /**
     * Exécute le mouvement d'une pièce.
     * 
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param laCaseVoulue l'identifiant de la case de destination
     * @param deplacementInit la case de départ
     * @param deplacementVers la case de destination
     */
    @Override
    public void mouvement(HashMap<String, CasePolygonView> mesBouton,String laCaseVoulue, Cases deplacementInit, Cases deplacementVers){
        CasePolygonView buttonPieceBouge = mesBouton.get(deplacementInit.getIdCase());
        CasePolygonView buttonPieceVers = mesBouton.get(laCaseVoulue);
        //regarder si on fait le rock et si le pion peut faire une promotion
        if(deplacementInit.getPiece().getClass() == Roi.class && deplacementInit.getPiece().isPremierMouvement()){
            //on regarde si on fait le rock
            if(!(deplacementInit.sonVoisin(deplacementVers))){
                //c'est pas sont voisin alors on fait le rock
                mouvementRock(mesBouton, laCaseVoulue, deplacementInit, deplacementVers);
            }
        }
        if(deplacementInit.getPiece().getClass() == Pion.class && promotion(deplacementInit,deplacementVers)){
            String promotion = "";
            if(iaPlayleur){
                //ia qui a jouer donc en fait la promo du pion en dame
                appliquerPromotion("\u265B", deplacementInit);
                completerDeplacement(mesBouton, laCaseVoulue, deplacementInit, deplacementVers);
            }
            else{
                //on peut faire une promotion
                System.out.println("le pion de "+deplacementInit.getPiece().getCouleurPiece()+" a atteint la case de promotion "+deplacementVers.getIdCase());
                this.clickEvent.demandePromotion(new PlateauYalta.PromotionCallback() {
                    @Override
                    public void onPieceChoisie(String promotion) {
                        // Ce code s'exécutera UNIQUEMENT quand le joueur aura cliqué sur la boîte
                        appliquerPromotion(promotion, deplacementInit);
                        completerDeplacement(mesBouton, laCaseVoulue, deplacementInit, deplacementVers);
                    }
                });
            }
            //on change la piece de la vue
            String nouvellePiece = promotion;
            buttonPieceBouge.deplacementPiece(nouvellePiece, deplacementInit.getPiece().getCouleurPieceAndroid() );
            //on change la piece du plateau
            deplacementInit.setPiece(creerLaNouvellePiece(promotion, deplacementInit.getPiece().getCouleurPiece()));
        }
        if(deplacementInit.getPiece().getClass() == Pion.class && coupDuPassantPossible(deplacementInit,deplacementVers)){
            //le pion peut faire le mouvement special coup du passant
            //le deplacement de la piece est fait faut juste faire disparaitre le pion adverse
            coupDuPassantPionAdverseManger(mesBouton, deplacementInit, deplacementVers);

        }
        if(deplacementInit.getPiece().getClass() == Pion.class && deplacementInit.getPiece().isPremierMouvement()){
            //si c'est un pion est que c'est sont premier mouvement faut voir si on met pas a true le coup passant
            if(!(deplacementInit.sonVoisin(deplacementVers))){
                //si c'est pas sont voisin, deplacement de 2 case
                deplacementInit.getPiece().setCoupPassantPossible(true);
            }
        }
        //deplace la piece du plateau
        deplacementVers.setPiece(deplacementInit.getPiece());
        deplacementInit.setPiece(null);

        //deplacement des piece de la vue
        buttonPieceVers.deplacementPiece(buttonPieceBouge.getTextePiece(), buttonPieceBouge.getcouleurPiece());
        buttonPieceBouge.deplacementPiece("", android.graphics.Color.TRANSPARENT);

        //on dit que la piece a fait sont premier mouvement tout le temps
        deplacementVers.getPiece().setPremierMouvement(false);
        //et augmante le nb coup
        deplacementVers.getPiece().augmenteNbCoup();
    }

    // Sub-fonction pour appliquer la nouvelle pièce issue de la promotion
    private void appliquerPromotion(String promotion, Cases deplacementInit) {
        deplacementInit.setPiece(creerLaNouvellePiece(promotion, deplacementInit.getPiece().getCouleurPiece()));
    }

    // Sub-fonction pour finaliser le déplacement (échiquier + vue)
    private void completerDeplacement(HashMap<String, CasePolygonView> mesBouton, String laCaseVoulue, Cases deplacementInit, Cases deplacementVers) {
        CasePolygonView buttonPieceBouge = mesBouton.get(deplacementInit.getIdCase());
        CasePolygonView buttonPieceVers = mesBouton.get(laCaseVoulue);

        // Déplace la pièce du plateau logique
        deplacementVers.setPiece(deplacementInit.getPiece());
        deplacementInit.setPiece(null);

        // Déplacement des pièces dans la vue Android
        buttonPieceVers.deplacementPiece(buttonPieceBouge.getTextePiece(), buttonPieceBouge.getcouleurPiece());
        buttonPieceBouge.deplacementPiece("", android.graphics.Color.TRANSPARENT);

        // Mise à jour des états de la pièce
        deplacementVers.getPiece().setPremierMouvement(false);
        deplacementVers.getPiece().augmenteNbCoup();
    }
    
}
