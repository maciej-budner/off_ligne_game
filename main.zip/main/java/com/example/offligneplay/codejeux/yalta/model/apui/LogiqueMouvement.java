package com.example.offligneplay.codejeux.yalta.model.apui;


import java.util.HashMap;

import com.example.offligneplay.codejeux.yalta.model.plateau.*;
import com.example.offligneplay.codejeux.yalta.vue.CasePolygonView;

/**
 * La classe LogiqueMouvement gère la logique des mouvements des pièces.
 * Elle sert d'intermédiaire entre les commandes de mouvement et l'interface graphique.
 * 
 * @author Maciej Budner
 */
public class LogiqueMouvement {
    /**
     * Constructeur par défaut de la classe LogiqueMouvement.
     */
    public LogiqueMouvement(){

    }
    
    /**
     * Exécute la logique de mouvement pour une pièce donnée.
     * Délègue l'exécution du mouvement à l'implémentation de l'interface Mouvement.
     * 
     * @param mouvement l'objet Mouvement qui gère le déplacement spécifique
     * @param mesBouton la HashMap contenant tous les boutons du plateau
     * @param laCaseVoulue l'identifiant de la case de destination
     * @param cases la case de départ
     * @param cases2 la case de destination
     */
    public void logiqueMouvement(Mouvement mouvement, HashMap<String, CasePolygonView> mesBouton, String laCaseVoulue, Cases cases, Cases cases2){
        mouvement.mouvement( mesBouton, laCaseVoulue, cases, cases2);
    }
}
