package com.example.offligneplay

import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.offligneplay.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayoutMediator



class MainActivity : AppCompatActivity() {
    private lateinit var ui: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ui = ActivityMainBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(ui.root)

        // Masquer la barre de statut (status bar) et la barre de navigation
        val decorView = window.decorView
        val uiOptions =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        decorView.systemUiVisibility = uiOptions

        chargeGrapheTable()

    }

    fun chargeGrapheTable(){
        val adapter = ViewPagerAdapter(this)
        ui.page.adapter = adapter

        // Pour lier les onglets et le ViewPager
        TabLayoutMediator(ui.table, ui.page) { tab, position ->
            tab.text = when (position) {
                0 -> "Jeux de Plateau"
                1 -> "Jeux de carte"
                2 -> "Jeux de réflexion"
                3 -> "Autre jeux"
                else -> null
            }
        }.attach()

    }
}

